--
-- PostgreSQL database dump
--

-- Dumped from database version 16.1
-- Dumped by pg_dump version 16.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.shop_shippingaddress DROP CONSTRAINT shop_shippingaddress_customer_id_c9f97754_fk_shop_customer_id;
ALTER TABLE ONLY public.shop_product DROP CONSTRAINT shop_product_customer_id_7d3a0e99_fk_shop_customer_id;
ALTER TABLE ONLY public.shop_orderline DROP CONSTRAINT shop_orderline_order_id_8ad562c5_fk_shop_order_id;
ALTER TABLE ONLY public.shop_order DROP CONSTRAINT shop_order_customer_id_f638df20_fk_shop_customer_id;
ALTER TABLE ONLY public.shop_customer DROP CONSTRAINT shop_customer_user_id_7e6c4129_fk_auth_user_id;
ALTER TABLE ONLY public.shop20_shippingaddress DROP CONSTRAINT shop20_shippingaddre_customer_id_028b07cb_fk_shop20_cu;
ALTER TABLE ONLY public.shop20_product DROP CONSTRAINT shop20_product_customer_id_a8581bf7_fk_shop20_customer_id;
ALTER TABLE ONLY public.shop20_orderline DROP CONSTRAINT shop20_orderline_order_id_27ab933a_fk_shop20_order_id;
ALTER TABLE ONLY public.shop20_order DROP CONSTRAINT shop20_order_customer_id_e29ccfba_fk_shop20_customer_id;
ALTER TABLE ONLY public.shop20_customer DROP CONSTRAINT shop20_customer_user_id_2b67b38c_fk_auth_user_id;
ALTER TABLE ONLY public.shop19_shippingaddress DROP CONSTRAINT shop19_shippingaddre_customer_id_01ed9cd1_fk_shop19_cu;
ALTER TABLE ONLY public.shop19_product DROP CONSTRAINT shop19_product_customer_id_5e2a1b50_fk_shop19_customer_id;
ALTER TABLE ONLY public.shop19_orderline DROP CONSTRAINT shop19_orderline_order_id_dd96fd6b_fk_shop19_order_id;
ALTER TABLE ONLY public.shop19_order DROP CONSTRAINT shop19_order_customer_id_165499b5_fk_shop19_customer_id;
ALTER TABLE ONLY public.shop19_customer DROP CONSTRAINT shop19_customer_user_id_282c5dd3_fk_auth_user_id;
ALTER TABLE ONLY public.shop18_shippingaddress DROP CONSTRAINT shop18_shippingaddre_customer_id_074a2fbf_fk_shop18_cu;
ALTER TABLE ONLY public.shop18_product DROP CONSTRAINT shop18_product_customer_id_5082adcc_fk_shop18_customer_id;
ALTER TABLE ONLY public.shop18_orderline DROP CONSTRAINT shop18_orderline_order_id_aef15da2_fk_shop18_order_id;
ALTER TABLE ONLY public.shop18_order DROP CONSTRAINT shop18_order_customer_id_7f37bcca_fk_shop18_customer_id;
ALTER TABLE ONLY public.shop18_customer DROP CONSTRAINT shop18_customer_user_id_788e92ac_fk_auth_user_id;
ALTER TABLE ONLY public.shop17_shippingaddress DROP CONSTRAINT shop17_shippingaddre_customer_id_a6a3b3b0_fk_shop17_cu;
ALTER TABLE ONLY public.shop17_product DROP CONSTRAINT shop17_product_customer_id_3f563d0a_fk_shop17_customer_id;
ALTER TABLE ONLY public.shop17_orderline DROP CONSTRAINT shop17_orderline_order_id_b820a59f_fk_shop17_order_id;
ALTER TABLE ONLY public.shop17_order DROP CONSTRAINT shop17_order_customer_id_f38201a7_fk_shop17_customer_id;
ALTER TABLE ONLY public.shop17_customer DROP CONSTRAINT shop17_customer_user_id_3802680a_fk_auth_user_id;
ALTER TABLE ONLY public.shop16_shippingaddress DROP CONSTRAINT shop16_shippingaddre_customer_id_42846bc0_fk_shop16_cu;
ALTER TABLE ONLY public.shop16_product DROP CONSTRAINT shop16_product_customer_id_6ad7bcc7_fk_shop16_customer_id;
ALTER TABLE ONLY public.shop16_orderline DROP CONSTRAINT shop16_orderline_order_id_e85d0392_fk_shop16_order_id;
ALTER TABLE ONLY public.shop16_order DROP CONSTRAINT shop16_order_customer_id_2f2e1321_fk_shop16_customer_id;
ALTER TABLE ONLY public.shop16_customer DROP CONSTRAINT shop16_customer_user_id_42469a38_fk_auth_user_id;
ALTER TABLE ONLY public.shop15_shippingaddress DROP CONSTRAINT shop15_shippingaddre_customer_id_6ec6cef9_fk_shop15_cu;
ALTER TABLE ONLY public.shop15_product DROP CONSTRAINT shop15_product_customer_id_b9b28ab4_fk_shop15_customer_id;
ALTER TABLE ONLY public.shop15_orderline DROP CONSTRAINT shop15_orderline_order_id_c68e5ee7_fk_shop15_order_id;
ALTER TABLE ONLY public.shop15_order DROP CONSTRAINT shop15_order_customer_id_8be91f4a_fk_shop15_customer_id;
ALTER TABLE ONLY public.shop15_customer DROP CONSTRAINT shop15_customer_user_id_cca3811f_fk_auth_user_id;
ALTER TABLE ONLY public.shop14_shippingaddress DROP CONSTRAINT shop14_shippingaddre_customer_id_b9687741_fk_shop14_cu;
ALTER TABLE ONLY public.shop14_product DROP CONSTRAINT shop14_product_customer_id_e23d7bca_fk_shop14_customer_id;
ALTER TABLE ONLY public.shop14_orderline DROP CONSTRAINT shop14_orderline_order_id_ab621f9e_fk_shop14_order_id;
ALTER TABLE ONLY public.shop14_order DROP CONSTRAINT shop14_order_customer_id_8441be08_fk_shop14_customer_id;
ALTER TABLE ONLY public.shop14_customer DROP CONSTRAINT shop14_customer_user_id_472d093f_fk_auth_user_id;
ALTER TABLE ONLY public.shop13_shippingaddress DROP CONSTRAINT shop13_shippingaddre_customer_id_01e8bd80_fk_shop13_cu;
ALTER TABLE ONLY public.shop13_product DROP CONSTRAINT shop13_product_customer_id_9edabf6b_fk_shop13_customer_id;
ALTER TABLE ONLY public.shop13_orderline DROP CONSTRAINT shop13_orderline_order_id_16348c44_fk_shop13_order_id;
ALTER TABLE ONLY public.shop13_order DROP CONSTRAINT shop13_order_customer_id_0d04c224_fk_shop13_customer_id;
ALTER TABLE ONLY public.shop13_customer DROP CONSTRAINT shop13_customer_user_id_35a715bb_fk_auth_user_id;
ALTER TABLE ONLY public.shop12_shippingaddress DROP CONSTRAINT shop12_shippingaddre_customer_id_cae2169e_fk_shop12_cu;
ALTER TABLE ONLY public.shop12_product DROP CONSTRAINT shop12_product_customer_id_422160a9_fk_shop12_customer_id;
ALTER TABLE ONLY public.shop12_orderline DROP CONSTRAINT shop12_orderline_order_id_014f64e9_fk_shop12_order_id;
ALTER TABLE ONLY public.shop12_order DROP CONSTRAINT shop12_order_customer_id_a59a8892_fk_shop12_customer_id;
ALTER TABLE ONLY public.shop12_customer DROP CONSTRAINT shop12_customer_user_id_bce3e3ce_fk_auth_user_id;
ALTER TABLE ONLY public.shop11_shippingaddress DROP CONSTRAINT shop11_shippingaddre_customer_id_530cd7f0_fk_shop11_cu;
ALTER TABLE ONLY public.shop11_product DROP CONSTRAINT shop11_product_customer_id_632cf107_fk_shop11_customer_id;
ALTER TABLE ONLY public.shop11_orderline DROP CONSTRAINT shop11_orderline_order_id_99b9f6ea_fk_shop11_order_id;
ALTER TABLE ONLY public.shop11_order DROP CONSTRAINT shop11_order_customer_id_cc8f62d2_fk_shop11_customer_id;
ALTER TABLE ONLY public.shop11_customer DROP CONSTRAINT shop11_customer_user_id_f766dd32_fk_auth_user_id;
ALTER TABLE ONLY public.shop10_shippingaddress DROP CONSTRAINT shop10_shippingaddre_customer_id_2d17caa0_fk_shop10_cu;
ALTER TABLE ONLY public.shop10_product DROP CONSTRAINT shop10_product_customer_id_d8762acd_fk_shop10_customer_id;
ALTER TABLE ONLY public.shop10_orderline DROP CONSTRAINT shop10_orderline_order_id_cc630673_fk_shop10_order_id;
ALTER TABLE ONLY public.shop10_order DROP CONSTRAINT shop10_order_customer_id_27f2cd1d_fk_shop10_customer_id;
ALTER TABLE ONLY public.shop10_customer DROP CONSTRAINT shop10_customer_user_id_49c4372c_fk_auth_user_id;
ALTER TABLE ONLY public.shop09_shippingaddress DROP CONSTRAINT shop09_shippingaddre_customer_id_571662e9_fk_shop09_cu;
ALTER TABLE ONLY public.shop09_product DROP CONSTRAINT shop09_product_customer_id_5ff967aa_fk_shop09_customer_id;
ALTER TABLE ONLY public.shop09_orderline DROP CONSTRAINT shop09_orderline_order_id_20d54247_fk_shop09_order_id;
ALTER TABLE ONLY public.shop09_order DROP CONSTRAINT shop09_order_customer_id_1d945d3a_fk_shop09_customer_id;
ALTER TABLE ONLY public.shop09_customer DROP CONSTRAINT shop09_customer_user_id_55fda531_fk_auth_user_id;
ALTER TABLE ONLY public.shop08_shippingaddress DROP CONSTRAINT shop08_shippingaddre_customer_id_9c13622c_fk_shop08_cu;
ALTER TABLE ONLY public.shop08_product DROP CONSTRAINT shop08_product_customer_id_724e5913_fk_shop08_customer_id;
ALTER TABLE ONLY public.shop08_orderline DROP CONSTRAINT shop08_orderline_order_id_76fb6bed_fk_shop08_order_id;
ALTER TABLE ONLY public.shop08_order DROP CONSTRAINT shop08_order_customer_id_6489dd60_fk_shop08_customer_id;
ALTER TABLE ONLY public.shop08_customer DROP CONSTRAINT shop08_customer_user_id_d24865d6_fk_auth_user_id;
ALTER TABLE ONLY public.shop07_shippingaddress DROP CONSTRAINT shop07_shippingaddre_customer_id_0921897b_fk_shop07_cu;
ALTER TABLE ONLY public.shop07_product DROP CONSTRAINT shop07_product_customer_id_84cca2df_fk_shop07_customer_id;
ALTER TABLE ONLY public.shop07_orderline DROP CONSTRAINT shop07_orderline_order_id_1a684a06_fk_shop07_order_id;
ALTER TABLE ONLY public.shop07_order DROP CONSTRAINT shop07_order_customer_id_949e5113_fk_shop07_customer_id;
ALTER TABLE ONLY public.shop07_customer DROP CONSTRAINT shop07_customer_user_id_4f8b41a3_fk_auth_user_id;
ALTER TABLE ONLY public.shop06_shippingaddress DROP CONSTRAINT shop06_shippingaddre_customer_id_e8d79370_fk_shop06_cu;
ALTER TABLE ONLY public.shop06_product DROP CONSTRAINT shop06_product_customer_id_646521f7_fk_shop06_customer_id;
ALTER TABLE ONLY public.shop06_orderline DROP CONSTRAINT shop06_orderline_order_id_d9177bbc_fk_shop06_order_id;
ALTER TABLE ONLY public.shop06_order DROP CONSTRAINT shop06_order_customer_id_ab170183_fk_shop06_customer_id;
ALTER TABLE ONLY public.shop06_customer DROP CONSTRAINT shop06_customer_user_id_cccf3ea0_fk_auth_user_id;
ALTER TABLE ONLY public.shop05_shippingaddress DROP CONSTRAINT shop05_shippingaddre_customer_id_d247fe42_fk_shop05_cu;
ALTER TABLE ONLY public.shop05_product DROP CONSTRAINT shop05_product_customer_id_4e9fa3d1_fk_shop05_customer_id;
ALTER TABLE ONLY public.shop05_orderline DROP CONSTRAINT shop05_orderline_order_id_d4a90023_fk_shop05_order_id;
ALTER TABLE ONLY public.shop05_order DROP CONSTRAINT shop05_order_customer_id_02b9756c_fk_shop05_customer_id;
ALTER TABLE ONLY public.shop05_customer DROP CONSTRAINT shop05_customer_user_id_a96b4e78_fk_auth_user_id;
ALTER TABLE ONLY public.shop04_shippingaddress DROP CONSTRAINT shop04_shippingaddre_customer_id_72dc6fad_fk_shop04_cu;
ALTER TABLE ONLY public.shop04_product DROP CONSTRAINT shop04_product_customer_id_a3f3724e_fk_shop04_customer_id;
ALTER TABLE ONLY public.shop04_orderline DROP CONSTRAINT shop04_orderline_order_id_28b868fb_fk_shop04_order_id;
ALTER TABLE ONLY public.shop04_order DROP CONSTRAINT shop04_order_customer_id_ec774de8_fk_shop04_customer_id;
ALTER TABLE ONLY public.shop04_customer DROP CONSTRAINT shop04_customer_user_id_7d6d4f13_fk_auth_user_id;
ALTER TABLE ONLY public.shop03_shippingaddress DROP CONSTRAINT shop03_shippingaddre_customer_id_81c071ed_fk_shop03_cu;
ALTER TABLE ONLY public.shop03_product DROP CONSTRAINT shop03_product_customer_id_49d34a57_fk_shop03_customer_id;
ALTER TABLE ONLY public.shop03_orderline DROP CONSTRAINT shop03_orderline_order_id_fc1c8109_fk_shop03_order_id;
ALTER TABLE ONLY public.shop03_order DROP CONSTRAINT shop03_order_customer_id_a5f8369b_fk_shop03_customer_id;
ALTER TABLE ONLY public.shop03_customer DROP CONSTRAINT shop03_customer_user_id_bcaf800a_fk_auth_user_id;
ALTER TABLE ONLY public.shop02_shippingaddress DROP CONSTRAINT shop02_shippingaddre_customer_id_8690ccc3_fk_shop02_cu;
ALTER TABLE ONLY public.shop02_product DROP CONSTRAINT shop02_product_customer_id_ed5029e9_fk_shop02_customer_id;
ALTER TABLE ONLY public.shop02_orderline DROP CONSTRAINT shop02_orderline_order_id_f1ea6df3_fk_shop02_order_id;
ALTER TABLE ONLY public.shop02_order DROP CONSTRAINT shop02_order_customer_id_5d68725e_fk_shop02_customer_id;
ALTER TABLE ONLY public.shop02_customer DROP CONSTRAINT shop02_customer_user_id_4bc269bb_fk_auth_user_id;
ALTER TABLE ONLY public.shop01_shippingaddress DROP CONSTRAINT shop01_shippingaddre_customer_id_70e95716_fk_shop01_cu;
ALTER TABLE ONLY public.shop01_product DROP CONSTRAINT shop01_product_customer_id_c5d86595_fk_shop01_customer_id;
ALTER TABLE ONLY public.shop01_orderline DROP CONSTRAINT shop01_orderline_order_id_86a351bf_fk_shop01_order_id;
ALTER TABLE ONLY public.shop01_order DROP CONSTRAINT shop01_order_customer_id_c50716f7_fk_shop01_customer_id;
ALTER TABLE ONLY public.shop01_customer DROP CONSTRAINT shop01_customer_user_id_19e364b9_fk_auth_user_id;
ALTER TABLE ONLY public.main_tweet DROP CONSTRAINT main_tweet_related_tweet_id_9596ad42_fk_main_tweet_id;
ALTER TABLE ONLY public.main_tweet DROP CONSTRAINT main_tweet_created_by_id_de58f942_fk_auth_user_id;
ALTER TABLE ONLY public.main_like DROP CONSTRAINT main_like_tweet_id_72804091_fk_main_tweet_id;
ALTER TABLE ONLY public.main_like DROP CONSTRAINT main_like_created_by_id_0c01bdc4_fk_auth_user_id;
ALTER TABLE ONLY public.main_follow DROP CONSTRAINT main_follow_user_followed_id_d42d3ee3_fk_auth_user_id;
ALTER TABLE ONLY public.main_follow DROP CONSTRAINT main_follow_created_by_id_4216b194_fk_auth_user_id;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm;
DROP INDEX public.shop_shippingaddress_customer_id_c9f97754;
DROP INDEX public.shop_product_customer_id_7d3a0e99;
DROP INDEX public.shop_orderline_order_id_8ad562c5;
DROP INDEX public.shop_order_customer_id_f638df20;
DROP INDEX public.shop20_shippingaddress_customer_id_028b07cb;
DROP INDEX public.shop20_product_customer_id_a8581bf7;
DROP INDEX public.shop20_orderline_order_id_27ab933a;
DROP INDEX public.shop20_order_customer_id_e29ccfba;
DROP INDEX public.shop19_shippingaddress_customer_id_01ed9cd1;
DROP INDEX public.shop19_product_customer_id_5e2a1b50;
DROP INDEX public.shop19_orderline_order_id_dd96fd6b;
DROP INDEX public.shop19_order_customer_id_165499b5;
DROP INDEX public.shop18_shippingaddress_customer_id_074a2fbf;
DROP INDEX public.shop18_product_customer_id_5082adcc;
DROP INDEX public.shop18_orderline_order_id_aef15da2;
DROP INDEX public.shop18_order_customer_id_7f37bcca;
DROP INDEX public.shop17_shippingaddress_customer_id_a6a3b3b0;
DROP INDEX public.shop17_product_customer_id_3f563d0a;
DROP INDEX public.shop17_orderline_order_id_b820a59f;
DROP INDEX public.shop17_order_customer_id_f38201a7;
DROP INDEX public.shop16_shippingaddress_customer_id_42846bc0;
DROP INDEX public.shop16_product_customer_id_6ad7bcc7;
DROP INDEX public.shop16_orderline_order_id_e85d0392;
DROP INDEX public.shop16_order_customer_id_2f2e1321;
DROP INDEX public.shop15_shippingaddress_customer_id_6ec6cef9;
DROP INDEX public.shop15_product_customer_id_b9b28ab4;
DROP INDEX public.shop15_orderline_order_id_c68e5ee7;
DROP INDEX public.shop15_order_customer_id_8be91f4a;
DROP INDEX public.shop14_shippingaddress_customer_id_b9687741;
DROP INDEX public.shop14_product_customer_id_e23d7bca;
DROP INDEX public.shop14_orderline_order_id_ab621f9e;
DROP INDEX public.shop14_order_customer_id_8441be08;
DROP INDEX public.shop13_shippingaddress_customer_id_01e8bd80;
DROP INDEX public.shop13_product_customer_id_9edabf6b;
DROP INDEX public.shop13_orderline_order_id_16348c44;
DROP INDEX public.shop13_order_customer_id_0d04c224;
DROP INDEX public.shop12_shippingaddress_customer_id_cae2169e;
DROP INDEX public.shop12_product_customer_id_422160a9;
DROP INDEX public.shop12_orderline_order_id_014f64e9;
DROP INDEX public.shop12_order_customer_id_a59a8892;
DROP INDEX public.shop11_shippingaddress_customer_id_530cd7f0;
DROP INDEX public.shop11_product_customer_id_632cf107;
DROP INDEX public.shop11_orderline_order_id_99b9f6ea;
DROP INDEX public.shop11_order_customer_id_cc8f62d2;
DROP INDEX public.shop10_shippingaddress_customer_id_2d17caa0;
DROP INDEX public.shop10_product_customer_id_d8762acd;
DROP INDEX public.shop10_orderline_order_id_cc630673;
DROP INDEX public.shop10_order_customer_id_27f2cd1d;
DROP INDEX public.shop09_shippingaddress_customer_id_571662e9;
DROP INDEX public.shop09_product_customer_id_5ff967aa;
DROP INDEX public.shop09_orderline_order_id_20d54247;
DROP INDEX public.shop09_order_customer_id_1d945d3a;
DROP INDEX public.shop08_shippingaddress_customer_id_9c13622c;
DROP INDEX public.shop08_product_customer_id_724e5913;
DROP INDEX public.shop08_orderline_order_id_76fb6bed;
DROP INDEX public.shop08_order_customer_id_6489dd60;
DROP INDEX public.shop07_shippingaddress_customer_id_0921897b;
DROP INDEX public.shop07_product_customer_id_84cca2df;
DROP INDEX public.shop07_orderline_order_id_1a684a06;
DROP INDEX public.shop07_order_customer_id_949e5113;
DROP INDEX public.shop06_shippingaddress_customer_id_e8d79370;
DROP INDEX public.shop06_product_customer_id_646521f7;
DROP INDEX public.shop06_orderline_order_id_d9177bbc;
DROP INDEX public.shop06_order_customer_id_ab170183;
DROP INDEX public.shop05_shippingaddress_customer_id_d247fe42;
DROP INDEX public.shop05_product_customer_id_4e9fa3d1;
DROP INDEX public.shop05_orderline_order_id_d4a90023;
DROP INDEX public.shop05_order_customer_id_02b9756c;
DROP INDEX public.shop04_shippingaddress_customer_id_72dc6fad;
DROP INDEX public.shop04_product_customer_id_a3f3724e;
DROP INDEX public.shop04_orderline_order_id_28b868fb;
DROP INDEX public.shop04_order_customer_id_ec774de8;
DROP INDEX public.shop03_shippingaddress_customer_id_81c071ed;
DROP INDEX public.shop03_product_customer_id_49d34a57;
DROP INDEX public.shop03_orderline_order_id_fc1c8109;
DROP INDEX public.shop03_order_customer_id_a5f8369b;
DROP INDEX public.shop02_shippingaddress_customer_id_8690ccc3;
DROP INDEX public.shop02_product_customer_id_ed5029e9;
DROP INDEX public.shop02_orderline_order_id_f1ea6df3;
DROP INDEX public.shop02_order_customer_id_5d68725e;
DROP INDEX public.shop01_shippingaddress_customer_id_70e95716;
DROP INDEX public.shop01_product_customer_id_c5d86595;
DROP INDEX public.shop01_orderline_order_id_86a351bf;
DROP INDEX public.shop01_order_customer_id_c50716f7;
DROP INDEX public.main_tweet_related_tweet_id_9596ad42;
DROP INDEX public.main_tweet_created_by_id_de58f942;
DROP INDEX public.main_like_tweet_id_72804091;
DROP INDEX public.main_like_created_by_id_0c01bdc4;
DROP INDEX public.main_follow_user_followed_id_d42d3ee3;
DROP INDEX public.main_follow_created_by_id_4216b194;
DROP INDEX public.django_session_session_key_c0390e0f_like;
DROP INDEX public.django_session_expire_date_a5c62663;
DROP INDEX public.django_admin_log_user_id_c564eba6;
DROP INDEX public.django_admin_log_content_type_id_c4bce8eb;
DROP INDEX public.auth_user_username_6821ab7c_like;
DROP INDEX public.auth_user_user_permissions_user_id_a95ead1b;
DROP INDEX public.auth_user_user_permissions_permission_id_1fbb5f2c;
DROP INDEX public.auth_user_groups_user_id_6a12ed8b;
DROP INDEX public.auth_user_groups_group_id_97559544;
DROP INDEX public.auth_permission_content_type_id_2f476e4b;
DROP INDEX public.auth_group_permissions_permission_id_84c5c92e;
DROP INDEX public.auth_group_permissions_group_id_b120cbf9;
DROP INDEX public.auth_group_name_a6ea08ec_like;
ALTER TABLE ONLY public.shop_shippingaddress DROP CONSTRAINT shop_shippingaddress_pkey;
ALTER TABLE ONLY public.shop_product DROP CONSTRAINT shop_product_pkey;
ALTER TABLE ONLY public.shop_orderline DROP CONSTRAINT shop_orderline_pkey;
ALTER TABLE ONLY public.shop_order DROP CONSTRAINT shop_order_pkey;
ALTER TABLE ONLY public.shop_customer DROP CONSTRAINT shop_customer_user_id_key;
ALTER TABLE ONLY public.shop_customer DROP CONSTRAINT shop_customer_pkey;
ALTER TABLE ONLY public.shop20_shippingaddress DROP CONSTRAINT shop20_shippingaddress_pkey;
ALTER TABLE ONLY public.shop20_product DROP CONSTRAINT shop20_product_pkey;
ALTER TABLE ONLY public.shop20_orderline DROP CONSTRAINT shop20_orderline_pkey;
ALTER TABLE ONLY public.shop20_order DROP CONSTRAINT shop20_order_pkey;
ALTER TABLE ONLY public.shop20_customer DROP CONSTRAINT shop20_customer_user_id_key;
ALTER TABLE ONLY public.shop20_customer DROP CONSTRAINT shop20_customer_pkey;
ALTER TABLE ONLY public.shop19_shippingaddress DROP CONSTRAINT shop19_shippingaddress_pkey;
ALTER TABLE ONLY public.shop19_product DROP CONSTRAINT shop19_product_pkey;
ALTER TABLE ONLY public.shop19_orderline DROP CONSTRAINT shop19_orderline_pkey;
ALTER TABLE ONLY public.shop19_order DROP CONSTRAINT shop19_order_pkey;
ALTER TABLE ONLY public.shop19_customer DROP CONSTRAINT shop19_customer_user_id_key;
ALTER TABLE ONLY public.shop19_customer DROP CONSTRAINT shop19_customer_pkey;
ALTER TABLE ONLY public.shop18_shippingaddress DROP CONSTRAINT shop18_shippingaddress_pkey;
ALTER TABLE ONLY public.shop18_product DROP CONSTRAINT shop18_product_pkey;
ALTER TABLE ONLY public.shop18_orderline DROP CONSTRAINT shop18_orderline_pkey;
ALTER TABLE ONLY public.shop18_order DROP CONSTRAINT shop18_order_pkey;
ALTER TABLE ONLY public.shop18_customer DROP CONSTRAINT shop18_customer_user_id_key;
ALTER TABLE ONLY public.shop18_customer DROP CONSTRAINT shop18_customer_pkey;
ALTER TABLE ONLY public.shop17_shippingaddress DROP CONSTRAINT shop17_shippingaddress_pkey;
ALTER TABLE ONLY public.shop17_product DROP CONSTRAINT shop17_product_pkey;
ALTER TABLE ONLY public.shop17_orderline DROP CONSTRAINT shop17_orderline_pkey;
ALTER TABLE ONLY public.shop17_order DROP CONSTRAINT shop17_order_pkey;
ALTER TABLE ONLY public.shop17_customer DROP CONSTRAINT shop17_customer_user_id_key;
ALTER TABLE ONLY public.shop17_customer DROP CONSTRAINT shop17_customer_pkey;
ALTER TABLE ONLY public.shop16_shippingaddress DROP CONSTRAINT shop16_shippingaddress_pkey;
ALTER TABLE ONLY public.shop16_product DROP CONSTRAINT shop16_product_pkey;
ALTER TABLE ONLY public.shop16_orderline DROP CONSTRAINT shop16_orderline_pkey;
ALTER TABLE ONLY public.shop16_order DROP CONSTRAINT shop16_order_pkey;
ALTER TABLE ONLY public.shop16_customer DROP CONSTRAINT shop16_customer_user_id_key;
ALTER TABLE ONLY public.shop16_customer DROP CONSTRAINT shop16_customer_pkey;
ALTER TABLE ONLY public.shop15_shippingaddress DROP CONSTRAINT shop15_shippingaddress_pkey;
ALTER TABLE ONLY public.shop15_product DROP CONSTRAINT shop15_product_pkey;
ALTER TABLE ONLY public.shop15_orderline DROP CONSTRAINT shop15_orderline_pkey;
ALTER TABLE ONLY public.shop15_order DROP CONSTRAINT shop15_order_pkey;
ALTER TABLE ONLY public.shop15_customer DROP CONSTRAINT shop15_customer_user_id_key;
ALTER TABLE ONLY public.shop15_customer DROP CONSTRAINT shop15_customer_pkey;
ALTER TABLE ONLY public.shop14_shippingaddress DROP CONSTRAINT shop14_shippingaddress_pkey;
ALTER TABLE ONLY public.shop14_product DROP CONSTRAINT shop14_product_pkey;
ALTER TABLE ONLY public.shop14_orderline DROP CONSTRAINT shop14_orderline_pkey;
ALTER TABLE ONLY public.shop14_order DROP CONSTRAINT shop14_order_pkey;
ALTER TABLE ONLY public.shop14_customer DROP CONSTRAINT shop14_customer_user_id_key;
ALTER TABLE ONLY public.shop14_customer DROP CONSTRAINT shop14_customer_pkey;
ALTER TABLE ONLY public.shop13_shippingaddress DROP CONSTRAINT shop13_shippingaddress_pkey;
ALTER TABLE ONLY public.shop13_product DROP CONSTRAINT shop13_product_pkey;
ALTER TABLE ONLY public.shop13_orderline DROP CONSTRAINT shop13_orderline_pkey;
ALTER TABLE ONLY public.shop13_order DROP CONSTRAINT shop13_order_pkey;
ALTER TABLE ONLY public.shop13_customer DROP CONSTRAINT shop13_customer_user_id_key;
ALTER TABLE ONLY public.shop13_customer DROP CONSTRAINT shop13_customer_pkey;
ALTER TABLE ONLY public.shop12_shippingaddress DROP CONSTRAINT shop12_shippingaddress_pkey;
ALTER TABLE ONLY public.shop12_product DROP CONSTRAINT shop12_product_pkey;
ALTER TABLE ONLY public.shop12_orderline DROP CONSTRAINT shop12_orderline_pkey;
ALTER TABLE ONLY public.shop12_order DROP CONSTRAINT shop12_order_pkey;
ALTER TABLE ONLY public.shop12_customer DROP CONSTRAINT shop12_customer_user_id_key;
ALTER TABLE ONLY public.shop12_customer DROP CONSTRAINT shop12_customer_pkey;
ALTER TABLE ONLY public.shop11_shippingaddress DROP CONSTRAINT shop11_shippingaddress_pkey;
ALTER TABLE ONLY public.shop11_product DROP CONSTRAINT shop11_product_pkey;
ALTER TABLE ONLY public.shop11_orderline DROP CONSTRAINT shop11_orderline_pkey;
ALTER TABLE ONLY public.shop11_order DROP CONSTRAINT shop11_order_pkey;
ALTER TABLE ONLY public.shop11_customer DROP CONSTRAINT shop11_customer_user_id_key;
ALTER TABLE ONLY public.shop11_customer DROP CONSTRAINT shop11_customer_pkey;
ALTER TABLE ONLY public.shop10_shippingaddress DROP CONSTRAINT shop10_shippingaddress_pkey;
ALTER TABLE ONLY public.shop10_product DROP CONSTRAINT shop10_product_pkey;
ALTER TABLE ONLY public.shop10_orderline DROP CONSTRAINT shop10_orderline_pkey;
ALTER TABLE ONLY public.shop10_order DROP CONSTRAINT shop10_order_pkey;
ALTER TABLE ONLY public.shop10_customer DROP CONSTRAINT shop10_customer_user_id_key;
ALTER TABLE ONLY public.shop10_customer DROP CONSTRAINT shop10_customer_pkey;
ALTER TABLE ONLY public.shop09_shippingaddress DROP CONSTRAINT shop09_shippingaddress_pkey;
ALTER TABLE ONLY public.shop09_product DROP CONSTRAINT shop09_product_pkey;
ALTER TABLE ONLY public.shop09_orderline DROP CONSTRAINT shop09_orderline_pkey;
ALTER TABLE ONLY public.shop09_order DROP CONSTRAINT shop09_order_pkey;
ALTER TABLE ONLY public.shop09_customer DROP CONSTRAINT shop09_customer_user_id_key;
ALTER TABLE ONLY public.shop09_customer DROP CONSTRAINT shop09_customer_pkey;
ALTER TABLE ONLY public.shop08_shippingaddress DROP CONSTRAINT shop08_shippingaddress_pkey;
ALTER TABLE ONLY public.shop08_product DROP CONSTRAINT shop08_product_pkey;
ALTER TABLE ONLY public.shop08_orderline DROP CONSTRAINT shop08_orderline_pkey;
ALTER TABLE ONLY public.shop08_order DROP CONSTRAINT shop08_order_pkey;
ALTER TABLE ONLY public.shop08_customer DROP CONSTRAINT shop08_customer_user_id_key;
ALTER TABLE ONLY public.shop08_customer DROP CONSTRAINT shop08_customer_pkey;
ALTER TABLE ONLY public.shop07_shippingaddress DROP CONSTRAINT shop07_shippingaddress_pkey;
ALTER TABLE ONLY public.shop07_product DROP CONSTRAINT shop07_product_pkey;
ALTER TABLE ONLY public.shop07_orderline DROP CONSTRAINT shop07_orderline_pkey;
ALTER TABLE ONLY public.shop07_order DROP CONSTRAINT shop07_order_pkey;
ALTER TABLE ONLY public.shop07_customer DROP CONSTRAINT shop07_customer_user_id_key;
ALTER TABLE ONLY public.shop07_customer DROP CONSTRAINT shop07_customer_pkey;
ALTER TABLE ONLY public.shop06_shippingaddress DROP CONSTRAINT shop06_shippingaddress_pkey;
ALTER TABLE ONLY public.shop06_product DROP CONSTRAINT shop06_product_pkey;
ALTER TABLE ONLY public.shop06_orderline DROP CONSTRAINT shop06_orderline_pkey;
ALTER TABLE ONLY public.shop06_order DROP CONSTRAINT shop06_order_pkey;
ALTER TABLE ONLY public.shop06_customer DROP CONSTRAINT shop06_customer_user_id_key;
ALTER TABLE ONLY public.shop06_customer DROP CONSTRAINT shop06_customer_pkey;
ALTER TABLE ONLY public.shop05_shippingaddress DROP CONSTRAINT shop05_shippingaddress_pkey;
ALTER TABLE ONLY public.shop05_product DROP CONSTRAINT shop05_product_pkey;
ALTER TABLE ONLY public.shop05_orderline DROP CONSTRAINT shop05_orderline_pkey;
ALTER TABLE ONLY public.shop05_order DROP CONSTRAINT shop05_order_pkey;
ALTER TABLE ONLY public.shop05_customer DROP CONSTRAINT shop05_customer_user_id_key;
ALTER TABLE ONLY public.shop05_customer DROP CONSTRAINT shop05_customer_pkey;
ALTER TABLE ONLY public.shop04_shippingaddress DROP CONSTRAINT shop04_shippingaddress_pkey;
ALTER TABLE ONLY public.shop04_product DROP CONSTRAINT shop04_product_pkey;
ALTER TABLE ONLY public.shop04_orderline DROP CONSTRAINT shop04_orderline_pkey;
ALTER TABLE ONLY public.shop04_order DROP CONSTRAINT shop04_order_pkey;
ALTER TABLE ONLY public.shop04_customer DROP CONSTRAINT shop04_customer_user_id_key;
ALTER TABLE ONLY public.shop04_customer DROP CONSTRAINT shop04_customer_pkey;
ALTER TABLE ONLY public.shop03_shippingaddress DROP CONSTRAINT shop03_shippingaddress_pkey;
ALTER TABLE ONLY public.shop03_product DROP CONSTRAINT shop03_product_pkey;
ALTER TABLE ONLY public.shop03_orderline DROP CONSTRAINT shop03_orderline_pkey;
ALTER TABLE ONLY public.shop03_order DROP CONSTRAINT shop03_order_pkey;
ALTER TABLE ONLY public.shop03_customer DROP CONSTRAINT shop03_customer_user_id_key;
ALTER TABLE ONLY public.shop03_customer DROP CONSTRAINT shop03_customer_pkey;
ALTER TABLE ONLY public.shop02_shippingaddress DROP CONSTRAINT shop02_shippingaddress_pkey;
ALTER TABLE ONLY public.shop02_product DROP CONSTRAINT shop02_product_pkey;
ALTER TABLE ONLY public.shop02_orderline DROP CONSTRAINT shop02_orderline_pkey;
ALTER TABLE ONLY public.shop02_order DROP CONSTRAINT shop02_order_pkey;
ALTER TABLE ONLY public.shop02_customer DROP CONSTRAINT shop02_customer_user_id_key;
ALTER TABLE ONLY public.shop02_customer DROP CONSTRAINT shop02_customer_pkey;
ALTER TABLE ONLY public.shop01_shippingaddress DROP CONSTRAINT shop01_shippingaddress_pkey;
ALTER TABLE ONLY public.shop01_product DROP CONSTRAINT shop01_product_pkey;
ALTER TABLE ONLY public.shop01_orderline DROP CONSTRAINT shop01_orderline_pkey;
ALTER TABLE ONLY public.shop01_order DROP CONSTRAINT shop01_order_pkey;
ALTER TABLE ONLY public.shop01_customer DROP CONSTRAINT shop01_customer_user_id_key;
ALTER TABLE ONLY public.shop01_customer DROP CONSTRAINT shop01_customer_pkey;
ALTER TABLE ONLY public.main_tweet DROP CONSTRAINT main_tweet_pkey;
ALTER TABLE ONLY public.main_like DROP CONSTRAINT main_like_tweet_id_created_by_id_f64e321e_uniq;
ALTER TABLE ONLY public.main_like DROP CONSTRAINT main_like_pkey;
ALTER TABLE ONLY public.main_follow DROP CONSTRAINT main_follow_pkey;
ALTER TABLE ONLY public.django_session DROP CONSTRAINT django_session_pkey;
ALTER TABLE ONLY public.django_migrations DROP CONSTRAINT django_migrations_pkey;
ALTER TABLE ONLY public.django_content_type DROP CONSTRAINT django_content_type_pkey;
ALTER TABLE ONLY public.django_content_type DROP CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_pkey;
ALTER TABLE ONLY public.auth_user DROP CONSTRAINT auth_user_username_key;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_pkey;
ALTER TABLE ONLY public.auth_user DROP CONSTRAINT auth_user_pkey;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_pkey;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_pkey;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq;
ALTER TABLE ONLY public.auth_group DROP CONSTRAINT auth_group_pkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_pkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq;
ALTER TABLE ONLY public.auth_group DROP CONSTRAINT auth_group_name_key;
DROP TABLE public.shop_shippingaddress;
DROP TABLE public.shop_product;
DROP TABLE public.shop_orderline;
DROP TABLE public.shop_order;
DROP TABLE public.shop_customer;
DROP TABLE public.shop20_shippingaddress;
DROP TABLE public.shop20_product;
DROP TABLE public.shop20_orderline;
DROP TABLE public.shop20_order;
DROP TABLE public.shop20_customer;
DROP TABLE public.shop19_shippingaddress;
DROP TABLE public.shop19_product;
DROP TABLE public.shop19_orderline;
DROP TABLE public.shop19_order;
DROP TABLE public.shop19_customer;
DROP TABLE public.shop18_shippingaddress;
DROP TABLE public.shop18_product;
DROP TABLE public.shop18_orderline;
DROP TABLE public.shop18_order;
DROP TABLE public.shop18_customer;
DROP TABLE public.shop17_shippingaddress;
DROP TABLE public.shop17_product;
DROP TABLE public.shop17_orderline;
DROP TABLE public.shop17_order;
DROP TABLE public.shop17_customer;
DROP TABLE public.shop16_shippingaddress;
DROP TABLE public.shop16_product;
DROP TABLE public.shop16_orderline;
DROP TABLE public.shop16_order;
DROP TABLE public.shop16_customer;
DROP TABLE public.shop15_shippingaddress;
DROP TABLE public.shop15_product;
DROP TABLE public.shop15_orderline;
DROP TABLE public.shop15_order;
DROP TABLE public.shop15_customer;
DROP TABLE public.shop14_shippingaddress;
DROP TABLE public.shop14_product;
DROP TABLE public.shop14_orderline;
DROP TABLE public.shop14_order;
DROP TABLE public.shop14_customer;
DROP TABLE public.shop13_shippingaddress;
DROP TABLE public.shop13_product;
DROP TABLE public.shop13_orderline;
DROP TABLE public.shop13_order;
DROP TABLE public.shop13_customer;
DROP TABLE public.shop12_shippingaddress;
DROP TABLE public.shop12_product;
DROP TABLE public.shop12_orderline;
DROP TABLE public.shop12_order;
DROP TABLE public.shop12_customer;
DROP TABLE public.shop11_shippingaddress;
DROP TABLE public.shop11_product;
DROP TABLE public.shop11_orderline;
DROP TABLE public.shop11_order;
DROP TABLE public.shop11_customer;
DROP TABLE public.shop10_shippingaddress;
DROP TABLE public.shop10_product;
DROP TABLE public.shop10_orderline;
DROP TABLE public.shop10_order;
DROP TABLE public.shop10_customer;
DROP TABLE public.shop09_shippingaddress;
DROP TABLE public.shop09_product;
DROP TABLE public.shop09_orderline;
DROP TABLE public.shop09_order;
DROP TABLE public.shop09_customer;
DROP TABLE public.shop08_shippingaddress;
DROP TABLE public.shop08_product;
DROP TABLE public.shop08_orderline;
DROP TABLE public.shop08_order;
DROP TABLE public.shop08_customer;
DROP TABLE public.shop07_shippingaddress;
DROP TABLE public.shop07_product;
DROP TABLE public.shop07_orderline;
DROP TABLE public.shop07_order;
DROP TABLE public.shop07_customer;
DROP TABLE public.shop06_shippingaddress;
DROP TABLE public.shop06_product;
DROP TABLE public.shop06_orderline;
DROP TABLE public.shop06_order;
DROP TABLE public.shop06_customer;
DROP TABLE public.shop05_shippingaddress;
DROP TABLE public.shop05_product;
DROP TABLE public.shop05_orderline;
DROP TABLE public.shop05_order;
DROP TABLE public.shop05_customer;
DROP TABLE public.shop04_shippingaddress;
DROP TABLE public.shop04_product;
DROP TABLE public.shop04_orderline;
DROP TABLE public.shop04_order;
DROP TABLE public.shop04_customer;
DROP TABLE public.shop03_shippingaddress;
DROP TABLE public.shop03_product;
DROP TABLE public.shop03_orderline;
DROP TABLE public.shop03_order;
DROP TABLE public.shop03_customer;
DROP TABLE public.shop02_shippingaddress;
DROP TABLE public.shop02_product;
DROP TABLE public.shop02_orderline;
DROP TABLE public.shop02_order;
DROP TABLE public.shop02_customer;
DROP TABLE public.shop01_shippingaddress;
DROP TABLE public.shop01_product;
DROP TABLE public.shop01_orderline;
DROP TABLE public.shop01_order;
DROP TABLE public.shop01_customer;
DROP TABLE public.main_tweet;
DROP TABLE public.main_like;
DROP TABLE public.main_follow;
DROP TABLE public.django_session;
DROP TABLE public.django_migrations;
DROP TABLE public.django_content_type;
DROP TABLE public.django_admin_log;
DROP TABLE public.auth_user_user_permissions;
DROP TABLE public.auth_user_groups;
DROP TABLE public.auth_user;
DROP TABLE public.auth_permission;
DROP TABLE public.auth_group_permissions;
DROP TABLE public.auth_group;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.auth_group ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_group_permissions (
    id bigint NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.auth_group_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.auth_permission ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(150) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_user_groups (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.auth_user_groups ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.auth_user ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_user_user_permissions (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.auth_user_user_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.django_admin_log ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.django_content_type ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_migrations (
    id bigint NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.django_migrations ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


--
-- Name: main_follow; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.main_follow (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    created_by_id integer NOT NULL,
    user_followed_id integer NOT NULL
);


--
-- Name: main_follow_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.main_follow ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.main_follow_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: main_like; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.main_like (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    created_by_id integer NOT NULL,
    tweet_id bigint NOT NULL
);


--
-- Name: main_like_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.main_like ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.main_like_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: main_tweet; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.main_tweet (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    text character varying(250) NOT NULL,
    created_by_id integer NOT NULL,
    related_tweet_id bigint
);


--
-- Name: main_tweet_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.main_tweet ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.main_tweet_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop01_customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop01_customer (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    customer_type integer NOT NULL
);


--
-- Name: shop01_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop01_customer ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop01_customer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop01_order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop01_order (
    id bigint NOT NULL,
    shipping_name character varying(200) NOT NULL,
    shipping_address character varying(100) NOT NULL,
    shipping_zip_code character varying(10) NOT NULL,
    shipping_city character varying(100) NOT NULL,
    shipping_province character varying(5) NOT NULL,
    shipping_state character varying(50) NOT NULL,
    customer_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: shop01_order_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop01_order ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop01_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop01_orderline; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop01_orderline (
    id bigint NOT NULL,
    product_name character varying(100) NOT NULL,
    product_um character varying(10) NOT NULL,
    quantity double precision NOT NULL,
    product_unit_price double precision NOT NULL,
    order_id bigint NOT NULL
);


--
-- Name: shop01_orderline_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop01_orderline ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop01_orderline_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop01_product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop01_product (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    um character varying(10) NOT NULL,
    unit_price double precision NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop01_product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop01_product ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop01_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop01_shippingaddress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop01_shippingaddress (
    id bigint NOT NULL,
    name character varying(200) NOT NULL,
    address character varying(100) NOT NULL,
    zip_code character varying(10) NOT NULL,
    city character varying(100) NOT NULL,
    province character varying(5) NOT NULL,
    state character varying(50) NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop01_shippingaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop01_shippingaddress ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop01_shippingaddress_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop02_customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop02_customer (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    customer_type integer NOT NULL
);


--
-- Name: shop02_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop02_customer ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop02_customer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop02_order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop02_order (
    id bigint NOT NULL,
    shipping_name character varying(200) NOT NULL,
    shipping_address character varying(100) NOT NULL,
    shipping_zip_code character varying(10) NOT NULL,
    shipping_city character varying(100) NOT NULL,
    shipping_province character varying(5) NOT NULL,
    shipping_state character varying(50) NOT NULL,
    customer_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: shop02_order_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop02_order ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop02_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop02_orderline; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop02_orderline (
    id bigint NOT NULL,
    product_name character varying(100) NOT NULL,
    product_um character varying(10) NOT NULL,
    quantity double precision NOT NULL,
    product_unit_price double precision NOT NULL,
    order_id bigint NOT NULL
);


--
-- Name: shop02_orderline_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop02_orderline ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop02_orderline_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop02_product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop02_product (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    um character varying(10) NOT NULL,
    unit_price double precision NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop02_product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop02_product ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop02_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop02_shippingaddress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop02_shippingaddress (
    id bigint NOT NULL,
    name character varying(200) NOT NULL,
    address character varying(100) NOT NULL,
    zip_code character varying(10) NOT NULL,
    city character varying(100) NOT NULL,
    province character varying(5) NOT NULL,
    state character varying(50) NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop02_shippingaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop02_shippingaddress ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop02_shippingaddress_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop03_customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop03_customer (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    customer_type integer NOT NULL
);


--
-- Name: shop03_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop03_customer ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop03_customer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop03_order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop03_order (
    id bigint NOT NULL,
    shipping_name character varying(200) NOT NULL,
    shipping_address character varying(100) NOT NULL,
    shipping_zip_code character varying(10) NOT NULL,
    shipping_city character varying(100) NOT NULL,
    shipping_province character varying(5) NOT NULL,
    shipping_state character varying(50) NOT NULL,
    customer_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: shop03_order_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop03_order ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop03_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop03_orderline; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop03_orderline (
    id bigint NOT NULL,
    product_name character varying(100) NOT NULL,
    product_um character varying(10) NOT NULL,
    quantity double precision NOT NULL,
    product_unit_price double precision NOT NULL,
    order_id bigint NOT NULL
);


--
-- Name: shop03_orderline_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop03_orderline ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop03_orderline_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop03_product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop03_product (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    um character varying(10) NOT NULL,
    unit_price double precision NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop03_product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop03_product ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop03_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop03_shippingaddress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop03_shippingaddress (
    id bigint NOT NULL,
    name character varying(200) NOT NULL,
    address character varying(100) NOT NULL,
    zip_code character varying(10) NOT NULL,
    city character varying(100) NOT NULL,
    province character varying(5) NOT NULL,
    state character varying(50) NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop03_shippingaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop03_shippingaddress ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop03_shippingaddress_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop04_customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop04_customer (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    customer_type integer NOT NULL
);


--
-- Name: shop04_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop04_customer ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop04_customer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop04_order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop04_order (
    id bigint NOT NULL,
    shipping_name character varying(200) NOT NULL,
    shipping_address character varying(100) NOT NULL,
    shipping_zip_code character varying(10) NOT NULL,
    shipping_city character varying(100) NOT NULL,
    shipping_province character varying(5) NOT NULL,
    shipping_state character varying(50) NOT NULL,
    customer_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: shop04_order_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop04_order ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop04_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop04_orderline; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop04_orderline (
    id bigint NOT NULL,
    product_name character varying(100) NOT NULL,
    product_um character varying(10) NOT NULL,
    quantity double precision NOT NULL,
    product_unit_price double precision NOT NULL,
    order_id bigint NOT NULL
);


--
-- Name: shop04_orderline_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop04_orderline ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop04_orderline_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop04_product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop04_product (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    um character varying(10) NOT NULL,
    unit_price double precision NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop04_product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop04_product ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop04_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop04_shippingaddress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop04_shippingaddress (
    id bigint NOT NULL,
    name character varying(200) NOT NULL,
    address character varying(100) NOT NULL,
    zip_code character varying(10) NOT NULL,
    city character varying(100) NOT NULL,
    province character varying(5) NOT NULL,
    state character varying(50) NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop04_shippingaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop04_shippingaddress ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop04_shippingaddress_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop05_customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop05_customer (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    customer_type integer NOT NULL
);


--
-- Name: shop05_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop05_customer ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop05_customer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop05_order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop05_order (
    id bigint NOT NULL,
    shipping_name character varying(200) NOT NULL,
    shipping_address character varying(100) NOT NULL,
    shipping_zip_code character varying(10) NOT NULL,
    shipping_city character varying(100) NOT NULL,
    shipping_province character varying(5) NOT NULL,
    shipping_state character varying(50) NOT NULL,
    customer_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: shop05_order_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop05_order ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop05_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop05_orderline; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop05_orderline (
    id bigint NOT NULL,
    product_name character varying(100) NOT NULL,
    product_um character varying(10) NOT NULL,
    quantity double precision NOT NULL,
    product_unit_price double precision NOT NULL,
    order_id bigint NOT NULL
);


--
-- Name: shop05_orderline_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop05_orderline ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop05_orderline_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop05_product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop05_product (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    um character varying(10) NOT NULL,
    unit_price double precision NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop05_product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop05_product ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop05_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop05_shippingaddress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop05_shippingaddress (
    id bigint NOT NULL,
    name character varying(200) NOT NULL,
    address character varying(100) NOT NULL,
    zip_code character varying(10) NOT NULL,
    city character varying(100) NOT NULL,
    province character varying(5) NOT NULL,
    state character varying(50) NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop05_shippingaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop05_shippingaddress ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop05_shippingaddress_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop06_customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop06_customer (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    customer_type integer NOT NULL
);


--
-- Name: shop06_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop06_customer ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop06_customer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop06_order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop06_order (
    id bigint NOT NULL,
    shipping_name character varying(200) NOT NULL,
    shipping_address character varying(100) NOT NULL,
    shipping_zip_code character varying(10) NOT NULL,
    shipping_city character varying(100) NOT NULL,
    shipping_province character varying(5) NOT NULL,
    shipping_state character varying(50) NOT NULL,
    customer_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: shop06_order_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop06_order ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop06_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop06_orderline; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop06_orderline (
    id bigint NOT NULL,
    product_name character varying(100) NOT NULL,
    product_um character varying(10) NOT NULL,
    quantity double precision NOT NULL,
    product_unit_price double precision NOT NULL,
    order_id bigint NOT NULL
);


--
-- Name: shop06_orderline_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop06_orderline ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop06_orderline_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop06_product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop06_product (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    um character varying(10) NOT NULL,
    unit_price double precision NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop06_product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop06_product ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop06_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop06_shippingaddress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop06_shippingaddress (
    id bigint NOT NULL,
    name character varying(200) NOT NULL,
    address character varying(100) NOT NULL,
    zip_code character varying(10) NOT NULL,
    city character varying(100) NOT NULL,
    province character varying(5) NOT NULL,
    state character varying(50) NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop06_shippingaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop06_shippingaddress ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop06_shippingaddress_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop07_customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop07_customer (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    customer_type integer NOT NULL
);


--
-- Name: shop07_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop07_customer ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop07_customer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop07_order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop07_order (
    id bigint NOT NULL,
    shipping_name character varying(200) NOT NULL,
    shipping_address character varying(100) NOT NULL,
    shipping_zip_code character varying(10) NOT NULL,
    shipping_city character varying(100) NOT NULL,
    shipping_province character varying(5) NOT NULL,
    shipping_state character varying(50) NOT NULL,
    customer_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: shop07_order_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop07_order ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop07_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop07_orderline; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop07_orderline (
    id bigint NOT NULL,
    product_name character varying(100) NOT NULL,
    product_um character varying(10) NOT NULL,
    quantity double precision NOT NULL,
    product_unit_price double precision NOT NULL,
    order_id bigint NOT NULL
);


--
-- Name: shop07_orderline_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop07_orderline ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop07_orderline_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop07_product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop07_product (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    um character varying(10) NOT NULL,
    unit_price double precision NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop07_product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop07_product ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop07_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop07_shippingaddress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop07_shippingaddress (
    id bigint NOT NULL,
    name character varying(200) NOT NULL,
    address character varying(100) NOT NULL,
    zip_code character varying(10) NOT NULL,
    city character varying(100) NOT NULL,
    province character varying(5) NOT NULL,
    state character varying(50) NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop07_shippingaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop07_shippingaddress ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop07_shippingaddress_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop08_customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop08_customer (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    customer_type integer NOT NULL
);


--
-- Name: shop08_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop08_customer ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop08_customer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop08_order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop08_order (
    id bigint NOT NULL,
    shipping_name character varying(200) NOT NULL,
    shipping_address character varying(100) NOT NULL,
    shipping_zip_code character varying(10) NOT NULL,
    shipping_city character varying(100) NOT NULL,
    shipping_province character varying(5) NOT NULL,
    shipping_state character varying(50) NOT NULL,
    customer_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: shop08_order_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop08_order ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop08_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop08_orderline; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop08_orderline (
    id bigint NOT NULL,
    product_name character varying(100) NOT NULL,
    product_um character varying(10) NOT NULL,
    quantity double precision NOT NULL,
    product_unit_price double precision NOT NULL,
    order_id bigint NOT NULL
);


--
-- Name: shop08_orderline_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop08_orderline ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop08_orderline_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop08_product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop08_product (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    um character varying(10) NOT NULL,
    unit_price double precision NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop08_product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop08_product ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop08_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop08_shippingaddress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop08_shippingaddress (
    id bigint NOT NULL,
    name character varying(200) NOT NULL,
    address character varying(100) NOT NULL,
    zip_code character varying(10) NOT NULL,
    city character varying(100) NOT NULL,
    province character varying(5) NOT NULL,
    state character varying(50) NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop08_shippingaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop08_shippingaddress ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop08_shippingaddress_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop09_customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop09_customer (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    customer_type integer NOT NULL
);


--
-- Name: shop09_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop09_customer ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop09_customer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop09_order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop09_order (
    id bigint NOT NULL,
    shipping_name character varying(200) NOT NULL,
    shipping_address character varying(100) NOT NULL,
    shipping_zip_code character varying(10) NOT NULL,
    shipping_city character varying(100) NOT NULL,
    shipping_province character varying(5) NOT NULL,
    shipping_state character varying(50) NOT NULL,
    customer_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: shop09_order_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop09_order ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop09_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop09_orderline; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop09_orderline (
    id bigint NOT NULL,
    product_name character varying(100) NOT NULL,
    product_um character varying(10) NOT NULL,
    quantity double precision NOT NULL,
    product_unit_price double precision NOT NULL,
    order_id bigint NOT NULL
);


--
-- Name: shop09_orderline_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop09_orderline ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop09_orderline_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop09_product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop09_product (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    um character varying(10) NOT NULL,
    unit_price double precision NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop09_product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop09_product ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop09_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop09_shippingaddress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop09_shippingaddress (
    id bigint NOT NULL,
    name character varying(200) NOT NULL,
    address character varying(100) NOT NULL,
    zip_code character varying(10) NOT NULL,
    city character varying(100) NOT NULL,
    province character varying(5) NOT NULL,
    state character varying(50) NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop09_shippingaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop09_shippingaddress ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop09_shippingaddress_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop10_customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop10_customer (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    customer_type integer NOT NULL
);


--
-- Name: shop10_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop10_customer ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop10_customer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop10_order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop10_order (
    id bigint NOT NULL,
    shipping_name character varying(200) NOT NULL,
    shipping_address character varying(100) NOT NULL,
    shipping_zip_code character varying(10) NOT NULL,
    shipping_city character varying(100) NOT NULL,
    shipping_province character varying(5) NOT NULL,
    shipping_state character varying(50) NOT NULL,
    customer_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: shop10_order_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop10_order ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop10_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop10_orderline; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop10_orderline (
    id bigint NOT NULL,
    product_name character varying(100) NOT NULL,
    product_um character varying(10) NOT NULL,
    quantity double precision NOT NULL,
    product_unit_price double precision NOT NULL,
    order_id bigint NOT NULL
);


--
-- Name: shop10_orderline_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop10_orderline ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop10_orderline_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop10_product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop10_product (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    um character varying(10) NOT NULL,
    unit_price double precision NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop10_product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop10_product ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop10_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop10_shippingaddress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop10_shippingaddress (
    id bigint NOT NULL,
    name character varying(200) NOT NULL,
    address character varying(100) NOT NULL,
    zip_code character varying(10) NOT NULL,
    city character varying(100) NOT NULL,
    province character varying(5) NOT NULL,
    state character varying(50) NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop10_shippingaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop10_shippingaddress ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop10_shippingaddress_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop11_customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop11_customer (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    customer_type integer NOT NULL
);


--
-- Name: shop11_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop11_customer ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop11_customer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop11_order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop11_order (
    id bigint NOT NULL,
    shipping_name character varying(200) NOT NULL,
    shipping_address character varying(100) NOT NULL,
    shipping_zip_code character varying(10) NOT NULL,
    shipping_city character varying(100) NOT NULL,
    shipping_province character varying(5) NOT NULL,
    shipping_state character varying(50) NOT NULL,
    customer_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: shop11_order_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop11_order ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop11_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop11_orderline; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop11_orderline (
    id bigint NOT NULL,
    product_name character varying(100) NOT NULL,
    product_um character varying(10) NOT NULL,
    quantity double precision NOT NULL,
    product_unit_price double precision NOT NULL,
    order_id bigint NOT NULL
);


--
-- Name: shop11_orderline_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop11_orderline ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop11_orderline_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop11_product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop11_product (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    um character varying(10) NOT NULL,
    unit_price double precision NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop11_product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop11_product ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop11_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop11_shippingaddress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop11_shippingaddress (
    id bigint NOT NULL,
    name character varying(200) NOT NULL,
    address character varying(100) NOT NULL,
    zip_code character varying(10) NOT NULL,
    city character varying(100) NOT NULL,
    province character varying(5) NOT NULL,
    state character varying(50) NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop11_shippingaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop11_shippingaddress ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop11_shippingaddress_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop12_customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop12_customer (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    customer_type integer NOT NULL
);


--
-- Name: shop12_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop12_customer ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop12_customer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop12_order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop12_order (
    id bigint NOT NULL,
    shipping_name character varying(200) NOT NULL,
    shipping_address character varying(100) NOT NULL,
    shipping_zip_code character varying(10) NOT NULL,
    shipping_city character varying(100) NOT NULL,
    shipping_province character varying(5) NOT NULL,
    shipping_state character varying(50) NOT NULL,
    customer_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: shop12_order_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop12_order ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop12_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop12_orderline; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop12_orderline (
    id bigint NOT NULL,
    product_name character varying(100) NOT NULL,
    product_um character varying(10) NOT NULL,
    quantity double precision NOT NULL,
    product_unit_price double precision NOT NULL,
    order_id bigint NOT NULL
);


--
-- Name: shop12_orderline_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop12_orderline ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop12_orderline_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop12_product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop12_product (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    um character varying(10) NOT NULL,
    unit_price double precision NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop12_product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop12_product ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop12_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop12_shippingaddress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop12_shippingaddress (
    id bigint NOT NULL,
    name character varying(200) NOT NULL,
    address character varying(100) NOT NULL,
    zip_code character varying(10) NOT NULL,
    city character varying(100) NOT NULL,
    province character varying(5) NOT NULL,
    state character varying(50) NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop12_shippingaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop12_shippingaddress ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop12_shippingaddress_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop13_customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop13_customer (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    customer_type integer NOT NULL
);


--
-- Name: shop13_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop13_customer ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop13_customer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop13_order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop13_order (
    id bigint NOT NULL,
    shipping_name character varying(200) NOT NULL,
    shipping_address character varying(100) NOT NULL,
    shipping_zip_code character varying(10) NOT NULL,
    shipping_city character varying(100) NOT NULL,
    shipping_province character varying(5) NOT NULL,
    shipping_state character varying(50) NOT NULL,
    customer_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: shop13_order_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop13_order ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop13_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop13_orderline; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop13_orderline (
    id bigint NOT NULL,
    product_name character varying(100) NOT NULL,
    product_um character varying(10) NOT NULL,
    quantity double precision NOT NULL,
    product_unit_price double precision NOT NULL,
    order_id bigint NOT NULL
);


--
-- Name: shop13_orderline_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop13_orderline ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop13_orderline_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop13_product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop13_product (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    um character varying(10) NOT NULL,
    unit_price double precision NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop13_product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop13_product ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop13_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop13_shippingaddress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop13_shippingaddress (
    id bigint NOT NULL,
    name character varying(200) NOT NULL,
    address character varying(100) NOT NULL,
    zip_code character varying(10) NOT NULL,
    city character varying(100) NOT NULL,
    province character varying(5) NOT NULL,
    state character varying(50) NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop13_shippingaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop13_shippingaddress ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop13_shippingaddress_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop14_customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop14_customer (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    customer_type integer NOT NULL
);


--
-- Name: shop14_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop14_customer ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop14_customer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop14_order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop14_order (
    id bigint NOT NULL,
    shipping_name character varying(200) NOT NULL,
    shipping_address character varying(100) NOT NULL,
    shipping_zip_code character varying(10) NOT NULL,
    shipping_city character varying(100) NOT NULL,
    shipping_province character varying(5) NOT NULL,
    shipping_state character varying(50) NOT NULL,
    customer_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: shop14_order_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop14_order ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop14_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop14_orderline; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop14_orderline (
    id bigint NOT NULL,
    product_name character varying(100) NOT NULL,
    product_um character varying(10) NOT NULL,
    quantity double precision NOT NULL,
    product_unit_price double precision NOT NULL,
    order_id bigint NOT NULL
);


--
-- Name: shop14_orderline_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop14_orderline ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop14_orderline_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop14_product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop14_product (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    um character varying(10) NOT NULL,
    unit_price double precision NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop14_product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop14_product ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop14_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop14_shippingaddress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop14_shippingaddress (
    id bigint NOT NULL,
    name character varying(200) NOT NULL,
    address character varying(100) NOT NULL,
    zip_code character varying(10) NOT NULL,
    city character varying(100) NOT NULL,
    province character varying(5) NOT NULL,
    state character varying(50) NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop14_shippingaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop14_shippingaddress ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop14_shippingaddress_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop15_customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop15_customer (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    customer_type integer NOT NULL
);


--
-- Name: shop15_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop15_customer ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop15_customer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop15_order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop15_order (
    id bigint NOT NULL,
    shipping_name character varying(200) NOT NULL,
    shipping_address character varying(100) NOT NULL,
    shipping_zip_code character varying(10) NOT NULL,
    shipping_city character varying(100) NOT NULL,
    shipping_province character varying(5) NOT NULL,
    shipping_state character varying(50) NOT NULL,
    customer_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: shop15_order_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop15_order ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop15_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop15_orderline; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop15_orderline (
    id bigint NOT NULL,
    product_name character varying(100) NOT NULL,
    product_um character varying(10) NOT NULL,
    quantity double precision NOT NULL,
    product_unit_price double precision NOT NULL,
    order_id bigint NOT NULL
);


--
-- Name: shop15_orderline_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop15_orderline ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop15_orderline_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop15_product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop15_product (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    um character varying(10) NOT NULL,
    unit_price double precision NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop15_product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop15_product ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop15_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop15_shippingaddress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop15_shippingaddress (
    id bigint NOT NULL,
    name character varying(200) NOT NULL,
    address character varying(100) NOT NULL,
    zip_code character varying(10) NOT NULL,
    city character varying(100) NOT NULL,
    province character varying(5) NOT NULL,
    state character varying(50) NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop15_shippingaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop15_shippingaddress ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop15_shippingaddress_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop16_customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop16_customer (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    customer_type integer NOT NULL
);


--
-- Name: shop16_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop16_customer ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop16_customer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop16_order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop16_order (
    id bigint NOT NULL,
    shipping_name character varying(200) NOT NULL,
    shipping_address character varying(100) NOT NULL,
    shipping_zip_code character varying(10) NOT NULL,
    shipping_city character varying(100) NOT NULL,
    shipping_province character varying(5) NOT NULL,
    shipping_state character varying(50) NOT NULL,
    customer_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: shop16_order_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop16_order ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop16_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop16_orderline; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop16_orderline (
    id bigint NOT NULL,
    product_name character varying(100) NOT NULL,
    product_um character varying(10) NOT NULL,
    quantity double precision NOT NULL,
    product_unit_price double precision NOT NULL,
    order_id bigint NOT NULL
);


--
-- Name: shop16_orderline_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop16_orderline ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop16_orderline_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop16_product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop16_product (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    um character varying(10) NOT NULL,
    unit_price double precision NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop16_product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop16_product ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop16_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop16_shippingaddress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop16_shippingaddress (
    id bigint NOT NULL,
    name character varying(200) NOT NULL,
    address character varying(100) NOT NULL,
    zip_code character varying(10) NOT NULL,
    city character varying(100) NOT NULL,
    province character varying(5) NOT NULL,
    state character varying(50) NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop16_shippingaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop16_shippingaddress ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop16_shippingaddress_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop17_customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop17_customer (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    customer_type integer NOT NULL
);


--
-- Name: shop17_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop17_customer ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop17_customer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop17_order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop17_order (
    id bigint NOT NULL,
    shipping_name character varying(200) NOT NULL,
    shipping_address character varying(100) NOT NULL,
    shipping_zip_code character varying(10) NOT NULL,
    shipping_city character varying(100) NOT NULL,
    shipping_province character varying(5) NOT NULL,
    shipping_state character varying(50) NOT NULL,
    customer_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: shop17_order_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop17_order ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop17_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop17_orderline; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop17_orderline (
    id bigint NOT NULL,
    product_name character varying(100) NOT NULL,
    product_um character varying(10) NOT NULL,
    quantity double precision NOT NULL,
    product_unit_price double precision NOT NULL,
    order_id bigint NOT NULL
);


--
-- Name: shop17_orderline_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop17_orderline ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop17_orderline_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop17_product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop17_product (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    um character varying(10) NOT NULL,
    unit_price double precision NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop17_product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop17_product ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop17_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop17_shippingaddress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop17_shippingaddress (
    id bigint NOT NULL,
    name character varying(200) NOT NULL,
    address character varying(100) NOT NULL,
    zip_code character varying(10) NOT NULL,
    city character varying(100) NOT NULL,
    province character varying(5) NOT NULL,
    state character varying(50) NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop17_shippingaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop17_shippingaddress ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop17_shippingaddress_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop18_customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop18_customer (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    customer_type integer NOT NULL
);


--
-- Name: shop18_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop18_customer ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop18_customer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop18_order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop18_order (
    id bigint NOT NULL,
    shipping_name character varying(200) NOT NULL,
    shipping_address character varying(100) NOT NULL,
    shipping_zip_code character varying(10) NOT NULL,
    shipping_city character varying(100) NOT NULL,
    shipping_province character varying(5) NOT NULL,
    shipping_state character varying(50) NOT NULL,
    customer_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: shop18_order_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop18_order ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop18_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop18_orderline; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop18_orderline (
    id bigint NOT NULL,
    product_name character varying(100) NOT NULL,
    product_um character varying(10) NOT NULL,
    quantity double precision NOT NULL,
    product_unit_price double precision NOT NULL,
    order_id bigint NOT NULL
);


--
-- Name: shop18_orderline_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop18_orderline ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop18_orderline_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop18_product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop18_product (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    um character varying(10) NOT NULL,
    unit_price double precision NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop18_product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop18_product ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop18_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop18_shippingaddress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop18_shippingaddress (
    id bigint NOT NULL,
    name character varying(200) NOT NULL,
    address character varying(100) NOT NULL,
    zip_code character varying(10) NOT NULL,
    city character varying(100) NOT NULL,
    province character varying(5) NOT NULL,
    state character varying(50) NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop18_shippingaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop18_shippingaddress ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop18_shippingaddress_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop19_customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop19_customer (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    customer_type integer NOT NULL
);


--
-- Name: shop19_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop19_customer ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop19_customer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop19_order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop19_order (
    id bigint NOT NULL,
    shipping_name character varying(200) NOT NULL,
    shipping_address character varying(100) NOT NULL,
    shipping_zip_code character varying(10) NOT NULL,
    shipping_city character varying(100) NOT NULL,
    shipping_province character varying(5) NOT NULL,
    shipping_state character varying(50) NOT NULL,
    customer_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: shop19_order_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop19_order ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop19_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop19_orderline; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop19_orderline (
    id bigint NOT NULL,
    product_name character varying(100) NOT NULL,
    product_um character varying(10) NOT NULL,
    quantity double precision NOT NULL,
    product_unit_price double precision NOT NULL,
    order_id bigint NOT NULL
);


--
-- Name: shop19_orderline_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop19_orderline ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop19_orderline_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop19_product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop19_product (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    um character varying(10) NOT NULL,
    unit_price double precision NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop19_product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop19_product ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop19_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop19_shippingaddress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop19_shippingaddress (
    id bigint NOT NULL,
    name character varying(200) NOT NULL,
    address character varying(100) NOT NULL,
    zip_code character varying(10) NOT NULL,
    city character varying(100) NOT NULL,
    province character varying(5) NOT NULL,
    state character varying(50) NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop19_shippingaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop19_shippingaddress ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop19_shippingaddress_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop20_customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop20_customer (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    customer_type integer NOT NULL
);


--
-- Name: shop20_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop20_customer ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop20_customer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop20_order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop20_order (
    id bigint NOT NULL,
    shipping_name character varying(200) NOT NULL,
    shipping_address character varying(100) NOT NULL,
    shipping_zip_code character varying(10) NOT NULL,
    shipping_city character varying(100) NOT NULL,
    shipping_province character varying(5) NOT NULL,
    shipping_state character varying(50) NOT NULL,
    customer_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: shop20_order_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop20_order ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop20_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop20_orderline; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop20_orderline (
    id bigint NOT NULL,
    product_name character varying(100) NOT NULL,
    product_um character varying(10) NOT NULL,
    quantity double precision NOT NULL,
    product_unit_price double precision NOT NULL,
    order_id bigint NOT NULL
);


--
-- Name: shop20_orderline_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop20_orderline ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop20_orderline_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop20_product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop20_product (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    um character varying(10) NOT NULL,
    unit_price double precision NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop20_product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop20_product ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop20_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop20_shippingaddress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop20_shippingaddress (
    id bigint NOT NULL,
    name character varying(200) NOT NULL,
    address character varying(100) NOT NULL,
    zip_code character varying(10) NOT NULL,
    city character varying(100) NOT NULL,
    province character varying(5) NOT NULL,
    state character varying(50) NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop20_shippingaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop20_shippingaddress ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop20_shippingaddress_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop_customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop_customer (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    customer_type integer NOT NULL
);


--
-- Name: shop_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop_customer ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop_customer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop_order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop_order (
    id bigint NOT NULL,
    shipping_name character varying(200) NOT NULL,
    shipping_address character varying(100) NOT NULL,
    shipping_zip_code character varying(10) NOT NULL,
    shipping_city character varying(100) NOT NULL,
    shipping_province character varying(5) NOT NULL,
    shipping_state character varying(50) NOT NULL,
    customer_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: shop_order_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop_order ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop_orderline; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop_orderline (
    id bigint NOT NULL,
    product_name character varying(100) NOT NULL,
    product_um character varying(10) NOT NULL,
    quantity double precision NOT NULL,
    product_unit_price double precision NOT NULL,
    order_id bigint NOT NULL
);


--
-- Name: shop_orderline_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop_orderline ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop_orderline_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop_product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop_product (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    um character varying(10) NOT NULL,
    unit_price double precision NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop_product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop_product ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop_shippingaddress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop_shippingaddress (
    id bigint NOT NULL,
    name character varying(200) NOT NULL,
    address character varying(100) NOT NULL,
    zip_code character varying(10) NOT NULL,
    city character varying(100) NOT NULL,
    province character varying(5) NOT NULL,
    state character varying(50) NOT NULL,
    customer_id bigint NOT NULL
);


--
-- Name: shop_shippingaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shop_shippingaddress ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shop_shippingaddress_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add tweet	1	add_tweet
2	Can change tweet	1	change_tweet
3	Can delete tweet	1	delete_tweet
4	Can view tweet	1	view_tweet
5	Can add like	2	add_like
6	Can change like	2	change_like
7	Can delete like	2	delete_like
8	Can view like	2	view_like
9	Can add follow	3	add_follow
10	Can change follow	3	change_follow
11	Can delete follow	3	delete_follow
12	Can view follow	3	view_follow
13	Can add customer	4	add_customer
14	Can change customer	4	change_customer
15	Can delete customer	4	delete_customer
16	Can view customer	4	view_customer
17	Can add shipping address	5	add_shippingaddress
18	Can change shipping address	5	change_shippingaddress
19	Can delete shipping address	5	delete_shippingaddress
20	Can view shipping address	5	view_shippingaddress
21	Can add order	6	add_order
22	Can change order	6	change_order
23	Can delete order	6	delete_order
24	Can view order	6	view_order
25	Can add order line	7	add_orderline
26	Can change order line	7	change_orderline
27	Can delete order line	7	delete_orderline
28	Can view order line	7	view_orderline
29	Can add product	8	add_product
30	Can change product	8	change_product
31	Can delete product	8	delete_product
32	Can view product	8	view_product
33	Can add customer	9	add_customer
34	Can change customer	9	change_customer
35	Can delete customer	9	delete_customer
36	Can view customer	9	view_customer
37	Can add shipping address	10	add_shippingaddress
38	Can change shipping address	10	change_shippingaddress
39	Can delete shipping address	10	delete_shippingaddress
40	Can view shipping address	10	view_shippingaddress
41	Can add order	11	add_order
42	Can change order	11	change_order
43	Can delete order	11	delete_order
44	Can view order	11	view_order
45	Can add order line	12	add_orderline
46	Can change order line	12	change_orderline
47	Can delete order line	12	delete_orderline
48	Can view order line	12	view_orderline
49	Can add product	13	add_product
50	Can change product	13	change_product
51	Can delete product	13	delete_product
52	Can view product	13	view_product
53	Can add customer	14	add_customer
54	Can change customer	14	change_customer
55	Can delete customer	14	delete_customer
56	Can view customer	14	view_customer
57	Can add shipping address	15	add_shippingaddress
58	Can change shipping address	15	change_shippingaddress
59	Can delete shipping address	15	delete_shippingaddress
60	Can view shipping address	15	view_shippingaddress
61	Can add order	16	add_order
62	Can change order	16	change_order
63	Can delete order	16	delete_order
64	Can view order	16	view_order
65	Can add order line	17	add_orderline
66	Can change order line	17	change_orderline
67	Can delete order line	17	delete_orderline
68	Can view order line	17	view_orderline
69	Can add product	18	add_product
70	Can change product	18	change_product
71	Can delete product	18	delete_product
72	Can view product	18	view_product
73	Can add customer	19	add_customer
74	Can change customer	19	change_customer
75	Can delete customer	19	delete_customer
76	Can view customer	19	view_customer
77	Can add shipping address	20	add_shippingaddress
78	Can change shipping address	20	change_shippingaddress
79	Can delete shipping address	20	delete_shippingaddress
80	Can view shipping address	20	view_shippingaddress
81	Can add order	21	add_order
82	Can change order	21	change_order
83	Can delete order	21	delete_order
84	Can view order	21	view_order
85	Can add order line	22	add_orderline
86	Can change order line	22	change_orderline
87	Can delete order line	22	delete_orderline
88	Can view order line	22	view_orderline
89	Can add product	23	add_product
90	Can change product	23	change_product
91	Can delete product	23	delete_product
92	Can view product	23	view_product
93	Can add customer	24	add_customer
94	Can change customer	24	change_customer
95	Can delete customer	24	delete_customer
96	Can view customer	24	view_customer
97	Can add shipping address	25	add_shippingaddress
98	Can change shipping address	25	change_shippingaddress
99	Can delete shipping address	25	delete_shippingaddress
100	Can view shipping address	25	view_shippingaddress
101	Can add order	26	add_order
102	Can change order	26	change_order
103	Can delete order	26	delete_order
104	Can view order	26	view_order
105	Can add order line	27	add_orderline
106	Can change order line	27	change_orderline
107	Can delete order line	27	delete_orderline
108	Can view order line	27	view_orderline
109	Can add product	28	add_product
110	Can change product	28	change_product
111	Can delete product	28	delete_product
112	Can view product	28	view_product
113	Can add customer	29	add_customer
114	Can change customer	29	change_customer
115	Can delete customer	29	delete_customer
116	Can view customer	29	view_customer
117	Can add shipping address	30	add_shippingaddress
118	Can change shipping address	30	change_shippingaddress
119	Can delete shipping address	30	delete_shippingaddress
120	Can view shipping address	30	view_shippingaddress
121	Can add order	31	add_order
122	Can change order	31	change_order
123	Can delete order	31	delete_order
124	Can view order	31	view_order
125	Can add order line	32	add_orderline
126	Can change order line	32	change_orderline
127	Can delete order line	32	delete_orderline
128	Can view order line	32	view_orderline
129	Can add product	33	add_product
130	Can change product	33	change_product
131	Can delete product	33	delete_product
132	Can view product	33	view_product
133	Can add customer	34	add_customer
134	Can change customer	34	change_customer
135	Can delete customer	34	delete_customer
136	Can view customer	34	view_customer
137	Can add shipping address	35	add_shippingaddress
138	Can change shipping address	35	change_shippingaddress
139	Can delete shipping address	35	delete_shippingaddress
140	Can view shipping address	35	view_shippingaddress
141	Can add order	36	add_order
142	Can change order	36	change_order
143	Can delete order	36	delete_order
144	Can view order	36	view_order
145	Can add order line	37	add_orderline
146	Can change order line	37	change_orderline
147	Can delete order line	37	delete_orderline
148	Can view order line	37	view_orderline
149	Can add product	38	add_product
150	Can change product	38	change_product
151	Can delete product	38	delete_product
152	Can view product	38	view_product
153	Can add customer	39	add_customer
154	Can change customer	39	change_customer
155	Can delete customer	39	delete_customer
156	Can view customer	39	view_customer
157	Can add shipping address	40	add_shippingaddress
158	Can change shipping address	40	change_shippingaddress
159	Can delete shipping address	40	delete_shippingaddress
160	Can view shipping address	40	view_shippingaddress
161	Can add order	41	add_order
162	Can change order	41	change_order
163	Can delete order	41	delete_order
164	Can view order	41	view_order
165	Can add order line	42	add_orderline
166	Can change order line	42	change_orderline
167	Can delete order line	42	delete_orderline
168	Can view order line	42	view_orderline
169	Can add product	43	add_product
170	Can change product	43	change_product
171	Can delete product	43	delete_product
172	Can view product	43	view_product
173	Can add customer	44	add_customer
174	Can change customer	44	change_customer
175	Can delete customer	44	delete_customer
176	Can view customer	44	view_customer
177	Can add shipping address	45	add_shippingaddress
178	Can change shipping address	45	change_shippingaddress
179	Can delete shipping address	45	delete_shippingaddress
180	Can view shipping address	45	view_shippingaddress
181	Can add order	46	add_order
182	Can change order	46	change_order
183	Can delete order	46	delete_order
184	Can view order	46	view_order
185	Can add order line	47	add_orderline
186	Can change order line	47	change_orderline
187	Can delete order line	47	delete_orderline
188	Can view order line	47	view_orderline
189	Can add product	48	add_product
190	Can change product	48	change_product
191	Can delete product	48	delete_product
192	Can view product	48	view_product
193	Can add customer	49	add_customer
194	Can change customer	49	change_customer
195	Can delete customer	49	delete_customer
196	Can view customer	49	view_customer
197	Can add shipping address	50	add_shippingaddress
198	Can change shipping address	50	change_shippingaddress
199	Can delete shipping address	50	delete_shippingaddress
200	Can view shipping address	50	view_shippingaddress
201	Can add order	51	add_order
202	Can change order	51	change_order
203	Can delete order	51	delete_order
204	Can view order	51	view_order
205	Can add order line	52	add_orderline
206	Can change order line	52	change_orderline
207	Can delete order line	52	delete_orderline
208	Can view order line	52	view_orderline
209	Can add product	53	add_product
210	Can change product	53	change_product
211	Can delete product	53	delete_product
212	Can view product	53	view_product
213	Can add customer	54	add_customer
214	Can change customer	54	change_customer
215	Can delete customer	54	delete_customer
216	Can view customer	54	view_customer
217	Can add shipping address	55	add_shippingaddress
218	Can change shipping address	55	change_shippingaddress
219	Can delete shipping address	55	delete_shippingaddress
220	Can view shipping address	55	view_shippingaddress
221	Can add order	56	add_order
222	Can change order	56	change_order
223	Can delete order	56	delete_order
224	Can view order	56	view_order
225	Can add order line	57	add_orderline
226	Can change order line	57	change_orderline
227	Can delete order line	57	delete_orderline
228	Can view order line	57	view_orderline
229	Can add product	58	add_product
230	Can change product	58	change_product
231	Can delete product	58	delete_product
232	Can view product	58	view_product
233	Can add customer	59	add_customer
234	Can change customer	59	change_customer
235	Can delete customer	59	delete_customer
236	Can view customer	59	view_customer
237	Can add shipping address	60	add_shippingaddress
238	Can change shipping address	60	change_shippingaddress
239	Can delete shipping address	60	delete_shippingaddress
240	Can view shipping address	60	view_shippingaddress
241	Can add order	61	add_order
242	Can change order	61	change_order
243	Can delete order	61	delete_order
244	Can view order	61	view_order
245	Can add order line	62	add_orderline
246	Can change order line	62	change_orderline
247	Can delete order line	62	delete_orderline
248	Can view order line	62	view_orderline
249	Can add product	63	add_product
250	Can change product	63	change_product
251	Can delete product	63	delete_product
252	Can view product	63	view_product
253	Can add customer	64	add_customer
254	Can change customer	64	change_customer
255	Can delete customer	64	delete_customer
256	Can view customer	64	view_customer
257	Can add shipping address	65	add_shippingaddress
258	Can change shipping address	65	change_shippingaddress
259	Can delete shipping address	65	delete_shippingaddress
260	Can view shipping address	65	view_shippingaddress
261	Can add order	66	add_order
262	Can change order	66	change_order
263	Can delete order	66	delete_order
264	Can view order	66	view_order
265	Can add order line	67	add_orderline
266	Can change order line	67	change_orderline
267	Can delete order line	67	delete_orderline
268	Can view order line	67	view_orderline
269	Can add product	68	add_product
270	Can change product	68	change_product
271	Can delete product	68	delete_product
272	Can view product	68	view_product
273	Can add customer	69	add_customer
274	Can change customer	69	change_customer
275	Can delete customer	69	delete_customer
276	Can view customer	69	view_customer
277	Can add shipping address	70	add_shippingaddress
278	Can change shipping address	70	change_shippingaddress
279	Can delete shipping address	70	delete_shippingaddress
280	Can view shipping address	70	view_shippingaddress
281	Can add order	71	add_order
282	Can change order	71	change_order
283	Can delete order	71	delete_order
284	Can view order	71	view_order
285	Can add order line	72	add_orderline
286	Can change order line	72	change_orderline
287	Can delete order line	72	delete_orderline
288	Can view order line	72	view_orderline
289	Can add product	73	add_product
290	Can change product	73	change_product
291	Can delete product	73	delete_product
292	Can view product	73	view_product
293	Can add customer	74	add_customer
294	Can change customer	74	change_customer
295	Can delete customer	74	delete_customer
296	Can view customer	74	view_customer
297	Can add shipping address	75	add_shippingaddress
298	Can change shipping address	75	change_shippingaddress
299	Can delete shipping address	75	delete_shippingaddress
300	Can view shipping address	75	view_shippingaddress
301	Can add order	76	add_order
302	Can change order	76	change_order
303	Can delete order	76	delete_order
304	Can view order	76	view_order
305	Can add order line	77	add_orderline
306	Can change order line	77	change_orderline
307	Can delete order line	77	delete_orderline
308	Can view order line	77	view_orderline
309	Can add product	78	add_product
310	Can change product	78	change_product
311	Can delete product	78	delete_product
312	Can view product	78	view_product
313	Can add customer	79	add_customer
314	Can change customer	79	change_customer
315	Can delete customer	79	delete_customer
316	Can view customer	79	view_customer
317	Can add shipping address	80	add_shippingaddress
318	Can change shipping address	80	change_shippingaddress
319	Can delete shipping address	80	delete_shippingaddress
320	Can view shipping address	80	view_shippingaddress
321	Can add order	81	add_order
322	Can change order	81	change_order
323	Can delete order	81	delete_order
324	Can view order	81	view_order
325	Can add order line	82	add_orderline
326	Can change order line	82	change_orderline
327	Can delete order line	82	delete_orderline
328	Can view order line	82	view_orderline
329	Can add product	83	add_product
330	Can change product	83	change_product
331	Can delete product	83	delete_product
332	Can view product	83	view_product
333	Can add customer	84	add_customer
334	Can change customer	84	change_customer
335	Can delete customer	84	delete_customer
336	Can view customer	84	view_customer
337	Can add shipping address	85	add_shippingaddress
338	Can change shipping address	85	change_shippingaddress
339	Can delete shipping address	85	delete_shippingaddress
340	Can view shipping address	85	view_shippingaddress
341	Can add order	86	add_order
342	Can change order	86	change_order
343	Can delete order	86	delete_order
344	Can view order	86	view_order
345	Can add order line	87	add_orderline
346	Can change order line	87	change_orderline
347	Can delete order line	87	delete_orderline
348	Can view order line	87	view_orderline
349	Can add product	88	add_product
350	Can change product	88	change_product
351	Can delete product	88	delete_product
352	Can view product	88	view_product
353	Can add customer	89	add_customer
354	Can change customer	89	change_customer
355	Can delete customer	89	delete_customer
356	Can view customer	89	view_customer
357	Can add shipping address	90	add_shippingaddress
358	Can change shipping address	90	change_shippingaddress
359	Can delete shipping address	90	delete_shippingaddress
360	Can view shipping address	90	view_shippingaddress
361	Can add order	91	add_order
362	Can change order	91	change_order
363	Can delete order	91	delete_order
364	Can view order	91	view_order
365	Can add order line	92	add_orderline
366	Can change order line	92	change_orderline
367	Can delete order line	92	delete_orderline
368	Can view order line	92	view_orderline
369	Can add product	93	add_product
370	Can change product	93	change_product
371	Can delete product	93	delete_product
372	Can view product	93	view_product
373	Can add customer	94	add_customer
374	Can change customer	94	change_customer
375	Can delete customer	94	delete_customer
376	Can view customer	94	view_customer
377	Can add shipping address	95	add_shippingaddress
378	Can change shipping address	95	change_shippingaddress
379	Can delete shipping address	95	delete_shippingaddress
380	Can view shipping address	95	view_shippingaddress
381	Can add order	96	add_order
382	Can change order	96	change_order
383	Can delete order	96	delete_order
384	Can view order	96	view_order
385	Can add order line	97	add_orderline
386	Can change order line	97	change_orderline
387	Can delete order line	97	delete_orderline
388	Can view order line	97	view_orderline
389	Can add product	98	add_product
390	Can change product	98	change_product
391	Can delete product	98	delete_product
392	Can view product	98	view_product
393	Can add customer	99	add_customer
394	Can change customer	99	change_customer
395	Can delete customer	99	delete_customer
396	Can view customer	99	view_customer
397	Can add shipping address	100	add_shippingaddress
398	Can change shipping address	100	change_shippingaddress
399	Can delete shipping address	100	delete_shippingaddress
400	Can view shipping address	100	view_shippingaddress
401	Can add order	101	add_order
402	Can change order	101	change_order
403	Can delete order	101	delete_order
404	Can view order	101	view_order
405	Can add order line	102	add_orderline
406	Can change order line	102	change_orderline
407	Can delete order line	102	delete_orderline
408	Can view order line	102	view_orderline
409	Can add product	103	add_product
410	Can change product	103	change_product
411	Can delete product	103	delete_product
412	Can view product	103	view_product
413	Can add customer	104	add_customer
414	Can change customer	104	change_customer
415	Can delete customer	104	delete_customer
416	Can view customer	104	view_customer
417	Can add shipping address	105	add_shippingaddress
418	Can change shipping address	105	change_shippingaddress
419	Can delete shipping address	105	delete_shippingaddress
420	Can view shipping address	105	view_shippingaddress
421	Can add order	106	add_order
422	Can change order	106	change_order
423	Can delete order	106	delete_order
424	Can view order	106	view_order
425	Can add order line	107	add_orderline
426	Can change order line	107	change_orderline
427	Can delete order line	107	delete_orderline
428	Can view order line	107	view_orderline
429	Can add product	108	add_product
430	Can change product	108	change_product
431	Can delete product	108	delete_product
432	Can view product	108	view_product
433	Can add log entry	109	add_logentry
434	Can change log entry	109	change_logentry
435	Can delete log entry	109	delete_logentry
436	Can view log entry	109	view_logentry
437	Can add permission	110	add_permission
438	Can change permission	110	change_permission
439	Can delete permission	110	delete_permission
440	Can view permission	110	view_permission
441	Can add group	111	add_group
442	Can change group	111	change_group
443	Can delete group	111	delete_group
444	Can view group	111	view_group
445	Can add user	112	add_user
446	Can change user	112	change_user
447	Can delete user	112	delete_user
448	Can view user	112	view_user
449	Can add content type	113	add_contenttype
450	Can change content type	113	change_contenttype
451	Can delete content type	113	delete_contenttype
452	Can view content type	113	view_contenttype
453	Can add session	114	add_session
454	Can change session	114	change_session
455	Can delete session	114	delete_session
456	Can view session	114	view_session
\.


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	main	tweet
2	main	like
3	main	follow
4	shop	customer
5	shop	shippingaddress
6	shop	order
7	shop	orderline
8	shop	product
9	shop01	customer
10	shop01	shippingaddress
11	shop01	order
12	shop01	orderline
13	shop01	product
14	shop02	customer
15	shop02	shippingaddress
16	shop02	order
17	shop02	orderline
18	shop02	product
19	shop03	customer
20	shop03	shippingaddress
21	shop03	order
22	shop03	orderline
23	shop03	product
24	shop04	customer
25	shop04	shippingaddress
26	shop04	order
27	shop04	orderline
28	shop04	product
29	shop05	customer
30	shop05	shippingaddress
31	shop05	order
32	shop05	orderline
33	shop05	product
34	shop06	customer
35	shop06	shippingaddress
36	shop06	order
37	shop06	orderline
38	shop06	product
39	shop07	customer
40	shop07	shippingaddress
41	shop07	order
42	shop07	orderline
43	shop07	product
44	shop08	customer
45	shop08	shippingaddress
46	shop08	order
47	shop08	orderline
48	shop08	product
49	shop09	customer
50	shop09	shippingaddress
51	shop09	order
52	shop09	orderline
53	shop09	product
54	shop10	customer
55	shop10	shippingaddress
56	shop10	order
57	shop10	orderline
58	shop10	product
59	shop11	customer
60	shop11	shippingaddress
61	shop11	order
62	shop11	orderline
63	shop11	product
64	shop12	customer
65	shop12	shippingaddress
66	shop12	order
67	shop12	orderline
68	shop12	product
69	shop13	customer
70	shop13	shippingaddress
71	shop13	order
72	shop13	orderline
73	shop13	product
74	shop14	customer
75	shop14	shippingaddress
76	shop14	order
77	shop14	orderline
78	shop14	product
79	shop15	customer
80	shop15	shippingaddress
81	shop15	order
82	shop15	orderline
83	shop15	product
84	shop16	customer
85	shop16	shippingaddress
86	shop16	order
87	shop16	orderline
88	shop16	product
89	shop17	customer
90	shop17	shippingaddress
91	shop17	order
92	shop17	orderline
93	shop17	product
94	shop18	customer
95	shop18	shippingaddress
96	shop18	order
97	shop18	orderline
98	shop18	product
99	shop19	customer
100	shop19	shippingaddress
101	shop19	order
102	shop19	orderline
103	shop19	product
104	shop20	customer
105	shop20	shippingaddress
106	shop20	order
107	shop20	orderline
108	shop20	product
109	admin	logentry
110	auth	permission
111	auth	group
112	auth	user
113	contenttypes	contenttype
114	sessions	session
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2024-02-09 21:13:09.822846+01
2	auth	0001_initial	2024-02-09 21:13:09.882422+01
3	admin	0001_initial	2024-02-09 21:13:09.896351+01
4	admin	0002_logentry_remove_auto_add	2024-02-09 21:13:09.900055+01
5	admin	0003_logentry_add_action_flag_choices	2024-02-09 21:13:09.903342+01
6	contenttypes	0002_remove_content_type_name	2024-02-09 21:13:09.90952+01
7	auth	0002_alter_permission_name_max_length	2024-02-09 21:13:09.9132+01
8	auth	0003_alter_user_email_max_length	2024-02-09 21:13:09.916652+01
9	auth	0004_alter_user_username_opts	2024-02-09 21:13:09.919985+01
10	auth	0005_alter_user_last_login_null	2024-02-09 21:13:09.924017+01
11	auth	0006_require_contenttypes_0002	2024-02-09 21:13:09.925231+01
12	auth	0007_alter_validators_add_error_messages	2024-02-09 21:13:09.927927+01
13	auth	0008_alter_user_username_max_length	2024-02-09 21:13:09.934092+01
14	auth	0009_alter_user_last_name_max_length	2024-02-09 21:13:09.938062+01
15	auth	0010_alter_group_name_max_length	2024-02-09 21:13:09.94243+01
16	auth	0011_update_proxy_permissions	2024-02-09 21:13:09.945634+01
17	auth	0012_alter_user_first_name_max_length	2024-02-09 21:13:09.949052+01
18	main	0001_initial	2024-02-09 21:13:09.961037+01
19	main	0002_alter_tweet_text	2024-02-09 21:13:09.965612+01
20	main	0003_like	2024-02-09 21:13:09.985434+01
21	main	0004_tweet_related_tweet_alter_tweet_text	2024-02-09 21:13:09.994543+01
22	main	0005_alter_like_tweet	2024-02-09 21:13:09.998915+01
23	main	0006_follow	2024-02-09 21:13:10.014234+01
24	sessions	0001_initial	2024-02-09 21:13:10.022161+01
25	shop	0001_initial	2024-02-09 21:13:10.042886+01
26	shop	0002_customer_is_premium	2024-02-09 21:13:10.06309+01
27	shop	0003_shippingaddress	2024-02-09 21:13:10.081071+01
28	shop	0004_migrate_shipping_address	2024-02-09 21:13:10.088162+01
29	shop	0005_remove_customer_shipping_state	2024-02-09 21:13:10.094707+01
30	shop	0006_remove_customer_shipping_province	2024-02-09 21:13:10.10202+01
31	shop	0007_remove_customer_shipping_city	2024-02-09 21:13:10.109946+01
32	shop	0008_remove_customer_shipping_zip_code	2024-02-09 21:13:10.117295+01
33	shop	0009_remove_customer_shipping_address	2024-02-09 21:13:10.123841+01
34	shop	0010_remove_customer_shipping_name	2024-02-09 21:13:10.129874+01
35	shop	0011_alter_shippingaddress_address_and_more	2024-02-09 21:13:10.138749+01
36	shop	0012_order	2024-02-09 21:13:10.161604+01
37	shop	0013_order_created_at	2024-02-09 21:13:10.167724+01
38	shop	0014_orderline	2024-02-09 21:13:10.185021+01
39	shop	0015_alter_customer_user	2024-02-09 21:13:10.191412+01
40	shop	0016_customer_customer_type	2024-02-09 21:13:10.199216+01
41	shop	0017_migrate_is_premium_to_customer_type	2024-02-09 21:13:10.207009+01
42	shop	0018_remove_customer_is_premium	2024-02-09 21:13:10.213335+01
43	shop	0019_alter_customer_customer_type	2024-02-09 21:13:10.219059+01
44	shop	0020_alter_customer_customer_type	2024-02-09 21:13:10.225939+01
45	shop	0021_alter_customer_customer_type	2024-02-09 21:13:10.233806+01
46	shop	0022_alter_customer_customer_type	2024-02-09 21:13:10.240172+01
47	shop	0023_alter_customer_customer_type	2024-02-09 21:13:10.246595+01
48	shop	0024_alter_customer_customer_type	2024-02-09 21:13:10.25275+01
49	shop	0025_rename_product_quantity_orderline_quantity	2024-02-09 21:13:10.25654+01
50	shop	0026_product	2024-02-09 21:13:10.28403+01
51	shop01	0001_initial	2024-02-09 21:13:10.314775+01
52	shop01	0002_customer_is_premium	2024-02-09 21:13:10.321584+01
53	shop01	0003_shippingaddress	2024-02-09 21:13:10.341009+01
54	shop01	0004_migrate_shipping_address	2024-02-09 21:13:10.347865+01
55	shop01	0005_remove_customer_shipping_state	2024-02-09 21:13:10.354825+01
56	shop01	0006_remove_customer_shipping_province	2024-02-09 21:13:10.360767+01
57	shop01	0007_remove_customer_shipping_city	2024-02-09 21:13:10.367477+01
58	shop01	0008_remove_customer_shipping_zip_code	2024-02-09 21:13:10.373045+01
59	shop01	0009_remove_customer_shipping_address	2024-02-09 21:13:10.378284+01
60	shop01	0010_remove_customer_shipping_name	2024-02-09 21:13:10.385689+01
61	shop01	0011_alter_shippingaddress_address_and_more	2024-02-09 21:13:10.394064+01
62	shop01	0012_order	2024-02-09 21:13:10.412386+01
63	shop01	0013_order_created_at	2024-02-09 21:13:10.416121+01
64	shop01	0014_orderline	2024-02-09 21:13:10.44589+01
65	shop01	0015_alter_customer_user	2024-02-09 21:13:10.453251+01
66	shop01	0016_customer_customer_type	2024-02-09 21:13:10.459262+01
67	shop01	0017_migrate_is_premium_to_customer_type	2024-02-09 21:13:10.466506+01
68	shop01	0018_remove_customer_is_premium	2024-02-09 21:13:10.473008+01
69	shop01	0019_alter_customer_customer_type	2024-02-09 21:13:10.480233+01
70	shop01	0020_alter_customer_customer_type	2024-02-09 21:13:10.486025+01
71	shop01	0021_alter_customer_customer_type	2024-02-09 21:13:10.491168+01
72	shop01	0022_alter_customer_customer_type	2024-02-09 21:13:10.497244+01
73	shop01	0023_alter_customer_customer_type	2024-02-09 21:13:10.502308+01
74	shop01	0024_alter_customer_customer_type	2024-02-09 21:13:10.506726+01
75	shop01	0025_rename_product_quantity_orderline_quantity	2024-02-09 21:13:10.510406+01
76	shop01	0026_product	2024-02-09 21:13:10.53092+01
77	shop02	0001_initial	2024-02-09 21:13:10.574744+01
78	shop02	0002_customer_is_premium	2024-02-09 21:13:10.581037+01
79	shop02	0003_shippingaddress	2024-02-09 21:13:10.601787+01
80	shop02	0004_migrate_shipping_address	2024-02-09 21:13:10.609951+01
81	shop02	0005_remove_customer_shipping_state	2024-02-09 21:13:10.616067+01
82	shop02	0006_remove_customer_shipping_province	2024-02-09 21:13:10.622242+01
83	shop02	0007_remove_customer_shipping_city	2024-02-09 21:13:10.627734+01
84	shop02	0008_remove_customer_shipping_zip_code	2024-02-09 21:13:10.63448+01
85	shop02	0009_remove_customer_shipping_address	2024-02-09 21:13:10.640456+01
86	shop02	0010_remove_customer_shipping_name	2024-02-09 21:13:10.645728+01
87	shop02	0011_alter_shippingaddress_address_and_more	2024-02-09 21:13:10.653552+01
88	shop02	0012_order	2024-02-09 21:13:10.673687+01
89	shop02	0013_order_created_at	2024-02-09 21:13:10.677891+01
90	shop02	0014_orderline	2024-02-09 21:13:10.702027+01
91	shop02	0015_alter_customer_user	2024-02-09 21:13:10.710143+01
92	shop02	0016_customer_customer_type	2024-02-09 21:13:10.716434+01
93	shop02	0017_migrate_is_premium_to_customer_type	2024-02-09 21:13:10.725068+01
94	shop02	0018_remove_customer_is_premium	2024-02-09 21:13:10.730235+01
95	shop02	0019_alter_customer_customer_type	2024-02-09 21:13:10.73531+01
96	shop02	0020_alter_customer_customer_type	2024-02-09 21:13:10.742198+01
97	shop02	0021_alter_customer_customer_type	2024-02-09 21:13:10.747994+01
98	shop02	0022_alter_customer_customer_type	2024-02-09 21:13:10.753072+01
99	shop02	0023_alter_customer_customer_type	2024-02-09 21:13:10.760558+01
100	shop02	0024_alter_customer_customer_type	2024-02-09 21:13:10.766173+01
101	shop02	0025_rename_product_quantity_orderline_quantity	2024-02-09 21:13:10.768883+01
102	shop02	0026_product	2024-02-09 21:13:10.793547+01
103	shop03	0001_initial	2024-02-09 21:13:10.814159+01
104	shop03	0002_customer_is_premium	2024-02-09 21:13:10.822297+01
105	shop03	0003_shippingaddress	2024-02-09 21:13:10.840177+01
106	shop03	0004_migrate_shipping_address	2024-02-09 21:13:10.84798+01
107	shop03	0005_remove_customer_shipping_state	2024-02-09 21:13:10.855528+01
108	shop03	0006_remove_customer_shipping_province	2024-02-09 21:13:10.861476+01
109	shop03	0007_remove_customer_shipping_city	2024-02-09 21:13:10.866747+01
110	shop03	0008_remove_customer_shipping_zip_code	2024-02-09 21:13:10.873594+01
111	shop03	0009_remove_customer_shipping_address	2024-02-09 21:13:10.880095+01
112	shop03	0010_remove_customer_shipping_name	2024-02-09 21:13:10.886901+01
113	shop03	0011_alter_shippingaddress_address_and_more	2024-02-09 21:13:10.896857+01
114	shop03	0012_order	2024-02-09 21:13:10.919984+01
115	shop03	0013_order_created_at	2024-02-09 21:13:10.925422+01
116	shop03	0014_orderline	2024-02-09 21:13:10.944258+01
117	shop03	0015_alter_customer_user	2024-02-09 21:13:10.953635+01
118	shop03	0016_customer_customer_type	2024-02-09 21:13:10.978732+01
119	shop03	0017_migrate_is_premium_to_customer_type	2024-02-09 21:13:10.987355+01
120	shop03	0018_remove_customer_is_premium	2024-02-09 21:13:10.993271+01
121	shop03	0019_alter_customer_customer_type	2024-02-09 21:13:10.999245+01
122	shop03	0020_alter_customer_customer_type	2024-02-09 21:13:11.004345+01
123	shop03	0021_alter_customer_customer_type	2024-02-09 21:13:11.008788+01
124	shop03	0022_alter_customer_customer_type	2024-02-09 21:13:11.014278+01
125	shop03	0023_alter_customer_customer_type	2024-02-09 21:13:11.019829+01
126	shop03	0024_alter_customer_customer_type	2024-02-09 21:13:11.025724+01
127	shop03	0025_rename_product_quantity_orderline_quantity	2024-02-09 21:13:11.030252+01
128	shop03	0026_product	2024-02-09 21:13:11.052242+01
129	shop04	0001_initial	2024-02-09 21:13:11.077898+01
130	shop04	0002_customer_is_premium	2024-02-09 21:13:11.085313+01
131	shop04	0003_shippingaddress	2024-02-09 21:13:11.108759+01
132	shop04	0004_migrate_shipping_address	2024-02-09 21:13:11.118284+01
133	shop04	0005_remove_customer_shipping_state	2024-02-09 21:13:11.123786+01
134	shop04	0006_remove_customer_shipping_province	2024-02-09 21:13:11.129761+01
135	shop04	0007_remove_customer_shipping_city	2024-02-09 21:13:11.136642+01
136	shop04	0008_remove_customer_shipping_zip_code	2024-02-09 21:13:11.142089+01
137	shop04	0009_remove_customer_shipping_address	2024-02-09 21:13:11.147782+01
138	shop04	0010_remove_customer_shipping_name	2024-02-09 21:13:11.153364+01
139	shop04	0011_alter_shippingaddress_address_and_more	2024-02-09 21:13:11.162771+01
140	shop04	0012_order	2024-02-09 21:13:11.183283+01
141	shop04	0013_order_created_at	2024-02-09 21:13:11.189413+01
142	shop04	0014_orderline	2024-02-09 21:13:11.218402+01
143	shop04	0015_alter_customer_user	2024-02-09 21:13:11.227814+01
144	shop04	0016_customer_customer_type	2024-02-09 21:13:11.235993+01
145	shop04	0017_migrate_is_premium_to_customer_type	2024-02-09 21:13:11.245582+01
146	shop04	0018_remove_customer_is_premium	2024-02-09 21:13:11.252474+01
147	shop04	0019_alter_customer_customer_type	2024-02-09 21:13:11.258252+01
148	shop04	0020_alter_customer_customer_type	2024-02-09 21:13:11.26389+01
149	shop04	0021_alter_customer_customer_type	2024-02-09 21:13:11.269733+01
150	shop04	0022_alter_customer_customer_type	2024-02-09 21:13:11.276505+01
151	shop04	0023_alter_customer_customer_type	2024-02-09 21:13:11.282211+01
152	shop04	0024_alter_customer_customer_type	2024-02-09 21:13:11.288494+01
153	shop04	0025_rename_product_quantity_orderline_quantity	2024-02-09 21:13:11.292813+01
154	shop04	0026_product	2024-02-09 21:13:11.315734+01
155	shop05	0001_initial	2024-02-09 21:13:11.360262+01
156	shop05	0002_customer_is_premium	2024-02-09 21:13:11.367463+01
157	shop05	0003_shippingaddress	2024-02-09 21:13:11.389497+01
158	shop05	0004_migrate_shipping_address	2024-02-09 21:13:11.400004+01
159	shop05	0005_remove_customer_shipping_state	2024-02-09 21:13:11.407554+01
160	shop05	0006_remove_customer_shipping_province	2024-02-09 21:13:11.413842+01
161	shop05	0007_remove_customer_shipping_city	2024-02-09 21:13:11.419961+01
162	shop05	0008_remove_customer_shipping_zip_code	2024-02-09 21:13:11.426021+01
163	shop05	0009_remove_customer_shipping_address	2024-02-09 21:13:11.432099+01
164	shop05	0010_remove_customer_shipping_name	2024-02-09 21:13:11.439212+01
165	shop05	0011_alter_shippingaddress_address_and_more	2024-02-09 21:13:11.448536+01
166	shop05	0012_order	2024-02-09 21:13:11.474762+01
167	shop05	0013_order_created_at	2024-02-09 21:13:11.480244+01
168	shop05	0014_orderline	2024-02-09 21:13:11.503899+01
169	shop05	0015_alter_customer_user	2024-02-09 21:13:11.514722+01
170	shop05	0016_customer_customer_type	2024-02-09 21:13:11.52285+01
171	shop05	0017_migrate_is_premium_to_customer_type	2024-02-09 21:13:11.533726+01
172	shop05	0018_remove_customer_is_premium	2024-02-09 21:13:11.54096+01
173	shop05	0019_alter_customer_customer_type	2024-02-09 21:13:11.54788+01
174	shop05	0020_alter_customer_customer_type	2024-02-09 21:13:11.553869+01
175	shop05	0021_alter_customer_customer_type	2024-02-09 21:13:11.5601+01
176	shop05	0022_alter_customer_customer_type	2024-02-09 21:13:11.565658+01
177	shop05	0023_alter_customer_customer_type	2024-02-09 21:13:11.572913+01
178	shop05	0024_alter_customer_customer_type	2024-02-09 21:13:11.578059+01
179	shop05	0025_rename_product_quantity_orderline_quantity	2024-02-09 21:13:11.581921+01
180	shop05	0026_product	2024-02-09 21:13:11.607073+01
181	shop06	0001_initial	2024-02-09 21:13:11.641521+01
182	shop06	0002_customer_is_premium	2024-02-09 21:13:11.647581+01
183	shop06	0003_shippingaddress	2024-02-09 21:13:11.669923+01
184	shop06	0004_migrate_shipping_address	2024-02-09 21:13:11.703325+01
185	shop06	0005_remove_customer_shipping_state	2024-02-09 21:13:11.710714+01
186	shop06	0006_remove_customer_shipping_province	2024-02-09 21:13:11.716533+01
187	shop06	0007_remove_customer_shipping_city	2024-02-09 21:13:11.723429+01
188	shop06	0008_remove_customer_shipping_zip_code	2024-02-09 21:13:11.731446+01
189	shop06	0009_remove_customer_shipping_address	2024-02-09 21:13:11.737888+01
190	shop06	0010_remove_customer_shipping_name	2024-02-09 21:13:11.744456+01
191	shop06	0011_alter_shippingaddress_address_and_more	2024-02-09 21:13:11.754821+01
192	shop06	0012_order	2024-02-09 21:13:11.779857+01
193	shop06	0013_order_created_at	2024-02-09 21:13:11.785697+01
194	shop06	0014_orderline	2024-02-09 21:13:11.81742+01
195	shop06	0015_alter_customer_user	2024-02-09 21:13:11.828887+01
196	shop06	0016_customer_customer_type	2024-02-09 21:13:11.83647+01
197	shop06	0017_migrate_is_premium_to_customer_type	2024-02-09 21:13:11.848982+01
198	shop06	0018_remove_customer_is_premium	2024-02-09 21:13:11.85688+01
199	shop06	0019_alter_customer_customer_type	2024-02-09 21:13:11.863566+01
200	shop06	0020_alter_customer_customer_type	2024-02-09 21:13:11.871028+01
201	shop06	0021_alter_customer_customer_type	2024-02-09 21:13:11.877402+01
202	shop06	0022_alter_customer_customer_type	2024-02-09 21:13:11.883735+01
203	shop06	0023_alter_customer_customer_type	2024-02-09 21:13:11.890151+01
204	shop06	0024_alter_customer_customer_type	2024-02-09 21:13:11.897697+01
205	shop06	0025_rename_product_quantity_orderline_quantity	2024-02-09 21:13:11.901229+01
206	shop06	0026_product	2024-02-09 21:13:11.92638+01
207	shop07	0001_initial	2024-02-09 21:13:11.956412+01
208	shop07	0002_customer_is_premium	2024-02-09 21:13:11.963728+01
209	shop07	0003_shippingaddress	2024-02-09 21:13:11.994994+01
210	shop07	0004_migrate_shipping_address	2024-02-09 21:13:12.006524+01
211	shop07	0005_remove_customer_shipping_state	2024-02-09 21:13:12.013459+01
212	shop07	0006_remove_customer_shipping_province	2024-02-09 21:13:12.020146+01
213	shop07	0007_remove_customer_shipping_city	2024-02-09 21:13:12.049035+01
214	shop07	0008_remove_customer_shipping_zip_code	2024-02-09 21:13:12.0571+01
215	shop07	0009_remove_customer_shipping_address	2024-02-09 21:13:12.062833+01
216	shop07	0010_remove_customer_shipping_name	2024-02-09 21:13:12.069344+01
217	shop07	0011_alter_shippingaddress_address_and_more	2024-02-09 21:13:12.079915+01
218	shop07	0012_order	2024-02-09 21:13:12.104028+01
219	shop07	0013_order_created_at	2024-02-09 21:13:12.109845+01
220	shop07	0014_orderline	2024-02-09 21:13:12.13477+01
221	shop07	0015_alter_customer_user	2024-02-09 21:13:12.147921+01
222	shop07	0016_customer_customer_type	2024-02-09 21:13:12.156408+01
223	shop07	0017_migrate_is_premium_to_customer_type	2024-02-09 21:13:12.168794+01
224	shop07	0018_remove_customer_is_premium	2024-02-09 21:13:12.1766+01
225	shop07	0019_alter_customer_customer_type	2024-02-09 21:13:12.183144+01
226	shop07	0020_alter_customer_customer_type	2024-02-09 21:13:12.19012+01
227	shop07	0021_alter_customer_customer_type	2024-02-09 21:13:12.195921+01
228	shop07	0022_alter_customer_customer_type	2024-02-09 21:13:12.202894+01
229	shop07	0023_alter_customer_customer_type	2024-02-09 21:13:12.210055+01
230	shop07	0024_alter_customer_customer_type	2024-02-09 21:13:12.215855+01
231	shop07	0025_rename_product_quantity_orderline_quantity	2024-02-09 21:13:12.21971+01
232	shop07	0026_product	2024-02-09 21:13:12.248167+01
233	shop08	0001_initial	2024-02-09 21:13:12.281388+01
234	shop08	0002_customer_is_premium	2024-02-09 21:13:12.289641+01
235	shop08	0003_shippingaddress	2024-02-09 21:13:12.311708+01
236	shop08	0004_migrate_shipping_address	2024-02-09 21:13:12.326506+01
237	shop08	0005_remove_customer_shipping_state	2024-02-09 21:13:12.333321+01
238	shop08	0006_remove_customer_shipping_province	2024-02-09 21:13:12.340667+01
239	shop08	0007_remove_customer_shipping_city	2024-02-09 21:13:12.348599+01
240	shop08	0008_remove_customer_shipping_zip_code	2024-02-09 21:13:12.377823+01
241	shop08	0009_remove_customer_shipping_address	2024-02-09 21:13:12.385831+01
242	shop08	0010_remove_customer_shipping_name	2024-02-09 21:13:12.393369+01
243	shop08	0011_alter_shippingaddress_address_and_more	2024-02-09 21:13:12.404214+01
244	shop08	0012_order	2024-02-09 21:13:12.435589+01
245	shop08	0013_order_created_at	2024-02-09 21:13:12.44213+01
246	shop08	0014_orderline	2024-02-09 21:13:12.472581+01
247	shop08	0015_alter_customer_user	2024-02-09 21:13:12.486681+01
248	shop08	0016_customer_customer_type	2024-02-09 21:13:12.493399+01
249	shop08	0017_migrate_is_premium_to_customer_type	2024-02-09 21:13:12.507254+01
250	shop08	0018_remove_customer_is_premium	2024-02-09 21:13:12.515303+01
251	shop08	0019_alter_customer_customer_type	2024-02-09 21:13:12.523092+01
252	shop08	0020_alter_customer_customer_type	2024-02-09 21:13:12.53074+01
253	shop08	0021_alter_customer_customer_type	2024-02-09 21:13:12.539488+01
254	shop08	0022_alter_customer_customer_type	2024-02-09 21:13:12.545462+01
255	shop08	0023_alter_customer_customer_type	2024-02-09 21:13:12.552184+01
256	shop08	0024_alter_customer_customer_type	2024-02-09 21:13:12.559835+01
257	shop08	0025_rename_product_quantity_orderline_quantity	2024-02-09 21:13:12.564278+01
258	shop08	0026_product	2024-02-09 21:13:12.593238+01
259	shop09	0001_initial	2024-02-09 21:13:12.621099+01
260	shop09	0002_customer_is_premium	2024-02-09 21:13:12.627773+01
261	shop09	0003_shippingaddress	2024-02-09 21:13:12.655122+01
262	shop09	0004_migrate_shipping_address	2024-02-09 21:13:12.669299+01
263	shop09	0005_remove_customer_shipping_state	2024-02-09 21:13:12.675728+01
264	shop09	0006_remove_customer_shipping_province	2024-02-09 21:13:12.706491+01
265	shop09	0007_remove_customer_shipping_city	2024-02-09 21:13:12.714574+01
266	shop09	0008_remove_customer_shipping_zip_code	2024-02-09 21:13:12.723008+01
267	shop09	0009_remove_customer_shipping_address	2024-02-09 21:13:12.729619+01
268	shop09	0010_remove_customer_shipping_name	2024-02-09 21:13:12.736493+01
269	shop09	0011_alter_shippingaddress_address_and_more	2024-02-09 21:13:12.748023+01
270	shop09	0012_order	2024-02-09 21:13:12.77468+01
271	shop09	0013_order_created_at	2024-02-09 21:13:12.780912+01
272	shop09	0014_orderline	2024-02-09 21:13:12.814969+01
273	shop09	0015_alter_customer_user	2024-02-09 21:13:12.830904+01
274	shop09	0016_customer_customer_type	2024-02-09 21:13:12.840438+01
275	shop09	0017_migrate_is_premium_to_customer_type	2024-02-09 21:13:12.856137+01
276	shop09	0018_remove_customer_is_premium	2024-02-09 21:13:12.864868+01
277	shop09	0019_alter_customer_customer_type	2024-02-09 21:13:12.873117+01
278	shop09	0020_alter_customer_customer_type	2024-02-09 21:13:12.881126+01
279	shop09	0021_alter_customer_customer_type	2024-02-09 21:13:12.890041+01
280	shop09	0022_alter_customer_customer_type	2024-02-09 21:13:12.898065+01
281	shop09	0023_alter_customer_customer_type	2024-02-09 21:13:12.906667+01
282	shop09	0024_alter_customer_customer_type	2024-02-09 21:13:12.915358+01
283	shop09	0025_rename_product_quantity_orderline_quantity	2024-02-09 21:13:12.919737+01
284	shop09	0026_product	2024-02-09 21:13:12.950489+01
285	shop10	0001_initial	2024-02-09 21:13:12.979842+01
286	shop10	0002_customer_is_premium	2024-02-09 21:13:12.989458+01
287	shop10	0003_shippingaddress	2024-02-09 21:13:13.040255+01
478	shop17	0012_order	2024-02-09 21:13:16.198224+01
288	shop10	0004_migrate_shipping_address	2024-02-09 21:13:13.056739+01
289	shop10	0005_remove_customer_shipping_state	2024-02-09 21:13:13.064478+01
290	shop10	0006_remove_customer_shipping_province	2024-02-09 21:13:13.072678+01
291	shop10	0007_remove_customer_shipping_city	2024-02-09 21:13:13.081192+01
292	shop10	0008_remove_customer_shipping_zip_code	2024-02-09 21:13:13.089872+01
293	shop10	0009_remove_customer_shipping_address	2024-02-09 21:13:13.096708+01
294	shop10	0010_remove_customer_shipping_name	2024-02-09 21:13:13.105659+01
295	shop10	0011_alter_shippingaddress_address_and_more	2024-02-09 21:13:13.116056+01
296	shop10	0012_order	2024-02-09 21:13:13.14697+01
297	shop10	0013_order_created_at	2024-02-09 21:13:13.152073+01
298	shop10	0014_orderline	2024-02-09 21:13:13.190095+01
299	shop10	0015_alter_customer_user	2024-02-09 21:13:13.206073+01
300	shop10	0016_customer_customer_type	2024-02-09 21:13:13.215255+01
301	shop10	0017_migrate_is_premium_to_customer_type	2024-02-09 21:13:13.231967+01
302	shop10	0018_remove_customer_is_premium	2024-02-09 21:13:13.241194+01
303	shop10	0019_alter_customer_customer_type	2024-02-09 21:13:13.248649+01
304	shop10	0020_alter_customer_customer_type	2024-02-09 21:13:13.25607+01
305	shop10	0021_alter_customer_customer_type	2024-02-09 21:13:13.264786+01
306	shop10	0022_alter_customer_customer_type	2024-02-09 21:13:13.272141+01
307	shop10	0023_alter_customer_customer_type	2024-02-09 21:13:13.27886+01
308	shop10	0024_alter_customer_customer_type	2024-02-09 21:13:13.286915+01
309	shop10	0025_rename_product_quantity_orderline_quantity	2024-02-09 21:13:13.291046+01
310	shop10	0026_product	2024-02-09 21:13:13.323187+01
311	shop11	0001_initial	2024-02-09 21:13:13.385755+01
312	shop11	0002_customer_is_premium	2024-02-09 21:13:13.394614+01
313	shop11	0003_shippingaddress	2024-02-09 21:13:13.426745+01
314	shop11	0004_migrate_shipping_address	2024-02-09 21:13:13.442517+01
315	shop11	0005_remove_customer_shipping_state	2024-02-09 21:13:13.450763+01
316	shop11	0006_remove_customer_shipping_province	2024-02-09 21:13:13.460596+01
317	shop11	0007_remove_customer_shipping_city	2024-02-09 21:13:13.468247+01
318	shop11	0008_remove_customer_shipping_zip_code	2024-02-09 21:13:13.477026+01
319	shop11	0009_remove_customer_shipping_address	2024-02-09 21:13:13.485714+01
320	shop11	0010_remove_customer_shipping_name	2024-02-09 21:13:13.494371+01
321	shop11	0011_alter_shippingaddress_address_and_more	2024-02-09 21:13:13.506813+01
322	shop11	0012_order	2024-02-09 21:13:13.541816+01
323	shop11	0013_order_created_at	2024-02-09 21:13:13.54718+01
324	shop11	0014_orderline	2024-02-09 21:13:13.589039+01
325	shop11	0015_alter_customer_user	2024-02-09 21:13:13.607764+01
326	shop11	0016_customer_customer_type	2024-02-09 21:13:13.617712+01
327	shop11	0017_migrate_is_premium_to_customer_type	2024-02-09 21:13:13.635741+01
328	shop11	0018_remove_customer_is_premium	2024-02-09 21:13:13.64484+01
329	shop11	0019_alter_customer_customer_type	2024-02-09 21:13:13.67629+01
330	shop11	0020_alter_customer_customer_type	2024-02-09 21:13:13.68526+01
331	shop11	0021_alter_customer_customer_type	2024-02-09 21:13:13.693493+01
332	shop11	0022_alter_customer_customer_type	2024-02-09 21:13:13.702739+01
333	shop11	0023_alter_customer_customer_type	2024-02-09 21:13:13.711525+01
334	shop11	0024_alter_customer_customer_type	2024-02-09 21:13:13.720008+01
335	shop11	0025_rename_product_quantity_orderline_quantity	2024-02-09 21:13:13.72563+01
336	shop11	0026_product	2024-02-09 21:13:13.763026+01
337	shop12	0001_initial	2024-02-09 21:13:13.79262+01
338	shop12	0002_customer_is_premium	2024-02-09 21:13:13.802766+01
339	shop12	0003_shippingaddress	2024-02-09 21:13:13.838596+01
340	shop12	0004_migrate_shipping_address	2024-02-09 21:13:13.856892+01
341	shop12	0005_remove_customer_shipping_state	2024-02-09 21:13:13.866403+01
342	shop12	0006_remove_customer_shipping_province	2024-02-09 21:13:13.876138+01
343	shop12	0007_remove_customer_shipping_city	2024-02-09 21:13:13.886025+01
344	shop12	0008_remove_customer_shipping_zip_code	2024-02-09 21:13:13.895188+01
345	shop12	0009_remove_customer_shipping_address	2024-02-09 21:13:13.905173+01
346	shop12	0010_remove_customer_shipping_name	2024-02-09 21:13:13.913119+01
347	shop12	0011_alter_shippingaddress_address_and_more	2024-02-09 21:13:13.926952+01
348	shop12	0012_order	2024-02-09 21:13:13.952672+01
349	shop12	0013_order_created_at	2024-02-09 21:13:13.959507+01
350	shop12	0014_orderline	2024-02-09 21:13:14.023488+01
351	shop12	0015_alter_customer_user	2024-02-09 21:13:14.043152+01
352	shop12	0016_customer_customer_type	2024-02-09 21:13:14.053987+01
353	shop12	0017_migrate_is_premium_to_customer_type	2024-02-09 21:13:14.071101+01
354	shop12	0018_remove_customer_is_premium	2024-02-09 21:13:14.080355+01
355	shop12	0019_alter_customer_customer_type	2024-02-09 21:13:14.087971+01
356	shop12	0020_alter_customer_customer_type	2024-02-09 21:13:14.095899+01
357	shop12	0021_alter_customer_customer_type	2024-02-09 21:13:14.10339+01
358	shop12	0022_alter_customer_customer_type	2024-02-09 21:13:14.110045+01
359	shop12	0023_alter_customer_customer_type	2024-02-09 21:13:14.118168+01
360	shop12	0024_alter_customer_customer_type	2024-02-09 21:13:14.125515+01
361	shop12	0025_rename_product_quantity_orderline_quantity	2024-02-09 21:13:14.129236+01
362	shop12	0026_product	2024-02-09 21:13:14.156899+01
363	shop13	0001_initial	2024-02-09 21:13:14.193495+01
364	shop13	0002_customer_is_premium	2024-02-09 21:13:14.203+01
365	shop13	0003_shippingaddress	2024-02-09 21:13:14.238382+01
366	shop13	0004_migrate_shipping_address	2024-02-09 21:13:14.25685+01
367	shop13	0005_remove_customer_shipping_state	2024-02-09 21:13:14.265819+01
368	shop13	0006_remove_customer_shipping_province	2024-02-09 21:13:14.301453+01
369	shop13	0007_remove_customer_shipping_city	2024-02-09 21:13:14.311301+01
370	shop13	0008_remove_customer_shipping_zip_code	2024-02-09 21:13:14.319858+01
371	shop13	0009_remove_customer_shipping_address	2024-02-09 21:13:14.328707+01
372	shop13	0010_remove_customer_shipping_name	2024-02-09 21:13:14.337594+01
373	shop13	0011_alter_shippingaddress_address_and_more	2024-02-09 21:13:14.350528+01
374	shop13	0012_order	2024-02-09 21:13:14.387858+01
375	shop13	0013_order_created_at	2024-02-09 21:13:14.39494+01
376	shop13	0014_orderline	2024-02-09 21:13:14.434322+01
377	shop13	0015_alter_customer_user	2024-02-09 21:13:14.454077+01
378	shop13	0016_customer_customer_type	2024-02-09 21:13:14.462935+01
379	shop13	0017_migrate_is_premium_to_customer_type	2024-02-09 21:13:14.479894+01
380	shop13	0018_remove_customer_is_premium	2024-02-09 21:13:14.488616+01
381	shop13	0019_alter_customer_customer_type	2024-02-09 21:13:14.496285+01
382	shop13	0020_alter_customer_customer_type	2024-02-09 21:13:14.504512+01
383	shop13	0021_alter_customer_customer_type	2024-02-09 21:13:14.51217+01
384	shop13	0022_alter_customer_customer_type	2024-02-09 21:13:14.521201+01
385	shop13	0023_alter_customer_customer_type	2024-02-09 21:13:14.528784+01
386	shop13	0024_alter_customer_customer_type	2024-02-09 21:13:14.537326+01
387	shop13	0025_rename_product_quantity_orderline_quantity	2024-02-09 21:13:14.543144+01
388	shop13	0026_product	2024-02-09 21:13:14.604847+01
389	shop14	0001_initial	2024-02-09 21:13:14.639951+01
390	shop14	0002_customer_is_premium	2024-02-09 21:13:14.64819+01
391	shop14	0003_shippingaddress	2024-02-09 21:13:14.684243+01
392	shop14	0004_migrate_shipping_address	2024-02-09 21:13:14.704322+01
393	shop14	0005_remove_customer_shipping_state	2024-02-09 21:13:14.713007+01
394	shop14	0006_remove_customer_shipping_province	2024-02-09 21:13:14.722362+01
395	shop14	0007_remove_customer_shipping_city	2024-02-09 21:13:14.731434+01
396	shop14	0008_remove_customer_shipping_zip_code	2024-02-09 21:13:14.741401+01
397	shop14	0009_remove_customer_shipping_address	2024-02-09 21:13:14.752674+01
398	shop14	0010_remove_customer_shipping_name	2024-02-09 21:13:14.762252+01
399	shop14	0011_alter_shippingaddress_address_and_more	2024-02-09 21:13:14.774908+01
400	shop14	0012_order	2024-02-09 21:13:14.812419+01
401	shop14	0013_order_created_at	2024-02-09 21:13:14.819579+01
402	shop14	0014_orderline	2024-02-09 21:13:14.851711+01
403	shop14	0015_alter_customer_user	2024-02-09 21:13:14.871613+01
404	shop14	0016_customer_customer_type	2024-02-09 21:13:14.907055+01
405	shop14	0017_migrate_is_premium_to_customer_type	2024-02-09 21:13:14.927141+01
406	shop14	0018_remove_customer_is_premium	2024-02-09 21:13:14.936532+01
407	shop14	0019_alter_customer_customer_type	2024-02-09 21:13:14.945485+01
408	shop14	0020_alter_customer_customer_type	2024-02-09 21:13:14.954662+01
409	shop14	0021_alter_customer_customer_type	2024-02-09 21:13:14.962854+01
410	shop14	0022_alter_customer_customer_type	2024-02-09 21:13:14.971695+01
411	shop14	0023_alter_customer_customer_type	2024-02-09 21:13:14.979743+01
412	shop14	0024_alter_customer_customer_type	2024-02-09 21:13:14.988512+01
413	shop14	0025_rename_product_quantity_orderline_quantity	2024-02-09 21:13:14.994257+01
414	shop14	0026_product	2024-02-09 21:13:15.027456+01
415	shop15	0001_initial	2024-02-09 21:13:15.065562+01
416	shop15	0002_customer_is_premium	2024-02-09 21:13:15.073307+01
417	shop15	0003_shippingaddress	2024-02-09 21:13:15.106683+01
418	shop15	0004_migrate_shipping_address	2024-02-09 21:13:15.125678+01
419	shop15	0005_remove_customer_shipping_state	2024-02-09 21:13:15.134176+01
420	shop15	0006_remove_customer_shipping_province	2024-02-09 21:13:15.141401+01
421	shop15	0007_remove_customer_shipping_city	2024-02-09 21:13:15.151657+01
422	shop15	0008_remove_customer_shipping_zip_code	2024-02-09 21:13:15.18476+01
423	shop15	0009_remove_customer_shipping_address	2024-02-09 21:13:15.194639+01
424	shop15	0010_remove_customer_shipping_name	2024-02-09 21:13:15.205225+01
425	shop15	0011_alter_shippingaddress_address_and_more	2024-02-09 21:13:15.21748+01
426	shop15	0012_order	2024-02-09 21:13:15.255786+01
427	shop15	0013_order_created_at	2024-02-09 21:13:15.26225+01
428	shop15	0014_orderline	2024-02-09 21:13:15.306222+01
429	shop15	0015_alter_customer_user	2024-02-09 21:13:15.328558+01
430	shop15	0016_customer_customer_type	2024-02-09 21:13:15.339874+01
431	shop15	0017_migrate_is_premium_to_customer_type	2024-02-09 21:13:15.361407+01
432	shop15	0018_remove_customer_is_premium	2024-02-09 21:13:15.371873+01
433	shop15	0019_alter_customer_customer_type	2024-02-09 21:13:15.379918+01
434	shop15	0020_alter_customer_customer_type	2024-02-09 21:13:15.388978+01
435	shop15	0021_alter_customer_customer_type	2024-02-09 21:13:15.396804+01
436	shop15	0022_alter_customer_customer_type	2024-02-09 21:13:15.405789+01
437	shop15	0023_alter_customer_customer_type	2024-02-09 21:13:15.413278+01
438	shop15	0024_alter_customer_customer_type	2024-02-09 21:13:15.422973+01
439	shop15	0025_rename_product_quantity_orderline_quantity	2024-02-09 21:13:15.428816+01
440	shop15	0026_product	2024-02-09 21:13:15.491452+01
441	shop16	0001_initial	2024-02-09 21:13:15.524714+01
442	shop16	0002_customer_is_premium	2024-02-09 21:13:15.535419+01
443	shop16	0003_shippingaddress	2024-02-09 21:13:15.571483+01
444	shop16	0004_migrate_shipping_address	2024-02-09 21:13:15.594096+01
445	shop16	0005_remove_customer_shipping_state	2024-02-09 21:13:15.604429+01
446	shop16	0006_remove_customer_shipping_province	2024-02-09 21:13:15.613503+01
447	shop16	0007_remove_customer_shipping_city	2024-02-09 21:13:15.624379+01
448	shop16	0008_remove_customer_shipping_zip_code	2024-02-09 21:13:15.634635+01
449	shop16	0009_remove_customer_shipping_address	2024-02-09 21:13:15.645053+01
450	shop16	0010_remove_customer_shipping_name	2024-02-09 21:13:15.654973+01
451	shop16	0011_alter_shippingaddress_address_and_more	2024-02-09 21:13:15.669587+01
452	shop16	0012_order	2024-02-09 21:13:15.708506+01
453	shop16	0013_order_created_at	2024-02-09 21:13:15.715509+01
454	shop16	0014_orderline	2024-02-09 21:13:15.778631+01
455	shop16	0015_alter_customer_user	2024-02-09 21:13:15.801547+01
456	shop16	0016_customer_customer_type	2024-02-09 21:13:15.81223+01
457	shop16	0017_migrate_is_premium_to_customer_type	2024-02-09 21:13:15.833876+01
458	shop16	0018_remove_customer_is_premium	2024-02-09 21:13:15.844365+01
459	shop16	0019_alter_customer_customer_type	2024-02-09 21:13:15.854435+01
460	shop16	0020_alter_customer_customer_type	2024-02-09 21:13:15.862088+01
461	shop16	0021_alter_customer_customer_type	2024-02-09 21:13:15.871596+01
462	shop16	0022_alter_customer_customer_type	2024-02-09 21:13:15.879507+01
463	shop16	0023_alter_customer_customer_type	2024-02-09 21:13:15.888744+01
464	shop16	0024_alter_customer_customer_type	2024-02-09 21:13:15.897939+01
465	shop16	0025_rename_product_quantity_orderline_quantity	2024-02-09 21:13:15.904271+01
466	shop16	0026_product	2024-02-09 21:13:15.943705+01
467	shop17	0001_initial	2024-02-09 21:13:15.989734+01
468	shop17	0002_customer_is_premium	2024-02-09 21:13:16.000199+01
469	shop17	0003_shippingaddress	2024-02-09 21:13:16.063167+01
470	shop17	0004_migrate_shipping_address	2024-02-09 21:13:16.086457+01
471	shop17	0005_remove_customer_shipping_state	2024-02-09 21:13:16.09582+01
472	shop17	0006_remove_customer_shipping_province	2024-02-09 21:13:16.106282+01
473	shop17	0007_remove_customer_shipping_city	2024-02-09 21:13:16.114749+01
474	shop17	0008_remove_customer_shipping_zip_code	2024-02-09 21:13:16.125067+01
475	shop17	0009_remove_customer_shipping_address	2024-02-09 21:13:16.135466+01
476	shop17	0010_remove_customer_shipping_name	2024-02-09 21:13:16.145399+01
477	shop17	0011_alter_shippingaddress_address_and_more	2024-02-09 21:13:16.15999+01
479	shop17	0013_order_created_at	2024-02-09 21:13:16.206567+01
480	shop17	0014_orderline	2024-02-09 21:13:16.251489+01
481	shop17	0015_alter_customer_user	2024-02-09 21:13:16.273245+01
482	shop17	0016_customer_customer_type	2024-02-09 21:13:16.285157+01
483	shop17	0017_migrate_is_premium_to_customer_type	2024-02-09 21:13:16.306568+01
484	shop17	0018_remove_customer_is_premium	2024-02-09 21:13:16.342636+01
485	shop17	0019_alter_customer_customer_type	2024-02-09 21:13:16.353265+01
486	shop17	0020_alter_customer_customer_type	2024-02-09 21:13:16.362899+01
487	shop17	0021_alter_customer_customer_type	2024-02-09 21:13:16.373424+01
488	shop17	0022_alter_customer_customer_type	2024-02-09 21:13:16.383357+01
489	shop17	0023_alter_customer_customer_type	2024-02-09 21:13:16.394494+01
490	shop17	0024_alter_customer_customer_type	2024-02-09 21:13:16.405062+01
491	shop17	0025_rename_product_quantity_orderline_quantity	2024-02-09 21:13:16.411689+01
492	shop17	0026_product	2024-02-09 21:13:16.450725+01
493	shop18	0001_initial	2024-02-09 21:13:16.488986+01
494	shop18	0002_customer_is_premium	2024-02-09 21:13:16.49994+01
495	shop18	0003_shippingaddress	2024-02-09 21:13:16.542527+01
496	shop18	0004_migrate_shipping_address	2024-02-09 21:13:16.566459+01
497	shop18	0005_remove_customer_shipping_state	2024-02-09 21:13:16.5777+01
498	shop18	0006_remove_customer_shipping_province	2024-02-09 21:13:16.589073+01
499	shop18	0007_remove_customer_shipping_city	2024-02-09 21:13:16.597978+01
500	shop18	0008_remove_customer_shipping_zip_code	2024-02-09 21:13:16.608826+01
501	shop18	0009_remove_customer_shipping_address	2024-02-09 21:13:16.644462+01
502	shop18	0010_remove_customer_shipping_name	2024-02-09 21:13:16.654898+01
503	shop18	0011_alter_shippingaddress_address_and_more	2024-02-09 21:13:16.669758+01
504	shop18	0012_order	2024-02-09 21:13:16.712046+01
505	shop18	0013_order_created_at	2024-02-09 21:13:16.719285+01
506	shop18	0014_orderline	2024-02-09 21:13:16.763737+01
507	shop18	0015_alter_customer_user	2024-02-09 21:13:16.78922+01
508	shop18	0016_customer_customer_type	2024-02-09 21:13:16.801784+01
509	shop18	0017_migrate_is_premium_to_customer_type	2024-02-09 21:13:16.826857+01
510	shop18	0018_remove_customer_is_premium	2024-02-09 21:13:16.837951+01
511	shop18	0019_alter_customer_customer_type	2024-02-09 21:13:16.847498+01
512	shop18	0020_alter_customer_customer_type	2024-02-09 21:13:16.858081+01
513	shop18	0021_alter_customer_customer_type	2024-02-09 21:13:16.869025+01
514	shop18	0022_alter_customer_customer_type	2024-02-09 21:13:16.87872+01
515	shop18	0023_alter_customer_customer_type	2024-02-09 21:13:16.888753+01
516	shop18	0024_alter_customer_customer_type	2024-02-09 21:13:16.898913+01
517	shop18	0025_rename_product_quantity_orderline_quantity	2024-02-09 21:13:16.929357+01
518	shop18	0026_product	2024-02-09 21:13:16.969706+01
519	shop19	0001_initial	2024-02-09 21:13:17.018299+01
520	shop19	0002_customer_is_premium	2024-02-09 21:13:17.028249+01
521	shop19	0003_shippingaddress	2024-02-09 21:13:17.06581+01
522	shop19	0004_migrate_shipping_address	2024-02-09 21:13:17.090312+01
523	shop19	0005_remove_customer_shipping_state	2024-02-09 21:13:17.102612+01
524	shop19	0006_remove_customer_shipping_province	2024-02-09 21:13:17.112192+01
525	shop19	0007_remove_customer_shipping_city	2024-02-09 21:13:17.123027+01
526	shop19	0008_remove_customer_shipping_zip_code	2024-02-09 21:13:17.13481+01
527	shop19	0009_remove_customer_shipping_address	2024-02-09 21:13:17.144923+01
528	shop19	0010_remove_customer_shipping_name	2024-02-09 21:13:17.155313+01
529	shop19	0011_alter_shippingaddress_address_and_more	2024-02-09 21:13:17.17009+01
530	shop19	0012_order	2024-02-09 21:13:17.22439+01
531	shop19	0013_order_created_at	2024-02-09 21:13:17.233379+01
532	shop19	0014_orderline	2024-02-09 21:13:17.271596+01
533	shop19	0015_alter_customer_user	2024-02-09 21:13:17.297411+01
534	shop19	0016_customer_customer_type	2024-02-09 21:13:17.309653+01
535	shop19	0017_migrate_is_premium_to_customer_type	2024-02-09 21:13:17.33361+01
536	shop19	0018_remove_customer_is_premium	2024-02-09 21:13:17.345202+01
537	shop19	0019_alter_customer_customer_type	2024-02-09 21:13:17.356945+01
538	shop19	0020_alter_customer_customer_type	2024-02-09 21:13:17.367713+01
539	shop19	0021_alter_customer_customer_type	2024-02-09 21:13:17.378902+01
540	shop19	0022_alter_customer_customer_type	2024-02-09 21:13:17.389564+01
541	shop19	0023_alter_customer_customer_type	2024-02-09 21:13:17.400371+01
542	shop19	0024_alter_customer_customer_type	2024-02-09 21:13:17.412055+01
543	shop19	0025_rename_product_quantity_orderline_quantity	2024-02-09 21:13:17.418471+01
544	shop19	0026_product	2024-02-09 21:13:17.462486+01
545	shop20	0001_initial	2024-02-09 21:13:17.533284+01
546	shop20	0002_customer_is_premium	2024-02-09 21:13:17.545568+01
547	shop20	0003_shippingaddress	2024-02-09 21:13:17.587375+01
548	shop20	0004_migrate_shipping_address	2024-02-09 21:13:17.614034+01
549	shop20	0005_remove_customer_shipping_state	2024-02-09 21:13:17.625739+01
550	shop20	0006_remove_customer_shipping_province	2024-02-09 21:13:17.637085+01
551	shop20	0007_remove_customer_shipping_city	2024-02-09 21:13:17.646356+01
552	shop20	0008_remove_customer_shipping_zip_code	2024-02-09 21:13:17.657686+01
553	shop20	0009_remove_customer_shipping_address	2024-02-09 21:13:17.669194+01
554	shop20	0010_remove_customer_shipping_name	2024-02-09 21:13:17.679185+01
555	shop20	0011_alter_shippingaddress_address_and_more	2024-02-09 21:13:17.694508+01
556	shop20	0012_order	2024-02-09 21:13:17.738869+01
557	shop20	0013_order_created_at	2024-02-09 21:13:17.745503+01
558	shop20	0014_orderline	2024-02-09 21:13:17.810412+01
559	shop20	0015_alter_customer_user	2024-02-09 21:13:17.836153+01
560	shop20	0016_customer_customer_type	2024-02-09 21:13:17.84618+01
561	shop20	0017_migrate_is_premium_to_customer_type	2024-02-09 21:13:17.871765+01
562	shop20	0018_remove_customer_is_premium	2024-02-09 21:13:17.881716+01
563	shop20	0019_alter_customer_customer_type	2024-02-09 21:13:17.892165+01
564	shop20	0020_alter_customer_customer_type	2024-02-09 21:13:17.903427+01
565	shop20	0021_alter_customer_customer_type	2024-02-09 21:13:17.912659+01
566	shop20	0022_alter_customer_customer_type	2024-02-09 21:13:17.923571+01
567	shop20	0023_alter_customer_customer_type	2024-02-09 21:13:17.935202+01
568	shop20	0024_alter_customer_customer_type	2024-02-09 21:13:17.945668+01
569	shop20	0025_rename_product_quantity_orderline_quantity	2024-02-09 21:13:17.952606+01
570	shop20	0026_product	2024-02-09 21:13:17.995919+01
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.


--
-- Data for Name: main_follow; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.main_follow (id, created_at, created_by_id, user_followed_id) FROM stdin;
\.


--
-- Data for Name: main_like; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.main_like (id, created_at, created_by_id, tweet_id) FROM stdin;
\.


--
-- Data for Name: main_tweet; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.main_tweet (id, created_at, text, created_by_id, related_tweet_id) FROM stdin;
\.


--
-- Data for Name: shop01_customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop01_customer (id, user_id, customer_type) FROM stdin;
\.


--
-- Data for Name: shop01_order; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop01_order (id, shipping_name, shipping_address, shipping_zip_code, shipping_city, shipping_province, shipping_state, customer_id, created_at) FROM stdin;
\.


--
-- Data for Name: shop01_orderline; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop01_orderline (id, product_name, product_um, quantity, product_unit_price, order_id) FROM stdin;
\.


--
-- Data for Name: shop01_product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop01_product (id, name, um, unit_price, customer_id) FROM stdin;
\.


--
-- Data for Name: shop01_shippingaddress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop01_shippingaddress (id, name, address, zip_code, city, province, state, customer_id) FROM stdin;
\.


--
-- Data for Name: shop02_customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop02_customer (id, user_id, customer_type) FROM stdin;
\.


--
-- Data for Name: shop02_order; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop02_order (id, shipping_name, shipping_address, shipping_zip_code, shipping_city, shipping_province, shipping_state, customer_id, created_at) FROM stdin;
\.


--
-- Data for Name: shop02_orderline; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop02_orderline (id, product_name, product_um, quantity, product_unit_price, order_id) FROM stdin;
\.


--
-- Data for Name: shop02_product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop02_product (id, name, um, unit_price, customer_id) FROM stdin;
\.


--
-- Data for Name: shop02_shippingaddress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop02_shippingaddress (id, name, address, zip_code, city, province, state, customer_id) FROM stdin;
\.


--
-- Data for Name: shop03_customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop03_customer (id, user_id, customer_type) FROM stdin;
\.


--
-- Data for Name: shop03_order; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop03_order (id, shipping_name, shipping_address, shipping_zip_code, shipping_city, shipping_province, shipping_state, customer_id, created_at) FROM stdin;
\.


--
-- Data for Name: shop03_orderline; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop03_orderline (id, product_name, product_um, quantity, product_unit_price, order_id) FROM stdin;
\.


--
-- Data for Name: shop03_product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop03_product (id, name, um, unit_price, customer_id) FROM stdin;
\.


--
-- Data for Name: shop03_shippingaddress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop03_shippingaddress (id, name, address, zip_code, city, province, state, customer_id) FROM stdin;
\.


--
-- Data for Name: shop04_customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop04_customer (id, user_id, customer_type) FROM stdin;
\.


--
-- Data for Name: shop04_order; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop04_order (id, shipping_name, shipping_address, shipping_zip_code, shipping_city, shipping_province, shipping_state, customer_id, created_at) FROM stdin;
\.


--
-- Data for Name: shop04_orderline; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop04_orderline (id, product_name, product_um, quantity, product_unit_price, order_id) FROM stdin;
\.


--
-- Data for Name: shop04_product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop04_product (id, name, um, unit_price, customer_id) FROM stdin;
\.


--
-- Data for Name: shop04_shippingaddress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop04_shippingaddress (id, name, address, zip_code, city, province, state, customer_id) FROM stdin;
\.


--
-- Data for Name: shop05_customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop05_customer (id, user_id, customer_type) FROM stdin;
\.


--
-- Data for Name: shop05_order; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop05_order (id, shipping_name, shipping_address, shipping_zip_code, shipping_city, shipping_province, shipping_state, customer_id, created_at) FROM stdin;
\.


--
-- Data for Name: shop05_orderline; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop05_orderline (id, product_name, product_um, quantity, product_unit_price, order_id) FROM stdin;
\.


--
-- Data for Name: shop05_product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop05_product (id, name, um, unit_price, customer_id) FROM stdin;
\.


--
-- Data for Name: shop05_shippingaddress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop05_shippingaddress (id, name, address, zip_code, city, province, state, customer_id) FROM stdin;
\.


--
-- Data for Name: shop06_customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop06_customer (id, user_id, customer_type) FROM stdin;
\.


--
-- Data for Name: shop06_order; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop06_order (id, shipping_name, shipping_address, shipping_zip_code, shipping_city, shipping_province, shipping_state, customer_id, created_at) FROM stdin;
\.


--
-- Data for Name: shop06_orderline; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop06_orderline (id, product_name, product_um, quantity, product_unit_price, order_id) FROM stdin;
\.


--
-- Data for Name: shop06_product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop06_product (id, name, um, unit_price, customer_id) FROM stdin;
\.


--
-- Data for Name: shop06_shippingaddress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop06_shippingaddress (id, name, address, zip_code, city, province, state, customer_id) FROM stdin;
\.


--
-- Data for Name: shop07_customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop07_customer (id, user_id, customer_type) FROM stdin;
\.


--
-- Data for Name: shop07_order; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop07_order (id, shipping_name, shipping_address, shipping_zip_code, shipping_city, shipping_province, shipping_state, customer_id, created_at) FROM stdin;
\.


--
-- Data for Name: shop07_orderline; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop07_orderline (id, product_name, product_um, quantity, product_unit_price, order_id) FROM stdin;
\.


--
-- Data for Name: shop07_product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop07_product (id, name, um, unit_price, customer_id) FROM stdin;
\.


--
-- Data for Name: shop07_shippingaddress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop07_shippingaddress (id, name, address, zip_code, city, province, state, customer_id) FROM stdin;
\.


--
-- Data for Name: shop08_customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop08_customer (id, user_id, customer_type) FROM stdin;
\.


--
-- Data for Name: shop08_order; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop08_order (id, shipping_name, shipping_address, shipping_zip_code, shipping_city, shipping_province, shipping_state, customer_id, created_at) FROM stdin;
\.


--
-- Data for Name: shop08_orderline; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop08_orderline (id, product_name, product_um, quantity, product_unit_price, order_id) FROM stdin;
\.


--
-- Data for Name: shop08_product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop08_product (id, name, um, unit_price, customer_id) FROM stdin;
\.


--
-- Data for Name: shop08_shippingaddress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop08_shippingaddress (id, name, address, zip_code, city, province, state, customer_id) FROM stdin;
\.


--
-- Data for Name: shop09_customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop09_customer (id, user_id, customer_type) FROM stdin;
\.


--
-- Data for Name: shop09_order; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop09_order (id, shipping_name, shipping_address, shipping_zip_code, shipping_city, shipping_province, shipping_state, customer_id, created_at) FROM stdin;
\.


--
-- Data for Name: shop09_orderline; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop09_orderline (id, product_name, product_um, quantity, product_unit_price, order_id) FROM stdin;
\.


--
-- Data for Name: shop09_product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop09_product (id, name, um, unit_price, customer_id) FROM stdin;
\.


--
-- Data for Name: shop09_shippingaddress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop09_shippingaddress (id, name, address, zip_code, city, province, state, customer_id) FROM stdin;
\.


--
-- Data for Name: shop10_customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop10_customer (id, user_id, customer_type) FROM stdin;
\.


--
-- Data for Name: shop10_order; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop10_order (id, shipping_name, shipping_address, shipping_zip_code, shipping_city, shipping_province, shipping_state, customer_id, created_at) FROM stdin;
\.


--
-- Data for Name: shop10_orderline; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop10_orderline (id, product_name, product_um, quantity, product_unit_price, order_id) FROM stdin;
\.


--
-- Data for Name: shop10_product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop10_product (id, name, um, unit_price, customer_id) FROM stdin;
\.


--
-- Data for Name: shop10_shippingaddress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop10_shippingaddress (id, name, address, zip_code, city, province, state, customer_id) FROM stdin;
\.


--
-- Data for Name: shop11_customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop11_customer (id, user_id, customer_type) FROM stdin;
\.


--
-- Data for Name: shop11_order; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop11_order (id, shipping_name, shipping_address, shipping_zip_code, shipping_city, shipping_province, shipping_state, customer_id, created_at) FROM stdin;
\.


--
-- Data for Name: shop11_orderline; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop11_orderline (id, product_name, product_um, quantity, product_unit_price, order_id) FROM stdin;
\.


--
-- Data for Name: shop11_product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop11_product (id, name, um, unit_price, customer_id) FROM stdin;
\.


--
-- Data for Name: shop11_shippingaddress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop11_shippingaddress (id, name, address, zip_code, city, province, state, customer_id) FROM stdin;
\.


--
-- Data for Name: shop12_customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop12_customer (id, user_id, customer_type) FROM stdin;
\.


--
-- Data for Name: shop12_order; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop12_order (id, shipping_name, shipping_address, shipping_zip_code, shipping_city, shipping_province, shipping_state, customer_id, created_at) FROM stdin;
\.


--
-- Data for Name: shop12_orderline; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop12_orderline (id, product_name, product_um, quantity, product_unit_price, order_id) FROM stdin;
\.


--
-- Data for Name: shop12_product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop12_product (id, name, um, unit_price, customer_id) FROM stdin;
\.


--
-- Data for Name: shop12_shippingaddress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop12_shippingaddress (id, name, address, zip_code, city, province, state, customer_id) FROM stdin;
\.


--
-- Data for Name: shop13_customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop13_customer (id, user_id, customer_type) FROM stdin;
\.


--
-- Data for Name: shop13_order; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop13_order (id, shipping_name, shipping_address, shipping_zip_code, shipping_city, shipping_province, shipping_state, customer_id, created_at) FROM stdin;
\.


--
-- Data for Name: shop13_orderline; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop13_orderline (id, product_name, product_um, quantity, product_unit_price, order_id) FROM stdin;
\.


--
-- Data for Name: shop13_product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop13_product (id, name, um, unit_price, customer_id) FROM stdin;
\.


--
-- Data for Name: shop13_shippingaddress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop13_shippingaddress (id, name, address, zip_code, city, province, state, customer_id) FROM stdin;
\.


--
-- Data for Name: shop14_customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop14_customer (id, user_id, customer_type) FROM stdin;
\.


--
-- Data for Name: shop14_order; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop14_order (id, shipping_name, shipping_address, shipping_zip_code, shipping_city, shipping_province, shipping_state, customer_id, created_at) FROM stdin;
\.


--
-- Data for Name: shop14_orderline; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop14_orderline (id, product_name, product_um, quantity, product_unit_price, order_id) FROM stdin;
\.


--
-- Data for Name: shop14_product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop14_product (id, name, um, unit_price, customer_id) FROM stdin;
\.


--
-- Data for Name: shop14_shippingaddress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop14_shippingaddress (id, name, address, zip_code, city, province, state, customer_id) FROM stdin;
\.


--
-- Data for Name: shop15_customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop15_customer (id, user_id, customer_type) FROM stdin;
\.


--
-- Data for Name: shop15_order; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop15_order (id, shipping_name, shipping_address, shipping_zip_code, shipping_city, shipping_province, shipping_state, customer_id, created_at) FROM stdin;
\.


--
-- Data for Name: shop15_orderline; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop15_orderline (id, product_name, product_um, quantity, product_unit_price, order_id) FROM stdin;
\.


--
-- Data for Name: shop15_product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop15_product (id, name, um, unit_price, customer_id) FROM stdin;
\.


--
-- Data for Name: shop15_shippingaddress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop15_shippingaddress (id, name, address, zip_code, city, province, state, customer_id) FROM stdin;
\.


--
-- Data for Name: shop16_customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop16_customer (id, user_id, customer_type) FROM stdin;
\.


--
-- Data for Name: shop16_order; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop16_order (id, shipping_name, shipping_address, shipping_zip_code, shipping_city, shipping_province, shipping_state, customer_id, created_at) FROM stdin;
\.


--
-- Data for Name: shop16_orderline; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop16_orderline (id, product_name, product_um, quantity, product_unit_price, order_id) FROM stdin;
\.


--
-- Data for Name: shop16_product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop16_product (id, name, um, unit_price, customer_id) FROM stdin;
\.


--
-- Data for Name: shop16_shippingaddress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop16_shippingaddress (id, name, address, zip_code, city, province, state, customer_id) FROM stdin;
\.


--
-- Data for Name: shop17_customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop17_customer (id, user_id, customer_type) FROM stdin;
\.


--
-- Data for Name: shop17_order; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop17_order (id, shipping_name, shipping_address, shipping_zip_code, shipping_city, shipping_province, shipping_state, customer_id, created_at) FROM stdin;
\.


--
-- Data for Name: shop17_orderline; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop17_orderline (id, product_name, product_um, quantity, product_unit_price, order_id) FROM stdin;
\.


--
-- Data for Name: shop17_product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop17_product (id, name, um, unit_price, customer_id) FROM stdin;
\.


--
-- Data for Name: shop17_shippingaddress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop17_shippingaddress (id, name, address, zip_code, city, province, state, customer_id) FROM stdin;
\.


--
-- Data for Name: shop18_customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop18_customer (id, user_id, customer_type) FROM stdin;
\.


--
-- Data for Name: shop18_order; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop18_order (id, shipping_name, shipping_address, shipping_zip_code, shipping_city, shipping_province, shipping_state, customer_id, created_at) FROM stdin;
\.


--
-- Data for Name: shop18_orderline; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop18_orderline (id, product_name, product_um, quantity, product_unit_price, order_id) FROM stdin;
\.


--
-- Data for Name: shop18_product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop18_product (id, name, um, unit_price, customer_id) FROM stdin;
\.


--
-- Data for Name: shop18_shippingaddress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop18_shippingaddress (id, name, address, zip_code, city, province, state, customer_id) FROM stdin;
\.


--
-- Data for Name: shop19_customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop19_customer (id, user_id, customer_type) FROM stdin;
\.


--
-- Data for Name: shop19_order; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop19_order (id, shipping_name, shipping_address, shipping_zip_code, shipping_city, shipping_province, shipping_state, customer_id, created_at) FROM stdin;
\.


--
-- Data for Name: shop19_orderline; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop19_orderline (id, product_name, product_um, quantity, product_unit_price, order_id) FROM stdin;
\.


--
-- Data for Name: shop19_product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop19_product (id, name, um, unit_price, customer_id) FROM stdin;
\.


--
-- Data for Name: shop19_shippingaddress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop19_shippingaddress (id, name, address, zip_code, city, province, state, customer_id) FROM stdin;
\.


--
-- Data for Name: shop20_customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop20_customer (id, user_id, customer_type) FROM stdin;
\.


--
-- Data for Name: shop20_order; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop20_order (id, shipping_name, shipping_address, shipping_zip_code, shipping_city, shipping_province, shipping_state, customer_id, created_at) FROM stdin;
\.


--
-- Data for Name: shop20_orderline; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop20_orderline (id, product_name, product_um, quantity, product_unit_price, order_id) FROM stdin;
\.


--
-- Data for Name: shop20_product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop20_product (id, name, um, unit_price, customer_id) FROM stdin;
\.


--
-- Data for Name: shop20_shippingaddress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop20_shippingaddress (id, name, address, zip_code, city, province, state, customer_id) FROM stdin;
\.


--
-- Data for Name: shop_customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop_customer (id, user_id, customer_type) FROM stdin;
\.


--
-- Data for Name: shop_order; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop_order (id, shipping_name, shipping_address, shipping_zip_code, shipping_city, shipping_province, shipping_state, customer_id, created_at) FROM stdin;
\.


--
-- Data for Name: shop_orderline; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop_orderline (id, product_name, product_um, quantity, product_unit_price, order_id) FROM stdin;
\.


--
-- Data for Name: shop_product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop_product (id, name, um, unit_price, customer_id) FROM stdin;
\.


--
-- Data for Name: shop_shippingaddress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop_shippingaddress (id, name, address, zip_code, city, province, state, customer_id) FROM stdin;
\.


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 456, true);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 1, false);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 1, false);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 114, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 570, true);


--
-- Name: main_follow_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.main_follow_id_seq', 1, false);


--
-- Name: main_like_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.main_like_id_seq', 1, false);


--
-- Name: main_tweet_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.main_tweet_id_seq', 1, false);


--
-- Name: shop01_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop01_customer_id_seq', 1, false);


--
-- Name: shop01_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop01_order_id_seq', 1, false);


--
-- Name: shop01_orderline_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop01_orderline_id_seq', 1, false);


--
-- Name: shop01_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop01_product_id_seq', 1, false);


--
-- Name: shop01_shippingaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop01_shippingaddress_id_seq', 1, false);


--
-- Name: shop02_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop02_customer_id_seq', 1, false);


--
-- Name: shop02_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop02_order_id_seq', 1, false);


--
-- Name: shop02_orderline_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop02_orderline_id_seq', 1, false);


--
-- Name: shop02_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop02_product_id_seq', 1, false);


--
-- Name: shop02_shippingaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop02_shippingaddress_id_seq', 1, false);


--
-- Name: shop03_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop03_customer_id_seq', 1, false);


--
-- Name: shop03_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop03_order_id_seq', 1, false);


--
-- Name: shop03_orderline_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop03_orderline_id_seq', 1, false);


--
-- Name: shop03_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop03_product_id_seq', 1, false);


--
-- Name: shop03_shippingaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop03_shippingaddress_id_seq', 1, false);


--
-- Name: shop04_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop04_customer_id_seq', 1, false);


--
-- Name: shop04_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop04_order_id_seq', 1, false);


--
-- Name: shop04_orderline_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop04_orderline_id_seq', 1, false);


--
-- Name: shop04_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop04_product_id_seq', 1, false);


--
-- Name: shop04_shippingaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop04_shippingaddress_id_seq', 1, false);


--
-- Name: shop05_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop05_customer_id_seq', 1, false);


--
-- Name: shop05_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop05_order_id_seq', 1, false);


--
-- Name: shop05_orderline_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop05_orderline_id_seq', 1, false);


--
-- Name: shop05_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop05_product_id_seq', 1, false);


--
-- Name: shop05_shippingaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop05_shippingaddress_id_seq', 1, false);


--
-- Name: shop06_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop06_customer_id_seq', 1, false);


--
-- Name: shop06_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop06_order_id_seq', 1, false);


--
-- Name: shop06_orderline_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop06_orderline_id_seq', 1, false);


--
-- Name: shop06_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop06_product_id_seq', 1, false);


--
-- Name: shop06_shippingaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop06_shippingaddress_id_seq', 1, false);


--
-- Name: shop07_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop07_customer_id_seq', 1, false);


--
-- Name: shop07_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop07_order_id_seq', 1, false);


--
-- Name: shop07_orderline_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop07_orderline_id_seq', 1, false);


--
-- Name: shop07_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop07_product_id_seq', 1, false);


--
-- Name: shop07_shippingaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop07_shippingaddress_id_seq', 1, false);


--
-- Name: shop08_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop08_customer_id_seq', 1, false);


--
-- Name: shop08_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop08_order_id_seq', 1, false);


--
-- Name: shop08_orderline_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop08_orderline_id_seq', 1, false);


--
-- Name: shop08_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop08_product_id_seq', 1, false);


--
-- Name: shop08_shippingaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop08_shippingaddress_id_seq', 1, false);


--
-- Name: shop09_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop09_customer_id_seq', 1, false);


--
-- Name: shop09_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop09_order_id_seq', 1, false);


--
-- Name: shop09_orderline_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop09_orderline_id_seq', 1, false);


--
-- Name: shop09_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop09_product_id_seq', 1, false);


--
-- Name: shop09_shippingaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop09_shippingaddress_id_seq', 1, false);


--
-- Name: shop10_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop10_customer_id_seq', 1, false);


--
-- Name: shop10_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop10_order_id_seq', 1, false);


--
-- Name: shop10_orderline_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop10_orderline_id_seq', 1, false);


--
-- Name: shop10_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop10_product_id_seq', 1, false);


--
-- Name: shop10_shippingaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop10_shippingaddress_id_seq', 1, false);


--
-- Name: shop11_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop11_customer_id_seq', 1, false);


--
-- Name: shop11_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop11_order_id_seq', 1, false);


--
-- Name: shop11_orderline_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop11_orderline_id_seq', 1, false);


--
-- Name: shop11_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop11_product_id_seq', 1, false);


--
-- Name: shop11_shippingaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop11_shippingaddress_id_seq', 1, false);


--
-- Name: shop12_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop12_customer_id_seq', 1, false);


--
-- Name: shop12_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop12_order_id_seq', 1, false);


--
-- Name: shop12_orderline_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop12_orderline_id_seq', 1, false);


--
-- Name: shop12_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop12_product_id_seq', 1, false);


--
-- Name: shop12_shippingaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop12_shippingaddress_id_seq', 1, false);


--
-- Name: shop13_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop13_customer_id_seq', 1, false);


--
-- Name: shop13_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop13_order_id_seq', 1, false);


--
-- Name: shop13_orderline_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop13_orderline_id_seq', 1, false);


--
-- Name: shop13_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop13_product_id_seq', 1, false);


--
-- Name: shop13_shippingaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop13_shippingaddress_id_seq', 1, false);


--
-- Name: shop14_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop14_customer_id_seq', 1, false);


--
-- Name: shop14_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop14_order_id_seq', 1, false);


--
-- Name: shop14_orderline_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop14_orderline_id_seq', 1, false);


--
-- Name: shop14_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop14_product_id_seq', 1, false);


--
-- Name: shop14_shippingaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop14_shippingaddress_id_seq', 1, false);


--
-- Name: shop15_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop15_customer_id_seq', 1, false);


--
-- Name: shop15_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop15_order_id_seq', 1, false);


--
-- Name: shop15_orderline_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop15_orderline_id_seq', 1, false);


--
-- Name: shop15_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop15_product_id_seq', 1, false);


--
-- Name: shop15_shippingaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop15_shippingaddress_id_seq', 1, false);


--
-- Name: shop16_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop16_customer_id_seq', 1, false);


--
-- Name: shop16_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop16_order_id_seq', 1, false);


--
-- Name: shop16_orderline_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop16_orderline_id_seq', 1, false);


--
-- Name: shop16_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop16_product_id_seq', 1, false);


--
-- Name: shop16_shippingaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop16_shippingaddress_id_seq', 1, false);


--
-- Name: shop17_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop17_customer_id_seq', 1, false);


--
-- Name: shop17_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop17_order_id_seq', 1, false);


--
-- Name: shop17_orderline_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop17_orderline_id_seq', 1, false);


--
-- Name: shop17_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop17_product_id_seq', 1, false);


--
-- Name: shop17_shippingaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop17_shippingaddress_id_seq', 1, false);


--
-- Name: shop18_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop18_customer_id_seq', 1, false);


--
-- Name: shop18_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop18_order_id_seq', 1, false);


--
-- Name: shop18_orderline_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop18_orderline_id_seq', 1, false);


--
-- Name: shop18_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop18_product_id_seq', 1, false);


--
-- Name: shop18_shippingaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop18_shippingaddress_id_seq', 1, false);


--
-- Name: shop19_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop19_customer_id_seq', 1, false);


--
-- Name: shop19_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop19_order_id_seq', 1, false);


--
-- Name: shop19_orderline_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop19_orderline_id_seq', 1, false);


--
-- Name: shop19_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop19_product_id_seq', 1, false);


--
-- Name: shop19_shippingaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop19_shippingaddress_id_seq', 1, false);


--
-- Name: shop20_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop20_customer_id_seq', 1, false);


--
-- Name: shop20_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop20_order_id_seq', 1, false);


--
-- Name: shop20_orderline_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop20_orderline_id_seq', 1, false);


--
-- Name: shop20_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop20_product_id_seq', 1, false);


--
-- Name: shop20_shippingaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop20_shippingaddress_id_seq', 1, false);


--
-- Name: shop_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop_customer_id_seq', 1, false);


--
-- Name: shop_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop_order_id_seq', 1, false);


--
-- Name: shop_orderline_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop_orderline_id_seq', 1, false);


--
-- Name: shop_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop_product_id_seq', 1, false);


--
-- Name: shop_shippingaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop_shippingaddress_id_seq', 1, false);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: main_follow main_follow_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.main_follow
    ADD CONSTRAINT main_follow_pkey PRIMARY KEY (id);


--
-- Name: main_like main_like_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.main_like
    ADD CONSTRAINT main_like_pkey PRIMARY KEY (id);


--
-- Name: main_like main_like_tweet_id_created_by_id_f64e321e_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.main_like
    ADD CONSTRAINT main_like_tweet_id_created_by_id_f64e321e_uniq UNIQUE (tweet_id, created_by_id);


--
-- Name: main_tweet main_tweet_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.main_tweet
    ADD CONSTRAINT main_tweet_pkey PRIMARY KEY (id);


--
-- Name: shop01_customer shop01_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop01_customer
    ADD CONSTRAINT shop01_customer_pkey PRIMARY KEY (id);


--
-- Name: shop01_customer shop01_customer_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop01_customer
    ADD CONSTRAINT shop01_customer_user_id_key UNIQUE (user_id);


--
-- Name: shop01_order shop01_order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop01_order
    ADD CONSTRAINT shop01_order_pkey PRIMARY KEY (id);


--
-- Name: shop01_orderline shop01_orderline_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop01_orderline
    ADD CONSTRAINT shop01_orderline_pkey PRIMARY KEY (id);


--
-- Name: shop01_product shop01_product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop01_product
    ADD CONSTRAINT shop01_product_pkey PRIMARY KEY (id);


--
-- Name: shop01_shippingaddress shop01_shippingaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop01_shippingaddress
    ADD CONSTRAINT shop01_shippingaddress_pkey PRIMARY KEY (id);


--
-- Name: shop02_customer shop02_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop02_customer
    ADD CONSTRAINT shop02_customer_pkey PRIMARY KEY (id);


--
-- Name: shop02_customer shop02_customer_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop02_customer
    ADD CONSTRAINT shop02_customer_user_id_key UNIQUE (user_id);


--
-- Name: shop02_order shop02_order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop02_order
    ADD CONSTRAINT shop02_order_pkey PRIMARY KEY (id);


--
-- Name: shop02_orderline shop02_orderline_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop02_orderline
    ADD CONSTRAINT shop02_orderline_pkey PRIMARY KEY (id);


--
-- Name: shop02_product shop02_product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop02_product
    ADD CONSTRAINT shop02_product_pkey PRIMARY KEY (id);


--
-- Name: shop02_shippingaddress shop02_shippingaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop02_shippingaddress
    ADD CONSTRAINT shop02_shippingaddress_pkey PRIMARY KEY (id);


--
-- Name: shop03_customer shop03_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop03_customer
    ADD CONSTRAINT shop03_customer_pkey PRIMARY KEY (id);


--
-- Name: shop03_customer shop03_customer_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop03_customer
    ADD CONSTRAINT shop03_customer_user_id_key UNIQUE (user_id);


--
-- Name: shop03_order shop03_order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop03_order
    ADD CONSTRAINT shop03_order_pkey PRIMARY KEY (id);


--
-- Name: shop03_orderline shop03_orderline_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop03_orderline
    ADD CONSTRAINT shop03_orderline_pkey PRIMARY KEY (id);


--
-- Name: shop03_product shop03_product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop03_product
    ADD CONSTRAINT shop03_product_pkey PRIMARY KEY (id);


--
-- Name: shop03_shippingaddress shop03_shippingaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop03_shippingaddress
    ADD CONSTRAINT shop03_shippingaddress_pkey PRIMARY KEY (id);


--
-- Name: shop04_customer shop04_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop04_customer
    ADD CONSTRAINT shop04_customer_pkey PRIMARY KEY (id);


--
-- Name: shop04_customer shop04_customer_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop04_customer
    ADD CONSTRAINT shop04_customer_user_id_key UNIQUE (user_id);


--
-- Name: shop04_order shop04_order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop04_order
    ADD CONSTRAINT shop04_order_pkey PRIMARY KEY (id);


--
-- Name: shop04_orderline shop04_orderline_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop04_orderline
    ADD CONSTRAINT shop04_orderline_pkey PRIMARY KEY (id);


--
-- Name: shop04_product shop04_product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop04_product
    ADD CONSTRAINT shop04_product_pkey PRIMARY KEY (id);


--
-- Name: shop04_shippingaddress shop04_shippingaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop04_shippingaddress
    ADD CONSTRAINT shop04_shippingaddress_pkey PRIMARY KEY (id);


--
-- Name: shop05_customer shop05_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop05_customer
    ADD CONSTRAINT shop05_customer_pkey PRIMARY KEY (id);


--
-- Name: shop05_customer shop05_customer_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop05_customer
    ADD CONSTRAINT shop05_customer_user_id_key UNIQUE (user_id);


--
-- Name: shop05_order shop05_order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop05_order
    ADD CONSTRAINT shop05_order_pkey PRIMARY KEY (id);


--
-- Name: shop05_orderline shop05_orderline_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop05_orderline
    ADD CONSTRAINT shop05_orderline_pkey PRIMARY KEY (id);


--
-- Name: shop05_product shop05_product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop05_product
    ADD CONSTRAINT shop05_product_pkey PRIMARY KEY (id);


--
-- Name: shop05_shippingaddress shop05_shippingaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop05_shippingaddress
    ADD CONSTRAINT shop05_shippingaddress_pkey PRIMARY KEY (id);


--
-- Name: shop06_customer shop06_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop06_customer
    ADD CONSTRAINT shop06_customer_pkey PRIMARY KEY (id);


--
-- Name: shop06_customer shop06_customer_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop06_customer
    ADD CONSTRAINT shop06_customer_user_id_key UNIQUE (user_id);


--
-- Name: shop06_order shop06_order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop06_order
    ADD CONSTRAINT shop06_order_pkey PRIMARY KEY (id);


--
-- Name: shop06_orderline shop06_orderline_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop06_orderline
    ADD CONSTRAINT shop06_orderline_pkey PRIMARY KEY (id);


--
-- Name: shop06_product shop06_product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop06_product
    ADD CONSTRAINT shop06_product_pkey PRIMARY KEY (id);


--
-- Name: shop06_shippingaddress shop06_shippingaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop06_shippingaddress
    ADD CONSTRAINT shop06_shippingaddress_pkey PRIMARY KEY (id);


--
-- Name: shop07_customer shop07_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop07_customer
    ADD CONSTRAINT shop07_customer_pkey PRIMARY KEY (id);


--
-- Name: shop07_customer shop07_customer_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop07_customer
    ADD CONSTRAINT shop07_customer_user_id_key UNIQUE (user_id);


--
-- Name: shop07_order shop07_order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop07_order
    ADD CONSTRAINT shop07_order_pkey PRIMARY KEY (id);


--
-- Name: shop07_orderline shop07_orderline_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop07_orderline
    ADD CONSTRAINT shop07_orderline_pkey PRIMARY KEY (id);


--
-- Name: shop07_product shop07_product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop07_product
    ADD CONSTRAINT shop07_product_pkey PRIMARY KEY (id);


--
-- Name: shop07_shippingaddress shop07_shippingaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop07_shippingaddress
    ADD CONSTRAINT shop07_shippingaddress_pkey PRIMARY KEY (id);


--
-- Name: shop08_customer shop08_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop08_customer
    ADD CONSTRAINT shop08_customer_pkey PRIMARY KEY (id);


--
-- Name: shop08_customer shop08_customer_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop08_customer
    ADD CONSTRAINT shop08_customer_user_id_key UNIQUE (user_id);


--
-- Name: shop08_order shop08_order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop08_order
    ADD CONSTRAINT shop08_order_pkey PRIMARY KEY (id);


--
-- Name: shop08_orderline shop08_orderline_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop08_orderline
    ADD CONSTRAINT shop08_orderline_pkey PRIMARY KEY (id);


--
-- Name: shop08_product shop08_product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop08_product
    ADD CONSTRAINT shop08_product_pkey PRIMARY KEY (id);


--
-- Name: shop08_shippingaddress shop08_shippingaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop08_shippingaddress
    ADD CONSTRAINT shop08_shippingaddress_pkey PRIMARY KEY (id);


--
-- Name: shop09_customer shop09_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop09_customer
    ADD CONSTRAINT shop09_customer_pkey PRIMARY KEY (id);


--
-- Name: shop09_customer shop09_customer_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop09_customer
    ADD CONSTRAINT shop09_customer_user_id_key UNIQUE (user_id);


--
-- Name: shop09_order shop09_order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop09_order
    ADD CONSTRAINT shop09_order_pkey PRIMARY KEY (id);


--
-- Name: shop09_orderline shop09_orderline_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop09_orderline
    ADD CONSTRAINT shop09_orderline_pkey PRIMARY KEY (id);


--
-- Name: shop09_product shop09_product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop09_product
    ADD CONSTRAINT shop09_product_pkey PRIMARY KEY (id);


--
-- Name: shop09_shippingaddress shop09_shippingaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop09_shippingaddress
    ADD CONSTRAINT shop09_shippingaddress_pkey PRIMARY KEY (id);


--
-- Name: shop10_customer shop10_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop10_customer
    ADD CONSTRAINT shop10_customer_pkey PRIMARY KEY (id);


--
-- Name: shop10_customer shop10_customer_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop10_customer
    ADD CONSTRAINT shop10_customer_user_id_key UNIQUE (user_id);


--
-- Name: shop10_order shop10_order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop10_order
    ADD CONSTRAINT shop10_order_pkey PRIMARY KEY (id);


--
-- Name: shop10_orderline shop10_orderline_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop10_orderline
    ADD CONSTRAINT shop10_orderline_pkey PRIMARY KEY (id);


--
-- Name: shop10_product shop10_product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop10_product
    ADD CONSTRAINT shop10_product_pkey PRIMARY KEY (id);


--
-- Name: shop10_shippingaddress shop10_shippingaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop10_shippingaddress
    ADD CONSTRAINT shop10_shippingaddress_pkey PRIMARY KEY (id);


--
-- Name: shop11_customer shop11_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop11_customer
    ADD CONSTRAINT shop11_customer_pkey PRIMARY KEY (id);


--
-- Name: shop11_customer shop11_customer_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop11_customer
    ADD CONSTRAINT shop11_customer_user_id_key UNIQUE (user_id);


--
-- Name: shop11_order shop11_order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop11_order
    ADD CONSTRAINT shop11_order_pkey PRIMARY KEY (id);


--
-- Name: shop11_orderline shop11_orderline_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop11_orderline
    ADD CONSTRAINT shop11_orderline_pkey PRIMARY KEY (id);


--
-- Name: shop11_product shop11_product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop11_product
    ADD CONSTRAINT shop11_product_pkey PRIMARY KEY (id);


--
-- Name: shop11_shippingaddress shop11_shippingaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop11_shippingaddress
    ADD CONSTRAINT shop11_shippingaddress_pkey PRIMARY KEY (id);


--
-- Name: shop12_customer shop12_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop12_customer
    ADD CONSTRAINT shop12_customer_pkey PRIMARY KEY (id);


--
-- Name: shop12_customer shop12_customer_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop12_customer
    ADD CONSTRAINT shop12_customer_user_id_key UNIQUE (user_id);


--
-- Name: shop12_order shop12_order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop12_order
    ADD CONSTRAINT shop12_order_pkey PRIMARY KEY (id);


--
-- Name: shop12_orderline shop12_orderline_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop12_orderline
    ADD CONSTRAINT shop12_orderline_pkey PRIMARY KEY (id);


--
-- Name: shop12_product shop12_product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop12_product
    ADD CONSTRAINT shop12_product_pkey PRIMARY KEY (id);


--
-- Name: shop12_shippingaddress shop12_shippingaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop12_shippingaddress
    ADD CONSTRAINT shop12_shippingaddress_pkey PRIMARY KEY (id);


--
-- Name: shop13_customer shop13_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop13_customer
    ADD CONSTRAINT shop13_customer_pkey PRIMARY KEY (id);


--
-- Name: shop13_customer shop13_customer_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop13_customer
    ADD CONSTRAINT shop13_customer_user_id_key UNIQUE (user_id);


--
-- Name: shop13_order shop13_order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop13_order
    ADD CONSTRAINT shop13_order_pkey PRIMARY KEY (id);


--
-- Name: shop13_orderline shop13_orderline_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop13_orderline
    ADD CONSTRAINT shop13_orderline_pkey PRIMARY KEY (id);


--
-- Name: shop13_product shop13_product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop13_product
    ADD CONSTRAINT shop13_product_pkey PRIMARY KEY (id);


--
-- Name: shop13_shippingaddress shop13_shippingaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop13_shippingaddress
    ADD CONSTRAINT shop13_shippingaddress_pkey PRIMARY KEY (id);


--
-- Name: shop14_customer shop14_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop14_customer
    ADD CONSTRAINT shop14_customer_pkey PRIMARY KEY (id);


--
-- Name: shop14_customer shop14_customer_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop14_customer
    ADD CONSTRAINT shop14_customer_user_id_key UNIQUE (user_id);


--
-- Name: shop14_order shop14_order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop14_order
    ADD CONSTRAINT shop14_order_pkey PRIMARY KEY (id);


--
-- Name: shop14_orderline shop14_orderline_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop14_orderline
    ADD CONSTRAINT shop14_orderline_pkey PRIMARY KEY (id);


--
-- Name: shop14_product shop14_product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop14_product
    ADD CONSTRAINT shop14_product_pkey PRIMARY KEY (id);


--
-- Name: shop14_shippingaddress shop14_shippingaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop14_shippingaddress
    ADD CONSTRAINT shop14_shippingaddress_pkey PRIMARY KEY (id);


--
-- Name: shop15_customer shop15_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop15_customer
    ADD CONSTRAINT shop15_customer_pkey PRIMARY KEY (id);


--
-- Name: shop15_customer shop15_customer_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop15_customer
    ADD CONSTRAINT shop15_customer_user_id_key UNIQUE (user_id);


--
-- Name: shop15_order shop15_order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop15_order
    ADD CONSTRAINT shop15_order_pkey PRIMARY KEY (id);


--
-- Name: shop15_orderline shop15_orderline_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop15_orderline
    ADD CONSTRAINT shop15_orderline_pkey PRIMARY KEY (id);


--
-- Name: shop15_product shop15_product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop15_product
    ADD CONSTRAINT shop15_product_pkey PRIMARY KEY (id);


--
-- Name: shop15_shippingaddress shop15_shippingaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop15_shippingaddress
    ADD CONSTRAINT shop15_shippingaddress_pkey PRIMARY KEY (id);


--
-- Name: shop16_customer shop16_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop16_customer
    ADD CONSTRAINT shop16_customer_pkey PRIMARY KEY (id);


--
-- Name: shop16_customer shop16_customer_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop16_customer
    ADD CONSTRAINT shop16_customer_user_id_key UNIQUE (user_id);


--
-- Name: shop16_order shop16_order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop16_order
    ADD CONSTRAINT shop16_order_pkey PRIMARY KEY (id);


--
-- Name: shop16_orderline shop16_orderline_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop16_orderline
    ADD CONSTRAINT shop16_orderline_pkey PRIMARY KEY (id);


--
-- Name: shop16_product shop16_product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop16_product
    ADD CONSTRAINT shop16_product_pkey PRIMARY KEY (id);


--
-- Name: shop16_shippingaddress shop16_shippingaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop16_shippingaddress
    ADD CONSTRAINT shop16_shippingaddress_pkey PRIMARY KEY (id);


--
-- Name: shop17_customer shop17_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop17_customer
    ADD CONSTRAINT shop17_customer_pkey PRIMARY KEY (id);


--
-- Name: shop17_customer shop17_customer_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop17_customer
    ADD CONSTRAINT shop17_customer_user_id_key UNIQUE (user_id);


--
-- Name: shop17_order shop17_order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop17_order
    ADD CONSTRAINT shop17_order_pkey PRIMARY KEY (id);


--
-- Name: shop17_orderline shop17_orderline_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop17_orderline
    ADD CONSTRAINT shop17_orderline_pkey PRIMARY KEY (id);


--
-- Name: shop17_product shop17_product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop17_product
    ADD CONSTRAINT shop17_product_pkey PRIMARY KEY (id);


--
-- Name: shop17_shippingaddress shop17_shippingaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop17_shippingaddress
    ADD CONSTRAINT shop17_shippingaddress_pkey PRIMARY KEY (id);


--
-- Name: shop18_customer shop18_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop18_customer
    ADD CONSTRAINT shop18_customer_pkey PRIMARY KEY (id);


--
-- Name: shop18_customer shop18_customer_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop18_customer
    ADD CONSTRAINT shop18_customer_user_id_key UNIQUE (user_id);


--
-- Name: shop18_order shop18_order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop18_order
    ADD CONSTRAINT shop18_order_pkey PRIMARY KEY (id);


--
-- Name: shop18_orderline shop18_orderline_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop18_orderline
    ADD CONSTRAINT shop18_orderline_pkey PRIMARY KEY (id);


--
-- Name: shop18_product shop18_product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop18_product
    ADD CONSTRAINT shop18_product_pkey PRIMARY KEY (id);


--
-- Name: shop18_shippingaddress shop18_shippingaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop18_shippingaddress
    ADD CONSTRAINT shop18_shippingaddress_pkey PRIMARY KEY (id);


--
-- Name: shop19_customer shop19_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop19_customer
    ADD CONSTRAINT shop19_customer_pkey PRIMARY KEY (id);


--
-- Name: shop19_customer shop19_customer_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop19_customer
    ADD CONSTRAINT shop19_customer_user_id_key UNIQUE (user_id);


--
-- Name: shop19_order shop19_order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop19_order
    ADD CONSTRAINT shop19_order_pkey PRIMARY KEY (id);


--
-- Name: shop19_orderline shop19_orderline_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop19_orderline
    ADD CONSTRAINT shop19_orderline_pkey PRIMARY KEY (id);


--
-- Name: shop19_product shop19_product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop19_product
    ADD CONSTRAINT shop19_product_pkey PRIMARY KEY (id);


--
-- Name: shop19_shippingaddress shop19_shippingaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop19_shippingaddress
    ADD CONSTRAINT shop19_shippingaddress_pkey PRIMARY KEY (id);


--
-- Name: shop20_customer shop20_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop20_customer
    ADD CONSTRAINT shop20_customer_pkey PRIMARY KEY (id);


--
-- Name: shop20_customer shop20_customer_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop20_customer
    ADD CONSTRAINT shop20_customer_user_id_key UNIQUE (user_id);


--
-- Name: shop20_order shop20_order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop20_order
    ADD CONSTRAINT shop20_order_pkey PRIMARY KEY (id);


--
-- Name: shop20_orderline shop20_orderline_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop20_orderline
    ADD CONSTRAINT shop20_orderline_pkey PRIMARY KEY (id);


--
-- Name: shop20_product shop20_product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop20_product
    ADD CONSTRAINT shop20_product_pkey PRIMARY KEY (id);


--
-- Name: shop20_shippingaddress shop20_shippingaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop20_shippingaddress
    ADD CONSTRAINT shop20_shippingaddress_pkey PRIMARY KEY (id);


--
-- Name: shop_customer shop_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_customer
    ADD CONSTRAINT shop_customer_pkey PRIMARY KEY (id);


--
-- Name: shop_customer shop_customer_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_customer
    ADD CONSTRAINT shop_customer_user_id_key UNIQUE (user_id);


--
-- Name: shop_order shop_order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_order
    ADD CONSTRAINT shop_order_pkey PRIMARY KEY (id);


--
-- Name: shop_orderline shop_orderline_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_orderline
    ADD CONSTRAINT shop_orderline_pkey PRIMARY KEY (id);


--
-- Name: shop_product shop_product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_product
    ADD CONSTRAINT shop_product_pkey PRIMARY KEY (id);


--
-- Name: shop_shippingaddress shop_shippingaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_shippingaddress
    ADD CONSTRAINT shop_shippingaddress_pkey PRIMARY KEY (id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_user_groups_group_id_97559544 ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_user_username_6821ab7c_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: main_follow_created_by_id_4216b194; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX main_follow_created_by_id_4216b194 ON public.main_follow USING btree (created_by_id);


--
-- Name: main_follow_user_followed_id_d42d3ee3; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX main_follow_user_followed_id_d42d3ee3 ON public.main_follow USING btree (user_followed_id);


--
-- Name: main_like_created_by_id_0c01bdc4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX main_like_created_by_id_0c01bdc4 ON public.main_like USING btree (created_by_id);


--
-- Name: main_like_tweet_id_72804091; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX main_like_tweet_id_72804091 ON public.main_like USING btree (tweet_id);


--
-- Name: main_tweet_created_by_id_de58f942; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX main_tweet_created_by_id_de58f942 ON public.main_tweet USING btree (created_by_id);


--
-- Name: main_tweet_related_tweet_id_9596ad42; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX main_tweet_related_tweet_id_9596ad42 ON public.main_tweet USING btree (related_tweet_id);


--
-- Name: shop01_order_customer_id_c50716f7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop01_order_customer_id_c50716f7 ON public.shop01_order USING btree (customer_id);


--
-- Name: shop01_orderline_order_id_86a351bf; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop01_orderline_order_id_86a351bf ON public.shop01_orderline USING btree (order_id);


--
-- Name: shop01_product_customer_id_c5d86595; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop01_product_customer_id_c5d86595 ON public.shop01_product USING btree (customer_id);


--
-- Name: shop01_shippingaddress_customer_id_70e95716; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop01_shippingaddress_customer_id_70e95716 ON public.shop01_shippingaddress USING btree (customer_id);


--
-- Name: shop02_order_customer_id_5d68725e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop02_order_customer_id_5d68725e ON public.shop02_order USING btree (customer_id);


--
-- Name: shop02_orderline_order_id_f1ea6df3; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop02_orderline_order_id_f1ea6df3 ON public.shop02_orderline USING btree (order_id);


--
-- Name: shop02_product_customer_id_ed5029e9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop02_product_customer_id_ed5029e9 ON public.shop02_product USING btree (customer_id);


--
-- Name: shop02_shippingaddress_customer_id_8690ccc3; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop02_shippingaddress_customer_id_8690ccc3 ON public.shop02_shippingaddress USING btree (customer_id);


--
-- Name: shop03_order_customer_id_a5f8369b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop03_order_customer_id_a5f8369b ON public.shop03_order USING btree (customer_id);


--
-- Name: shop03_orderline_order_id_fc1c8109; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop03_orderline_order_id_fc1c8109 ON public.shop03_orderline USING btree (order_id);


--
-- Name: shop03_product_customer_id_49d34a57; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop03_product_customer_id_49d34a57 ON public.shop03_product USING btree (customer_id);


--
-- Name: shop03_shippingaddress_customer_id_81c071ed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop03_shippingaddress_customer_id_81c071ed ON public.shop03_shippingaddress USING btree (customer_id);


--
-- Name: shop04_order_customer_id_ec774de8; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop04_order_customer_id_ec774de8 ON public.shop04_order USING btree (customer_id);


--
-- Name: shop04_orderline_order_id_28b868fb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop04_orderline_order_id_28b868fb ON public.shop04_orderline USING btree (order_id);


--
-- Name: shop04_product_customer_id_a3f3724e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop04_product_customer_id_a3f3724e ON public.shop04_product USING btree (customer_id);


--
-- Name: shop04_shippingaddress_customer_id_72dc6fad; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop04_shippingaddress_customer_id_72dc6fad ON public.shop04_shippingaddress USING btree (customer_id);


--
-- Name: shop05_order_customer_id_02b9756c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop05_order_customer_id_02b9756c ON public.shop05_order USING btree (customer_id);


--
-- Name: shop05_orderline_order_id_d4a90023; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop05_orderline_order_id_d4a90023 ON public.shop05_orderline USING btree (order_id);


--
-- Name: shop05_product_customer_id_4e9fa3d1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop05_product_customer_id_4e9fa3d1 ON public.shop05_product USING btree (customer_id);


--
-- Name: shop05_shippingaddress_customer_id_d247fe42; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop05_shippingaddress_customer_id_d247fe42 ON public.shop05_shippingaddress USING btree (customer_id);


--
-- Name: shop06_order_customer_id_ab170183; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop06_order_customer_id_ab170183 ON public.shop06_order USING btree (customer_id);


--
-- Name: shop06_orderline_order_id_d9177bbc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop06_orderline_order_id_d9177bbc ON public.shop06_orderline USING btree (order_id);


--
-- Name: shop06_product_customer_id_646521f7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop06_product_customer_id_646521f7 ON public.shop06_product USING btree (customer_id);


--
-- Name: shop06_shippingaddress_customer_id_e8d79370; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop06_shippingaddress_customer_id_e8d79370 ON public.shop06_shippingaddress USING btree (customer_id);


--
-- Name: shop07_order_customer_id_949e5113; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop07_order_customer_id_949e5113 ON public.shop07_order USING btree (customer_id);


--
-- Name: shop07_orderline_order_id_1a684a06; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop07_orderline_order_id_1a684a06 ON public.shop07_orderline USING btree (order_id);


--
-- Name: shop07_product_customer_id_84cca2df; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop07_product_customer_id_84cca2df ON public.shop07_product USING btree (customer_id);


--
-- Name: shop07_shippingaddress_customer_id_0921897b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop07_shippingaddress_customer_id_0921897b ON public.shop07_shippingaddress USING btree (customer_id);


--
-- Name: shop08_order_customer_id_6489dd60; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop08_order_customer_id_6489dd60 ON public.shop08_order USING btree (customer_id);


--
-- Name: shop08_orderline_order_id_76fb6bed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop08_orderline_order_id_76fb6bed ON public.shop08_orderline USING btree (order_id);


--
-- Name: shop08_product_customer_id_724e5913; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop08_product_customer_id_724e5913 ON public.shop08_product USING btree (customer_id);


--
-- Name: shop08_shippingaddress_customer_id_9c13622c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop08_shippingaddress_customer_id_9c13622c ON public.shop08_shippingaddress USING btree (customer_id);


--
-- Name: shop09_order_customer_id_1d945d3a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop09_order_customer_id_1d945d3a ON public.shop09_order USING btree (customer_id);


--
-- Name: shop09_orderline_order_id_20d54247; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop09_orderline_order_id_20d54247 ON public.shop09_orderline USING btree (order_id);


--
-- Name: shop09_product_customer_id_5ff967aa; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop09_product_customer_id_5ff967aa ON public.shop09_product USING btree (customer_id);


--
-- Name: shop09_shippingaddress_customer_id_571662e9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop09_shippingaddress_customer_id_571662e9 ON public.shop09_shippingaddress USING btree (customer_id);


--
-- Name: shop10_order_customer_id_27f2cd1d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop10_order_customer_id_27f2cd1d ON public.shop10_order USING btree (customer_id);


--
-- Name: shop10_orderline_order_id_cc630673; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop10_orderline_order_id_cc630673 ON public.shop10_orderline USING btree (order_id);


--
-- Name: shop10_product_customer_id_d8762acd; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop10_product_customer_id_d8762acd ON public.shop10_product USING btree (customer_id);


--
-- Name: shop10_shippingaddress_customer_id_2d17caa0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop10_shippingaddress_customer_id_2d17caa0 ON public.shop10_shippingaddress USING btree (customer_id);


--
-- Name: shop11_order_customer_id_cc8f62d2; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop11_order_customer_id_cc8f62d2 ON public.shop11_order USING btree (customer_id);


--
-- Name: shop11_orderline_order_id_99b9f6ea; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop11_orderline_order_id_99b9f6ea ON public.shop11_orderline USING btree (order_id);


--
-- Name: shop11_product_customer_id_632cf107; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop11_product_customer_id_632cf107 ON public.shop11_product USING btree (customer_id);


--
-- Name: shop11_shippingaddress_customer_id_530cd7f0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop11_shippingaddress_customer_id_530cd7f0 ON public.shop11_shippingaddress USING btree (customer_id);


--
-- Name: shop12_order_customer_id_a59a8892; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop12_order_customer_id_a59a8892 ON public.shop12_order USING btree (customer_id);


--
-- Name: shop12_orderline_order_id_014f64e9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop12_orderline_order_id_014f64e9 ON public.shop12_orderline USING btree (order_id);


--
-- Name: shop12_product_customer_id_422160a9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop12_product_customer_id_422160a9 ON public.shop12_product USING btree (customer_id);


--
-- Name: shop12_shippingaddress_customer_id_cae2169e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop12_shippingaddress_customer_id_cae2169e ON public.shop12_shippingaddress USING btree (customer_id);


--
-- Name: shop13_order_customer_id_0d04c224; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop13_order_customer_id_0d04c224 ON public.shop13_order USING btree (customer_id);


--
-- Name: shop13_orderline_order_id_16348c44; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop13_orderline_order_id_16348c44 ON public.shop13_orderline USING btree (order_id);


--
-- Name: shop13_product_customer_id_9edabf6b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop13_product_customer_id_9edabf6b ON public.shop13_product USING btree (customer_id);


--
-- Name: shop13_shippingaddress_customer_id_01e8bd80; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop13_shippingaddress_customer_id_01e8bd80 ON public.shop13_shippingaddress USING btree (customer_id);


--
-- Name: shop14_order_customer_id_8441be08; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop14_order_customer_id_8441be08 ON public.shop14_order USING btree (customer_id);


--
-- Name: shop14_orderline_order_id_ab621f9e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop14_orderline_order_id_ab621f9e ON public.shop14_orderline USING btree (order_id);


--
-- Name: shop14_product_customer_id_e23d7bca; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop14_product_customer_id_e23d7bca ON public.shop14_product USING btree (customer_id);


--
-- Name: shop14_shippingaddress_customer_id_b9687741; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop14_shippingaddress_customer_id_b9687741 ON public.shop14_shippingaddress USING btree (customer_id);


--
-- Name: shop15_order_customer_id_8be91f4a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop15_order_customer_id_8be91f4a ON public.shop15_order USING btree (customer_id);


--
-- Name: shop15_orderline_order_id_c68e5ee7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop15_orderline_order_id_c68e5ee7 ON public.shop15_orderline USING btree (order_id);


--
-- Name: shop15_product_customer_id_b9b28ab4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop15_product_customer_id_b9b28ab4 ON public.shop15_product USING btree (customer_id);


--
-- Name: shop15_shippingaddress_customer_id_6ec6cef9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop15_shippingaddress_customer_id_6ec6cef9 ON public.shop15_shippingaddress USING btree (customer_id);


--
-- Name: shop16_order_customer_id_2f2e1321; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop16_order_customer_id_2f2e1321 ON public.shop16_order USING btree (customer_id);


--
-- Name: shop16_orderline_order_id_e85d0392; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop16_orderline_order_id_e85d0392 ON public.shop16_orderline USING btree (order_id);


--
-- Name: shop16_product_customer_id_6ad7bcc7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop16_product_customer_id_6ad7bcc7 ON public.shop16_product USING btree (customer_id);


--
-- Name: shop16_shippingaddress_customer_id_42846bc0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop16_shippingaddress_customer_id_42846bc0 ON public.shop16_shippingaddress USING btree (customer_id);


--
-- Name: shop17_order_customer_id_f38201a7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop17_order_customer_id_f38201a7 ON public.shop17_order USING btree (customer_id);


--
-- Name: shop17_orderline_order_id_b820a59f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop17_orderline_order_id_b820a59f ON public.shop17_orderline USING btree (order_id);


--
-- Name: shop17_product_customer_id_3f563d0a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop17_product_customer_id_3f563d0a ON public.shop17_product USING btree (customer_id);


--
-- Name: shop17_shippingaddress_customer_id_a6a3b3b0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop17_shippingaddress_customer_id_a6a3b3b0 ON public.shop17_shippingaddress USING btree (customer_id);


--
-- Name: shop18_order_customer_id_7f37bcca; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop18_order_customer_id_7f37bcca ON public.shop18_order USING btree (customer_id);


--
-- Name: shop18_orderline_order_id_aef15da2; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop18_orderline_order_id_aef15da2 ON public.shop18_orderline USING btree (order_id);


--
-- Name: shop18_product_customer_id_5082adcc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop18_product_customer_id_5082adcc ON public.shop18_product USING btree (customer_id);


--
-- Name: shop18_shippingaddress_customer_id_074a2fbf; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop18_shippingaddress_customer_id_074a2fbf ON public.shop18_shippingaddress USING btree (customer_id);


--
-- Name: shop19_order_customer_id_165499b5; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop19_order_customer_id_165499b5 ON public.shop19_order USING btree (customer_id);


--
-- Name: shop19_orderline_order_id_dd96fd6b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop19_orderline_order_id_dd96fd6b ON public.shop19_orderline USING btree (order_id);


--
-- Name: shop19_product_customer_id_5e2a1b50; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop19_product_customer_id_5e2a1b50 ON public.shop19_product USING btree (customer_id);


--
-- Name: shop19_shippingaddress_customer_id_01ed9cd1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop19_shippingaddress_customer_id_01ed9cd1 ON public.shop19_shippingaddress USING btree (customer_id);


--
-- Name: shop20_order_customer_id_e29ccfba; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop20_order_customer_id_e29ccfba ON public.shop20_order USING btree (customer_id);


--
-- Name: shop20_orderline_order_id_27ab933a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop20_orderline_order_id_27ab933a ON public.shop20_orderline USING btree (order_id);


--
-- Name: shop20_product_customer_id_a8581bf7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop20_product_customer_id_a8581bf7 ON public.shop20_product USING btree (customer_id);


--
-- Name: shop20_shippingaddress_customer_id_028b07cb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop20_shippingaddress_customer_id_028b07cb ON public.shop20_shippingaddress USING btree (customer_id);


--
-- Name: shop_order_customer_id_f638df20; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop_order_customer_id_f638df20 ON public.shop_order USING btree (customer_id);


--
-- Name: shop_orderline_order_id_8ad562c5; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop_orderline_order_id_8ad562c5 ON public.shop_orderline USING btree (order_id);


--
-- Name: shop_product_customer_id_7d3a0e99; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop_product_customer_id_7d3a0e99 ON public.shop_product USING btree (customer_id);


--
-- Name: shop_shippingaddress_customer_id_c9f97754; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop_shippingaddress_customer_id_c9f97754 ON public.shop_shippingaddress USING btree (customer_id);


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_follow main_follow_created_by_id_4216b194_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.main_follow
    ADD CONSTRAINT main_follow_created_by_id_4216b194_fk_auth_user_id FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_follow main_follow_user_followed_id_d42d3ee3_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.main_follow
    ADD CONSTRAINT main_follow_user_followed_id_d42d3ee3_fk_auth_user_id FOREIGN KEY (user_followed_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_like main_like_created_by_id_0c01bdc4_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.main_like
    ADD CONSTRAINT main_like_created_by_id_0c01bdc4_fk_auth_user_id FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_like main_like_tweet_id_72804091_fk_main_tweet_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.main_like
    ADD CONSTRAINT main_like_tweet_id_72804091_fk_main_tweet_id FOREIGN KEY (tweet_id) REFERENCES public.main_tweet(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_tweet main_tweet_created_by_id_de58f942_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.main_tweet
    ADD CONSTRAINT main_tweet_created_by_id_de58f942_fk_auth_user_id FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_tweet main_tweet_related_tweet_id_9596ad42_fk_main_tweet_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.main_tweet
    ADD CONSTRAINT main_tweet_related_tweet_id_9596ad42_fk_main_tweet_id FOREIGN KEY (related_tweet_id) REFERENCES public.main_tweet(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop01_customer shop01_customer_user_id_19e364b9_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop01_customer
    ADD CONSTRAINT shop01_customer_user_id_19e364b9_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop01_order shop01_order_customer_id_c50716f7_fk_shop01_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop01_order
    ADD CONSTRAINT shop01_order_customer_id_c50716f7_fk_shop01_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop01_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop01_orderline shop01_orderline_order_id_86a351bf_fk_shop01_order_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop01_orderline
    ADD CONSTRAINT shop01_orderline_order_id_86a351bf_fk_shop01_order_id FOREIGN KEY (order_id) REFERENCES public.shop01_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop01_product shop01_product_customer_id_c5d86595_fk_shop01_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop01_product
    ADD CONSTRAINT shop01_product_customer_id_c5d86595_fk_shop01_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop01_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop01_shippingaddress shop01_shippingaddre_customer_id_70e95716_fk_shop01_cu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop01_shippingaddress
    ADD CONSTRAINT shop01_shippingaddre_customer_id_70e95716_fk_shop01_cu FOREIGN KEY (customer_id) REFERENCES public.shop01_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop02_customer shop02_customer_user_id_4bc269bb_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop02_customer
    ADD CONSTRAINT shop02_customer_user_id_4bc269bb_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop02_order shop02_order_customer_id_5d68725e_fk_shop02_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop02_order
    ADD CONSTRAINT shop02_order_customer_id_5d68725e_fk_shop02_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop02_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop02_orderline shop02_orderline_order_id_f1ea6df3_fk_shop02_order_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop02_orderline
    ADD CONSTRAINT shop02_orderline_order_id_f1ea6df3_fk_shop02_order_id FOREIGN KEY (order_id) REFERENCES public.shop02_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop02_product shop02_product_customer_id_ed5029e9_fk_shop02_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop02_product
    ADD CONSTRAINT shop02_product_customer_id_ed5029e9_fk_shop02_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop02_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop02_shippingaddress shop02_shippingaddre_customer_id_8690ccc3_fk_shop02_cu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop02_shippingaddress
    ADD CONSTRAINT shop02_shippingaddre_customer_id_8690ccc3_fk_shop02_cu FOREIGN KEY (customer_id) REFERENCES public.shop02_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop03_customer shop03_customer_user_id_bcaf800a_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop03_customer
    ADD CONSTRAINT shop03_customer_user_id_bcaf800a_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop03_order shop03_order_customer_id_a5f8369b_fk_shop03_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop03_order
    ADD CONSTRAINT shop03_order_customer_id_a5f8369b_fk_shop03_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop03_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop03_orderline shop03_orderline_order_id_fc1c8109_fk_shop03_order_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop03_orderline
    ADD CONSTRAINT shop03_orderline_order_id_fc1c8109_fk_shop03_order_id FOREIGN KEY (order_id) REFERENCES public.shop03_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop03_product shop03_product_customer_id_49d34a57_fk_shop03_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop03_product
    ADD CONSTRAINT shop03_product_customer_id_49d34a57_fk_shop03_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop03_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop03_shippingaddress shop03_shippingaddre_customer_id_81c071ed_fk_shop03_cu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop03_shippingaddress
    ADD CONSTRAINT shop03_shippingaddre_customer_id_81c071ed_fk_shop03_cu FOREIGN KEY (customer_id) REFERENCES public.shop03_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop04_customer shop04_customer_user_id_7d6d4f13_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop04_customer
    ADD CONSTRAINT shop04_customer_user_id_7d6d4f13_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop04_order shop04_order_customer_id_ec774de8_fk_shop04_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop04_order
    ADD CONSTRAINT shop04_order_customer_id_ec774de8_fk_shop04_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop04_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop04_orderline shop04_orderline_order_id_28b868fb_fk_shop04_order_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop04_orderline
    ADD CONSTRAINT shop04_orderline_order_id_28b868fb_fk_shop04_order_id FOREIGN KEY (order_id) REFERENCES public.shop04_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop04_product shop04_product_customer_id_a3f3724e_fk_shop04_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop04_product
    ADD CONSTRAINT shop04_product_customer_id_a3f3724e_fk_shop04_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop04_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop04_shippingaddress shop04_shippingaddre_customer_id_72dc6fad_fk_shop04_cu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop04_shippingaddress
    ADD CONSTRAINT shop04_shippingaddre_customer_id_72dc6fad_fk_shop04_cu FOREIGN KEY (customer_id) REFERENCES public.shop04_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop05_customer shop05_customer_user_id_a96b4e78_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop05_customer
    ADD CONSTRAINT shop05_customer_user_id_a96b4e78_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop05_order shop05_order_customer_id_02b9756c_fk_shop05_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop05_order
    ADD CONSTRAINT shop05_order_customer_id_02b9756c_fk_shop05_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop05_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop05_orderline shop05_orderline_order_id_d4a90023_fk_shop05_order_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop05_orderline
    ADD CONSTRAINT shop05_orderline_order_id_d4a90023_fk_shop05_order_id FOREIGN KEY (order_id) REFERENCES public.shop05_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop05_product shop05_product_customer_id_4e9fa3d1_fk_shop05_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop05_product
    ADD CONSTRAINT shop05_product_customer_id_4e9fa3d1_fk_shop05_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop05_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop05_shippingaddress shop05_shippingaddre_customer_id_d247fe42_fk_shop05_cu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop05_shippingaddress
    ADD CONSTRAINT shop05_shippingaddre_customer_id_d247fe42_fk_shop05_cu FOREIGN KEY (customer_id) REFERENCES public.shop05_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop06_customer shop06_customer_user_id_cccf3ea0_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop06_customer
    ADD CONSTRAINT shop06_customer_user_id_cccf3ea0_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop06_order shop06_order_customer_id_ab170183_fk_shop06_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop06_order
    ADD CONSTRAINT shop06_order_customer_id_ab170183_fk_shop06_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop06_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop06_orderline shop06_orderline_order_id_d9177bbc_fk_shop06_order_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop06_orderline
    ADD CONSTRAINT shop06_orderline_order_id_d9177bbc_fk_shop06_order_id FOREIGN KEY (order_id) REFERENCES public.shop06_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop06_product shop06_product_customer_id_646521f7_fk_shop06_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop06_product
    ADD CONSTRAINT shop06_product_customer_id_646521f7_fk_shop06_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop06_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop06_shippingaddress shop06_shippingaddre_customer_id_e8d79370_fk_shop06_cu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop06_shippingaddress
    ADD CONSTRAINT shop06_shippingaddre_customer_id_e8d79370_fk_shop06_cu FOREIGN KEY (customer_id) REFERENCES public.shop06_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop07_customer shop07_customer_user_id_4f8b41a3_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop07_customer
    ADD CONSTRAINT shop07_customer_user_id_4f8b41a3_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop07_order shop07_order_customer_id_949e5113_fk_shop07_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop07_order
    ADD CONSTRAINT shop07_order_customer_id_949e5113_fk_shop07_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop07_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop07_orderline shop07_orderline_order_id_1a684a06_fk_shop07_order_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop07_orderline
    ADD CONSTRAINT shop07_orderline_order_id_1a684a06_fk_shop07_order_id FOREIGN KEY (order_id) REFERENCES public.shop07_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop07_product shop07_product_customer_id_84cca2df_fk_shop07_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop07_product
    ADD CONSTRAINT shop07_product_customer_id_84cca2df_fk_shop07_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop07_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop07_shippingaddress shop07_shippingaddre_customer_id_0921897b_fk_shop07_cu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop07_shippingaddress
    ADD CONSTRAINT shop07_shippingaddre_customer_id_0921897b_fk_shop07_cu FOREIGN KEY (customer_id) REFERENCES public.shop07_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop08_customer shop08_customer_user_id_d24865d6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop08_customer
    ADD CONSTRAINT shop08_customer_user_id_d24865d6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop08_order shop08_order_customer_id_6489dd60_fk_shop08_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop08_order
    ADD CONSTRAINT shop08_order_customer_id_6489dd60_fk_shop08_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop08_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop08_orderline shop08_orderline_order_id_76fb6bed_fk_shop08_order_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop08_orderline
    ADD CONSTRAINT shop08_orderline_order_id_76fb6bed_fk_shop08_order_id FOREIGN KEY (order_id) REFERENCES public.shop08_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop08_product shop08_product_customer_id_724e5913_fk_shop08_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop08_product
    ADD CONSTRAINT shop08_product_customer_id_724e5913_fk_shop08_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop08_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop08_shippingaddress shop08_shippingaddre_customer_id_9c13622c_fk_shop08_cu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop08_shippingaddress
    ADD CONSTRAINT shop08_shippingaddre_customer_id_9c13622c_fk_shop08_cu FOREIGN KEY (customer_id) REFERENCES public.shop08_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop09_customer shop09_customer_user_id_55fda531_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop09_customer
    ADD CONSTRAINT shop09_customer_user_id_55fda531_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop09_order shop09_order_customer_id_1d945d3a_fk_shop09_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop09_order
    ADD CONSTRAINT shop09_order_customer_id_1d945d3a_fk_shop09_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop09_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop09_orderline shop09_orderline_order_id_20d54247_fk_shop09_order_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop09_orderline
    ADD CONSTRAINT shop09_orderline_order_id_20d54247_fk_shop09_order_id FOREIGN KEY (order_id) REFERENCES public.shop09_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop09_product shop09_product_customer_id_5ff967aa_fk_shop09_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop09_product
    ADD CONSTRAINT shop09_product_customer_id_5ff967aa_fk_shop09_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop09_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop09_shippingaddress shop09_shippingaddre_customer_id_571662e9_fk_shop09_cu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop09_shippingaddress
    ADD CONSTRAINT shop09_shippingaddre_customer_id_571662e9_fk_shop09_cu FOREIGN KEY (customer_id) REFERENCES public.shop09_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop10_customer shop10_customer_user_id_49c4372c_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop10_customer
    ADD CONSTRAINT shop10_customer_user_id_49c4372c_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop10_order shop10_order_customer_id_27f2cd1d_fk_shop10_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop10_order
    ADD CONSTRAINT shop10_order_customer_id_27f2cd1d_fk_shop10_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop10_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop10_orderline shop10_orderline_order_id_cc630673_fk_shop10_order_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop10_orderline
    ADD CONSTRAINT shop10_orderline_order_id_cc630673_fk_shop10_order_id FOREIGN KEY (order_id) REFERENCES public.shop10_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop10_product shop10_product_customer_id_d8762acd_fk_shop10_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop10_product
    ADD CONSTRAINT shop10_product_customer_id_d8762acd_fk_shop10_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop10_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop10_shippingaddress shop10_shippingaddre_customer_id_2d17caa0_fk_shop10_cu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop10_shippingaddress
    ADD CONSTRAINT shop10_shippingaddre_customer_id_2d17caa0_fk_shop10_cu FOREIGN KEY (customer_id) REFERENCES public.shop10_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop11_customer shop11_customer_user_id_f766dd32_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop11_customer
    ADD CONSTRAINT shop11_customer_user_id_f766dd32_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop11_order shop11_order_customer_id_cc8f62d2_fk_shop11_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop11_order
    ADD CONSTRAINT shop11_order_customer_id_cc8f62d2_fk_shop11_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop11_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop11_orderline shop11_orderline_order_id_99b9f6ea_fk_shop11_order_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop11_orderline
    ADD CONSTRAINT shop11_orderline_order_id_99b9f6ea_fk_shop11_order_id FOREIGN KEY (order_id) REFERENCES public.shop11_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop11_product shop11_product_customer_id_632cf107_fk_shop11_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop11_product
    ADD CONSTRAINT shop11_product_customer_id_632cf107_fk_shop11_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop11_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop11_shippingaddress shop11_shippingaddre_customer_id_530cd7f0_fk_shop11_cu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop11_shippingaddress
    ADD CONSTRAINT shop11_shippingaddre_customer_id_530cd7f0_fk_shop11_cu FOREIGN KEY (customer_id) REFERENCES public.shop11_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop12_customer shop12_customer_user_id_bce3e3ce_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop12_customer
    ADD CONSTRAINT shop12_customer_user_id_bce3e3ce_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop12_order shop12_order_customer_id_a59a8892_fk_shop12_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop12_order
    ADD CONSTRAINT shop12_order_customer_id_a59a8892_fk_shop12_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop12_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop12_orderline shop12_orderline_order_id_014f64e9_fk_shop12_order_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop12_orderline
    ADD CONSTRAINT shop12_orderline_order_id_014f64e9_fk_shop12_order_id FOREIGN KEY (order_id) REFERENCES public.shop12_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop12_product shop12_product_customer_id_422160a9_fk_shop12_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop12_product
    ADD CONSTRAINT shop12_product_customer_id_422160a9_fk_shop12_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop12_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop12_shippingaddress shop12_shippingaddre_customer_id_cae2169e_fk_shop12_cu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop12_shippingaddress
    ADD CONSTRAINT shop12_shippingaddre_customer_id_cae2169e_fk_shop12_cu FOREIGN KEY (customer_id) REFERENCES public.shop12_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop13_customer shop13_customer_user_id_35a715bb_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop13_customer
    ADD CONSTRAINT shop13_customer_user_id_35a715bb_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop13_order shop13_order_customer_id_0d04c224_fk_shop13_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop13_order
    ADD CONSTRAINT shop13_order_customer_id_0d04c224_fk_shop13_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop13_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop13_orderline shop13_orderline_order_id_16348c44_fk_shop13_order_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop13_orderline
    ADD CONSTRAINT shop13_orderline_order_id_16348c44_fk_shop13_order_id FOREIGN KEY (order_id) REFERENCES public.shop13_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop13_product shop13_product_customer_id_9edabf6b_fk_shop13_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop13_product
    ADD CONSTRAINT shop13_product_customer_id_9edabf6b_fk_shop13_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop13_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop13_shippingaddress shop13_shippingaddre_customer_id_01e8bd80_fk_shop13_cu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop13_shippingaddress
    ADD CONSTRAINT shop13_shippingaddre_customer_id_01e8bd80_fk_shop13_cu FOREIGN KEY (customer_id) REFERENCES public.shop13_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop14_customer shop14_customer_user_id_472d093f_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop14_customer
    ADD CONSTRAINT shop14_customer_user_id_472d093f_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop14_order shop14_order_customer_id_8441be08_fk_shop14_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop14_order
    ADD CONSTRAINT shop14_order_customer_id_8441be08_fk_shop14_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop14_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop14_orderline shop14_orderline_order_id_ab621f9e_fk_shop14_order_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop14_orderline
    ADD CONSTRAINT shop14_orderline_order_id_ab621f9e_fk_shop14_order_id FOREIGN KEY (order_id) REFERENCES public.shop14_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop14_product shop14_product_customer_id_e23d7bca_fk_shop14_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop14_product
    ADD CONSTRAINT shop14_product_customer_id_e23d7bca_fk_shop14_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop14_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop14_shippingaddress shop14_shippingaddre_customer_id_b9687741_fk_shop14_cu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop14_shippingaddress
    ADD CONSTRAINT shop14_shippingaddre_customer_id_b9687741_fk_shop14_cu FOREIGN KEY (customer_id) REFERENCES public.shop14_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop15_customer shop15_customer_user_id_cca3811f_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop15_customer
    ADD CONSTRAINT shop15_customer_user_id_cca3811f_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop15_order shop15_order_customer_id_8be91f4a_fk_shop15_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop15_order
    ADD CONSTRAINT shop15_order_customer_id_8be91f4a_fk_shop15_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop15_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop15_orderline shop15_orderline_order_id_c68e5ee7_fk_shop15_order_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop15_orderline
    ADD CONSTRAINT shop15_orderline_order_id_c68e5ee7_fk_shop15_order_id FOREIGN KEY (order_id) REFERENCES public.shop15_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop15_product shop15_product_customer_id_b9b28ab4_fk_shop15_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop15_product
    ADD CONSTRAINT shop15_product_customer_id_b9b28ab4_fk_shop15_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop15_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop15_shippingaddress shop15_shippingaddre_customer_id_6ec6cef9_fk_shop15_cu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop15_shippingaddress
    ADD CONSTRAINT shop15_shippingaddre_customer_id_6ec6cef9_fk_shop15_cu FOREIGN KEY (customer_id) REFERENCES public.shop15_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop16_customer shop16_customer_user_id_42469a38_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop16_customer
    ADD CONSTRAINT shop16_customer_user_id_42469a38_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop16_order shop16_order_customer_id_2f2e1321_fk_shop16_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop16_order
    ADD CONSTRAINT shop16_order_customer_id_2f2e1321_fk_shop16_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop16_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop16_orderline shop16_orderline_order_id_e85d0392_fk_shop16_order_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop16_orderline
    ADD CONSTRAINT shop16_orderline_order_id_e85d0392_fk_shop16_order_id FOREIGN KEY (order_id) REFERENCES public.shop16_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop16_product shop16_product_customer_id_6ad7bcc7_fk_shop16_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop16_product
    ADD CONSTRAINT shop16_product_customer_id_6ad7bcc7_fk_shop16_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop16_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop16_shippingaddress shop16_shippingaddre_customer_id_42846bc0_fk_shop16_cu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop16_shippingaddress
    ADD CONSTRAINT shop16_shippingaddre_customer_id_42846bc0_fk_shop16_cu FOREIGN KEY (customer_id) REFERENCES public.shop16_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop17_customer shop17_customer_user_id_3802680a_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop17_customer
    ADD CONSTRAINT shop17_customer_user_id_3802680a_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop17_order shop17_order_customer_id_f38201a7_fk_shop17_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop17_order
    ADD CONSTRAINT shop17_order_customer_id_f38201a7_fk_shop17_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop17_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop17_orderline shop17_orderline_order_id_b820a59f_fk_shop17_order_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop17_orderline
    ADD CONSTRAINT shop17_orderline_order_id_b820a59f_fk_shop17_order_id FOREIGN KEY (order_id) REFERENCES public.shop17_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop17_product shop17_product_customer_id_3f563d0a_fk_shop17_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop17_product
    ADD CONSTRAINT shop17_product_customer_id_3f563d0a_fk_shop17_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop17_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop17_shippingaddress shop17_shippingaddre_customer_id_a6a3b3b0_fk_shop17_cu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop17_shippingaddress
    ADD CONSTRAINT shop17_shippingaddre_customer_id_a6a3b3b0_fk_shop17_cu FOREIGN KEY (customer_id) REFERENCES public.shop17_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop18_customer shop18_customer_user_id_788e92ac_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop18_customer
    ADD CONSTRAINT shop18_customer_user_id_788e92ac_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop18_order shop18_order_customer_id_7f37bcca_fk_shop18_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop18_order
    ADD CONSTRAINT shop18_order_customer_id_7f37bcca_fk_shop18_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop18_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop18_orderline shop18_orderline_order_id_aef15da2_fk_shop18_order_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop18_orderline
    ADD CONSTRAINT shop18_orderline_order_id_aef15da2_fk_shop18_order_id FOREIGN KEY (order_id) REFERENCES public.shop18_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop18_product shop18_product_customer_id_5082adcc_fk_shop18_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop18_product
    ADD CONSTRAINT shop18_product_customer_id_5082adcc_fk_shop18_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop18_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop18_shippingaddress shop18_shippingaddre_customer_id_074a2fbf_fk_shop18_cu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop18_shippingaddress
    ADD CONSTRAINT shop18_shippingaddre_customer_id_074a2fbf_fk_shop18_cu FOREIGN KEY (customer_id) REFERENCES public.shop18_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop19_customer shop19_customer_user_id_282c5dd3_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop19_customer
    ADD CONSTRAINT shop19_customer_user_id_282c5dd3_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop19_order shop19_order_customer_id_165499b5_fk_shop19_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop19_order
    ADD CONSTRAINT shop19_order_customer_id_165499b5_fk_shop19_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop19_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop19_orderline shop19_orderline_order_id_dd96fd6b_fk_shop19_order_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop19_orderline
    ADD CONSTRAINT shop19_orderline_order_id_dd96fd6b_fk_shop19_order_id FOREIGN KEY (order_id) REFERENCES public.shop19_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop19_product shop19_product_customer_id_5e2a1b50_fk_shop19_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop19_product
    ADD CONSTRAINT shop19_product_customer_id_5e2a1b50_fk_shop19_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop19_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop19_shippingaddress shop19_shippingaddre_customer_id_01ed9cd1_fk_shop19_cu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop19_shippingaddress
    ADD CONSTRAINT shop19_shippingaddre_customer_id_01ed9cd1_fk_shop19_cu FOREIGN KEY (customer_id) REFERENCES public.shop19_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop20_customer shop20_customer_user_id_2b67b38c_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop20_customer
    ADD CONSTRAINT shop20_customer_user_id_2b67b38c_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop20_order shop20_order_customer_id_e29ccfba_fk_shop20_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop20_order
    ADD CONSTRAINT shop20_order_customer_id_e29ccfba_fk_shop20_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop20_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop20_orderline shop20_orderline_order_id_27ab933a_fk_shop20_order_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop20_orderline
    ADD CONSTRAINT shop20_orderline_order_id_27ab933a_fk_shop20_order_id FOREIGN KEY (order_id) REFERENCES public.shop20_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop20_product shop20_product_customer_id_a8581bf7_fk_shop20_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop20_product
    ADD CONSTRAINT shop20_product_customer_id_a8581bf7_fk_shop20_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop20_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop20_shippingaddress shop20_shippingaddre_customer_id_028b07cb_fk_shop20_cu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop20_shippingaddress
    ADD CONSTRAINT shop20_shippingaddre_customer_id_028b07cb_fk_shop20_cu FOREIGN KEY (customer_id) REFERENCES public.shop20_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop_customer shop_customer_user_id_7e6c4129_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_customer
    ADD CONSTRAINT shop_customer_user_id_7e6c4129_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop_order shop_order_customer_id_f638df20_fk_shop_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_order
    ADD CONSTRAINT shop_order_customer_id_f638df20_fk_shop_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop_orderline shop_orderline_order_id_8ad562c5_fk_shop_order_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_orderline
    ADD CONSTRAINT shop_orderline_order_id_8ad562c5_fk_shop_order_id FOREIGN KEY (order_id) REFERENCES public.shop_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop_product shop_product_customer_id_7d3a0e99_fk_shop_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_product
    ADD CONSTRAINT shop_product_customer_id_7d3a0e99_fk_shop_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop_shippingaddress shop_shippingaddress_customer_id_c9f97754_fk_shop_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_shippingaddress
    ADD CONSTRAINT shop_shippingaddress_customer_id_c9f97754_fk_shop_customer_id FOREIGN KEY (customer_id) REFERENCES public.shop_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

